<?php
// core/autoloader.php - PSR-4 Autoloader
// Adapted from GitHub reference for procedural compatibility

class Autoloader
{
    private static $namespaces = [];

    /**
     * Register the autoloader
     */
    public static function register()
    {
        spl_autoload_register([self::class, 'load']);

        // Register default namespaces
        self::addNamespace('App\\Core', __DIR__);
        self::addNamespace('App\\Modules', dirname(__DIR__) . '/modules');
    }

    /**
     * Add a namespace mapping
     * 
     * @param string $prefix Namespace prefix
     * @param string $baseDir Base directory for the namespace
     */
    public static function addNamespace($prefix, $baseDir)
    {
        // Normalize prefix
        $prefix = trim($prefix, '\\') . '\\';

        // Normalize base directory
        $baseDir = rtrim($baseDir, DIRECTORY_SEPARATOR) . '/';

        // Initialize array for this prefix if needed
        if (!isset(self::$namespaces[$prefix])) {
            self::$namespaces[$prefix] = [];
        }

        // Append base directory
        array_push(self::$namespaces[$prefix], $baseDir);
    }

    /**
     * Load the class file for a given class name
     * 
     * @param string $class Fully qualified class name
     * @return bool True if loaded, false otherwise
     */
    private static function load($class)
    {
        // Current namespace prefix
        $prefix = $class;

        // Work backwards through namespace to find mapped file
        while (false !== $pos = strrpos($prefix, '\\')) {
            // Retain trailing separator in prefix
            $prefix = substr($class, 0, $pos + 1);

            // Rest is relative class name
            $relativeClass = substr($class, $pos + 1);

            // Try to load mapped file
            $mappedFile = self::loadMappedFile($prefix, $relativeClass);
            if ($mappedFile) {
                return true;
            }

            // Remove trailing separator for next iteration
            $prefix = rtrim($prefix, '\\');
        }

        return false;
    }

    /**
     * Load the mapped file for a namespace prefix and relative class
     * 
     * @param string $prefix Namespace prefix
     * @param string $relativeClass Relative class name
     * @return bool True if loaded, false otherwise
     */
    private static function loadMappedFile($prefix, $relativeClass)
    {
        // Check if prefix has any mappings
        if (!isset(self::$namespaces[$prefix])) {
            return false;
        }

        // Look through base directories for this namespace prefix
        foreach (self::$namespaces[$prefix] as $baseDir) {
            // Replace namespace separators with directory separators
            // and append .php
            $file = $baseDir
                . str_replace('\\', '/', $relativeClass)
                . '.php';

            // If file exists, require it
            if (self::requireFile($file)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Require a file if it exists
     * 
     * @param string $file File path
     * @return bool True if file exists and was required
     */
    private static function requireFile($file)
    {
        if (file_exists($file)) {
            require $file;
            return true;
        }
        return false;
    }

    /**
     * Get all registered namespaces (for debugging)
     * 
     * @return array
     */
    public static function getNamespaces()
    {
        return self::$namespaces;
    }
}

// Auto-register on include
Autoloader::register();
?>