<?php
// core/logger.php - Centralized logging utility

class Logger
{
    private static $logFile = __DIR__ . '/../logs/system.log';

    public static function log($message, $level = 'INFO', $context = [])
    {
        $logDir = dirname(self::$logFile);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }

        $timestamp = date('Y-m-d H:i:s');
        $userId = $_SESSION['user_id'] ?? 'GUEST';
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

        $jsonContext = $context ? json_encode($context) : '';
        $logEntry = "[$timestamp] [$level] [User: $userId] [IP: $ip] $message $jsonContext" . PHP_EOL;

        file_put_contents(self::$logFile, $logEntry, FILE_APPEND);
    }

    public static function error($message, $context = [])
    {
        self::log($message, 'ERROR', $context);
    }
}

// Global Error Handlers
set_error_handler(function ($errno, $errstr, $errfile, $errline) {
    if (!(error_reporting() & $errno))
        return;
    Logger::error("PHP Error: $errstr", ['file' => $errfile, 'line' => $errline, 'errno' => $errno]);
});

set_exception_handler(function ($exception) {
    Logger::error("PHP Exception: " . $exception->getMessage(), [
        'file' => $exception->getFile(),
        'line' => $exception->getLine(),
        'trace' => $exception->getTraceAsString()
    ]);
});

register_shutdown_function(function () {
    $error = error_get_last();
    if ($error !== NULL && ($error['type'] === E_ERROR || $error['type'] === E_PARSE || $error['type'] === E_CORE_ERROR || $error['type'] === E_COMPILE_ERROR)) {
        Logger::error("Fatal Error: " . $error['message'], ['file' => $error['file'], 'line' => $error['line']]);
    }
});
?>