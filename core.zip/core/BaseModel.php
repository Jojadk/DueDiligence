<?php
// core/BaseModel.php

class BaseModel
{
    protected $db;
    protected $table;
    protected $tenantId;

    public function __construct(string $table)
    {
        $this->db = get_db_connection();
        $this->table = $table;
        // Assume tenant_id is stored in session
        $this->tenantId = $_SESSION['tenant_id'] ?? null;
    }

    /**
     * Automatically append filters (tenant_id, deleted_at) to queries.
     */
    protected function applyFilters(string $query, array &$params): string
    {
        $filters = [];

        if ($this->tenantId !== null) {
            $filters[] = "tenant_id = ?";
            $params[] = $this->tenantId;
        }

        // Always filter out soft-deleted records by default
        $filters[] = "deleted_at IS NULL";

        if (!empty($filters)) {
            $separator = (stripos($query, 'WHERE') === false) ? ' WHERE ' : ' AND ';
            $query .= $separator . implode(' AND ', $filters);
        }

        return $query;
    }

    public function find(int $id)
    {
        $params = [$id];
        $sql = "SELECT * FROM {$this->table} WHERE id = ?";
        $sql = $this->applyFilters($sql, $params);

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetch();
    }

    public function all(string $orderBy = 'id ASC')
    {
        $params = [];
        $sql = "SELECT * FROM {$this->table}";
        $sql = $this->applyFilters($sql, $params);
        $sql .= " ORDER BY {$orderBy}";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    // Add other CRUD methods as needed...
}
?>