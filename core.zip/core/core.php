<?php
// core/core.php - Core utility functions for DueDiligence SPA

require_once __DIR__ . '/constants.php';
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/logger.php';
require_once __DIR__ . '/template_parser.php';
require_once __DIR__ . '/App.php';

/**
 * Simple DB connection using PDO.
 * @return PDO
 */
function get_db_connection(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }
    return $pdo;
}

/**
 * Standard rounding (round-up) for financial values.
 */
if (!function_exists('roundVal')) {
    function roundVal($val, $factor)
    {
        if (!$factor || $factor <= 0)
            return (float) $val;
        return ceil((float) $val / $factor) * $factor;
    }
}

/**
 * Render a template using the custom parser.
 * @param string $templatePath Absolute path to .tpl file.
 * @param array $data Associative array of variables for the template.
 * @return string Rendered HTML.
 */
function render_template(string $templatePath, array $data = []): string
{
    // Load parser (assumes parser file exists later)
    if (!function_exists('parse_template')) {
        // Fallback simple include if parser not yet implemented
        extract($data);
        ob_start();
        include $templatePath;
        return ob_get_clean();
    }
    return parse_template($templatePath, $data);
}

/**
 * Fetch definitions of extra fields for a given type, optionally filtered by user group permissions.
 * @param string $bindType e.g., 'customers', 'projects'
 * @param int|null $groupId ID of the user group to check permissions for.
 * @return array
 */
function get_extra_field_definitions(string $bindType, ?int $groupId = null): array
{
    $db = get_db_connection();

    if ($groupId === null) {
        $stmt = $db->prepare("SELECT * FROM dd_system_ExtraFields WHERE bind_type = ? AND active = 1 ORDER BY sort_order ASC");
        $stmt->execute([$bindType]);
    } else {
        // qdPM style: check if permissions are defined. If not defined, we might default to allowed or denied.
        // Here we'll only return fields where allow_view is explicitly 1 OR where no specific permission is defined for that group (optional design)
        $stmt = $db->prepare("
            SELECT f.* 
            FROM dd_system_ExtraFields f
            LEFT JOIN dd_system_ExtraFieldPermissions p ON f.id = p.field_id AND p.group_id = ?
            WHERE f.bind_type = ? AND f.active = 1 
            AND (p.allow_view = 1 OR p.allow_view IS NULL)
            ORDER BY f.sort_order ASC
        ");
        $stmt->execute([$groupId, $bindType]);
    }

    return $stmt->fetchAll();
}

/**
 * Fetch extra field values for a specific record.
 * @param string $bindType
 * @param int $bindId
 * @return array Associative array of [field_name => value]
 */
function get_extra_field_values(string $bindType, int $bindId): array
{
    $db = get_db_connection();
    $stmt = $db->prepare("
        SELECT f.name, v.value 
        FROM dd_system_ExtraFieldValues v
        JOIN dd_system_ExtraFields f ON v.field_id = f.id
        WHERE f.bind_type = ? AND v.bind_id = ?
    ");
    $stmt->execute([$bindType, $bindId]);
    $results = [];
    foreach ($stmt->fetchAll() as $row) {
        $results[$row['name']] = $row['value'];
    }
    return $results;
}

/**
 * Save extra field values for a record.
 * @param int $bindId
 * @param array $values Associative array of [field_id => value]
 */
function save_extra_field_values(int $bindId, array $values): void
{
    $db = get_db_connection();
    foreach ($values as $fieldId => $value) {
        $stmt = $db->prepare("
            INSERT INTO dd_system_ExtraFieldValues (field_id, bind_id, value)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE value = ?
        ");
        $stmt->execute([$fieldId, $bindId, $value, $value]);
    }
}

/**
 * Fetch attachments for a given record.
 * @param string $bindType
 * @param int $bindId
 * @return array
 */
function get_attachments(string $bindType, int $bindId): array
{
    $db = get_db_connection();
    $stmt = $db->prepare("SELECT * FROM dd_system_Attachments WHERE bind_type = ? AND bind_id = ? ORDER BY created_at DESC");
    $stmt->execute([$bindType, $bindId]);
    return $stmt->fetchAll();
}

/**
 * Fetch comments for a given record.
 * @param string $bindType
 * @param int $bindId
 * @return array
 */
function get_comments(string $bindType, int $bindId): array
{
    $db = get_db_connection();
    $stmt = $db->prepare("
        SELECT c.*, u.name as user_name 
        FROM dd_system_Comments c
        LEFT JOIN dd_users u ON c.user_id = u.id
        WHERE c.bind_type = ? AND c.bind_id = ? 
        ORDER BY c.created_at ASC
    ");
    $stmt->execute([$bindType, $bindId]);
    return $stmt->fetchAll();
}

/**
 * Fetch dynamic budget intervals for a project.
 * @param int $projectId
 * @return array
 */
function get_project_intervals(int $projectId): array
{
    $db = get_db_connection();
    $stmt = $db->prepare("SELECT * FROM dd_project_Intervals WHERE project_id = ? ORDER BY sort_order ASC");
    $stmt->execute([$projectId]);
    return $stmt->fetchAll();
}

/**
 * Prepares data for templates, including project-specific budget intervals.
 * @param int $projectId
 * @param array $additionalData
 * @return array
 */
function get_template_data_with_intervals(int $projectId, array $additionalData = []): array
{
    return array_merge([
        'intervals' => get_project_intervals($projectId),
        'horizon' => BUDGET_HORIZON_DEFAULT
    ], $additionalData);
}

/**
 * Resolves a full image URL from a relative path or filename.
 */
function get_image_url(?string $path): string
{
    if (empty($path)) {
        return '';
    }
    // If it's already an absolute URL, return as is
    if (strpos($path, 'http') === 0 || strpos($path, 'https') === 0) {
        return $path;
    }
    // Remove leading slash if any
    $path = ltrim($path, '/');

    // If the path already includes assets/uploads, we just need BASE_URL
    if (strpos($path, UPLOAD_DIR) === 0) {
        return BASE_URL . $path;
    }

    // Otherwise prepend UPLOAD_URL
    return UPLOAD_URL . $path;
}

/**
 * Generate a UUID v7 (time-ordered).
 * @return string
 */
function generate_uuid_v7(): string
{
    // 48-bit timestamp in milliseconds
    $milli = (int) (microtime(true) * 1000);
    $binary = pack('J', $milli);
    $binary = substr($binary, 2); // 6 bytes

    // 16 bits for rand_a (including version 7)
    $rand_a = random_bytes(2);
    $binary .= $rand_a;

    // 64 bits for rand_b (including variant)
    $rand_b = random_bytes(8);
    $binary .= $rand_b;

    // Set version to 7: bits 48-51 (first 4 bits of 7th byte)
    $binary[6] = chr((ord($binary[6]) & 0x0f) | 0x70);

    // Set variant to RFC 4122: bits 64-65 (first 2 bits of 9th byte)
    $binary[8] = chr((ord($binary[8]) & 0x3f) | 0x80);

    return sprintf(
        '%08s-%04s-%04s-%04s-%12s',
        bin2hex(substr($binary, 0, 4)),
        bin2hex(substr($binary, 4, 2)),
        bin2hex(substr($binary, 6, 2)),
        bin2hex(substr($binary, 8, 2)),
        bin2hex(substr($binary, 10, 6))
    );
}

/**
 * Helper to send JSON response with proper headers.
 */
function json_response(array $payload, int $status = 200): void
{
    header('Content-Type: application/json');
    http_response_code($status);
    echo json_encode($payload);
    exit;
}

/**
 * MD5 Query Caching System
 * Implements intelligent caching for database queries.
 */
class QueryCache
{
    private static $cache = [];
    private static $hits = 0;
    private static $misses = 0;

    /**
     * Generate a unique cache key based on SQL and parameters.
     */
    public static function generateKey(string $sql, array $params = []): string
    {
        return md5($sql . serialize($params));
    }

    /**
     * Get a value from the cache.
     */
    public static function get(string $key)
    {
        if (isset(self::$cache[$key])) {
            self::$hits++;
            return self::$cache[$key];
        }
        self::$misses++;
        return null;
    }

    /**
     * Set a value in the cache.
     */
    public static function set(string $key, $value): void
    {
        self::$cache[$key] = $value;
    }

    /**
     * Clear the entire cache (useful after updates).
     */
    public static function clear(): void
    {
        self::$cache = [];
    }
}

/**
 * Execute a query with caching support.
 * @param string $sql
 * @param array $params
 * @param bool $useCache
 * @return array
 */
function db_query(string $sql, array $params = [], bool $useCache = true): array
{
    if ($useCache && stripos(trim($sql), 'SELECT') === 0) {
        $key = QueryCache::generateKey($sql, $params);
        $cached = QueryCache::get($key);
        if ($cached !== null) {
            return $cached;
        }
    }

    $db = get_db_connection();
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($useCache && stripos(trim($sql), 'SELECT') === 0) {
        QueryCache::set($key, $data);
    }

    return $data;
}

/**
 * Fetch all rows (Alias for db_query).
 */
function db_fetch_all(string $sql, array $params = [], bool $useCache = true): array
{
    return db_query($sql, $params, $useCache);
}

/**
 * Fetch a single row.
 */
function db_fetch(string $sql, array $params = [], bool $useCache = true): ?array
{
    $rows = db_query($sql, $params, $useCache);
    return $rows[0] ?? null;
}

/**
 * Fetch a single value.
 */
function db_value(string $sql, array $params = [], bool $useCache = true)
{
    $row = db_fetch($sql, $params, $useCache);
    return $row ? array_shift($row) : null;
}

/**
 * Execute a non-query statement (INSERT, UPDATE, DELETE).
 * automatically clears query cache to ensure consistency.
 */
function db_execute(string $sql, array $params = []): bool
{
    $db = get_db_connection();
    $stmt = $db->prepare($sql);
    $result = $stmt->execute($params);

    // Clear cache on modification to ensure data consistency
    QueryCache::clear();

    return $result;
}

/**
 * Fetches all project data (buildings, elements, budget, media) in a batch
 * to avoid N+1 query patterns in reports. Includes rounding logic.
 */
function get_project_data_batch($db, $projectId)
{
    // 0. Fetch Project Rounding
    $stmt = $db->prepare("SELECT rounding_level FROM dd_projects WHERE id = ?");
    $stmt->execute([$projectId]);
    $projectRounding = (float) ($stmt->fetchColumn() ?: 0);

    // 1. Fetch Buildings
    $stmt = $db->prepare("SELECT * FROM dd_buildings WHERE project_id = ? ORDER BY name ASC");
    $stmt->execute([$projectId]);
    $buildings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($buildings)) {
        return [];
    }

    $buildingIds = array_column($buildings, 'id');
    $placeholders = implode(',', array_fill(0, count($buildingIds), '?'));

    // 2. Fetch All Elements for these buildings
    $stmt = $db->prepare("
        SELECT * FROM dd_building_Elements 
        WHERE building_id IN ($placeholders) AND project_id = ?
        ORDER BY sort_order ASC, id ASC
    ");
    $params = array_merge($buildingIds, [$projectId]);
    $stmt->execute($params);
    $allElements = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($allElements)) {
        foreach ($buildings as &$b)
            $b['tree'] = [];
        return $buildings;
    }

    $elementIds = array_column($allElements, 'id');
    $elPlaceholders = implode(',', array_fill(0, count($elementIds), '?'));

    // 3. Fetch All Budget Items for these elements
    $stmt = $db->prepare("SELECT * FROM dd_budget_items WHERE element_id IN ($elPlaceholders) ORDER BY sort_order ASC, id ASC");
    $stmt->execute($elementIds);
    $allBudget = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 4. Fetch All Media for these elements
    $stmt = $db->prepare("SELECT * FROM element_media WHERE element_id IN ($elPlaceholders) ORDER BY sort_order ASC, id ASC");
    $stmt->execute($elementIds);
    $allMedia = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 5. Fetch All Comments for these elements
    // We fetch user name to display "Written by X"
    $stmt = $db->prepare("
        SELECT c.*, u.name as user_name 
        FROM dd_system_Comments c
        LEFT JOIN dd_users u ON c.user_id = u.id
        WHERE c.bind_type = 'element' AND c.bind_id IN ($elPlaceholders)
        ORDER BY c.created_at DESC
    ");
    $stmt->execute($elementIds);
    $allComments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Grouping for O(1) access
    $budgetByElement = [];
    foreach ($allBudget as $bi) {
        $budgetByElement[$bi['element_id']][] = $bi;
    }

    $mediaByElement = [];
    foreach ($allMedia as $m) {
        $mediaByElement[$m['element_id']][] = $m;
    }

    $commentsByElement = [];
    foreach ($allComments as $c) {
        $commentsByElement[$c['bind_id']][] = $c;
    }

    // Map elements by building
    $elementsByBuilding = [];
    $elementsById = [];
    foreach ($allElements as &$el) {
        $el['children'] = [];
        $el['budget_items'] = $budgetByElement[$el['id']] ?? [];
        $el['media'] = $mediaByElement[$el['id']] ?? [];
        $el['comments'] = $commentsByElement[$el['id']] ?? [];

        // Element override or Project default
        $ro = $projectRounding;
        if (isset($el['rounding_override']) && $el['rounding_override'] !== null && $el['rounding_override'] > 0) {
            $ro = (float) $el['rounding_override'];
        }

        // Calculate total budget (Sum of Rounds logic)
        $totalBudget = 0;
        $el['cost_buckets'] = [
            '0_1' => 0,
            '1_2' => 0,
            '3_5' => 0,
            '5_10' => 0
        ];

        foreach ($el['budget_items'] as &$bi) {
            $v1 = (float) ($bi['amount_0_1'] ?? 0);
            $v2 = (float) ($bi['amount_1_2'] ?? 0);
            $v3 = (float) ($bi['amount_3_5'] ?? 0);
            $v4 = (float) ($bi['amount_5_10'] ?? 0);
            $vTotal = (float) ($bi['total_calculated'] ?? 0);

            if ($ro > 0) {
                $v1 = roundVal($v1, $ro);
                $v2 = roundVal($v2, $ro);
                $v3 = roundVal($v3, $ro);
                $v4 = roundVal($v4, $ro);
                $vTotal = roundVal($vTotal, $ro);
            }

            // Update individual item values for detailed tables
            $bi['amount_0_1'] = $v1;
            $bi['amount_1_2'] = $v2;
            $bi['amount_3_5'] = $v3;
            $bi['amount_5_10'] = $v4;
            $bi['total_calculated'] = $vTotal;

            $el['cost_buckets']['0_1'] += $v1;
            $el['cost_buckets']['1_2'] += $v2;
            $el['cost_buckets']['3_5'] += $v3;
            $el['cost_buckets']['5_10'] += $v4;
            $totalBudget += $vTotal;
        }

        $el['total_budget'] = $totalBudget;
        $el['capex'] = $totalBudget; // Alias for different templates
        $el['estimated_cost'] = $totalBudget; // Alias for "Technical Audit Summary"

        // Fallback for elements without budget items but with risk levels
        if ($totalBudget == 0 && !empty($el['capex_fallback'])) {
            $totalBudget = (float) $el['capex_fallback'];
            if ($ro > 0)
                $totalBudget = ceil($totalBudget / $ro) * $ro;
            $el['total_budget'] = $totalBudget;
            $el['capex'] = $totalBudget;
            $el['estimated_cost'] = $totalBudget;

            // Distribute into buckets based on risk if no budget items
            $risk = $el['risk_level'] ?? '';
            if (strpos($risk, 'Rød') !== false)
                $el['cost_buckets']['0_1'] = $totalBudget;
            elseif (strpos($risk, 'Gul') !== false)
                $el['cost_buckets']['1_2'] = $totalBudget;
            elseif (strpos($risk, 'Grøn') !== false)
                $el['cost_buckets']['3_5'] = $totalBudget;
            else
                $el['cost_buckets']['5_10'] = $totalBudget;
        }

        $elementsById[$el['id']] = &$el;
        $elementsByBuilding[$el['building_id']][] = &$el;
    }
    unset($el);

    // Assemble trees per building
    foreach ($buildings as &$building) {
        $buildingElements = $elementsByBuilding[$building['id']] ?? [];
        $tree = [];
        foreach ($buildingElements as &$node) {
            if ($node['parent_id'] && isset($elementsById[$node['parent_id']])) {
                $elementsById[$node['parent_id']]['children'][] = &$node;
            } else {
                $tree[] = &$node;
            }
        }
        $building['tree'] = $tree;
    }
    unset($node);
    unset($building);

    return $buildings;
}

/**
 * Ensure meta table exists - SINGLETON PATTERN
 */
function ensure_project_meta_table($db)
{
    static $checked = false;
    if ($checked)
        return;

    try {
        $result = $db->query("SHOW TABLES LIKE 'dd_project_meta'");
        if ($result->rowCount() > 0) {
            $checked = true;
            return;
        }
    } catch (Exception $e) {
        // Table doesn't exist, create it
    }

    $sql = "CREATE TABLE IF NOT EXISTS dd_project_meta (
        id INT AUTO_INCREMENT PRIMARY KEY,
        project_id INT NOT NULL,
        meta_key VARCHAR(50) NOT NULL,
        meta_value TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY unique_project_key (project_id, meta_key),
        FOREIGN KEY (project_id) REFERENCES dd_projects(id) ON DELETE CASCADE,
        INDEX idx_project_id (project_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

    $db->exec($sql);
    $checked = true;
}

/**
 * Get project metadata - OPTIMIZED
 */
function get_project_meta($db, $projectId)
{
    ensure_project_meta_table($db);

    $stmt = $db->prepare("
        SELECT meta_key, meta_value 
        FROM dd_project_meta 
        WHERE project_id = ?
    ");
    $stmt->execute([$projectId]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $meta = [];
    foreach ($rows as $row) {
        $value = $row['meta_value'];

        // Attempt JSON decode
        if (is_string($value) && !empty($value)) {
            $decoded = json_decode($value, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                $value = $decoded;
            }
        }

        $meta[$row['meta_key']] = $value;
    }

    return $meta;
}

/**
 * Save project metadata - UPSERT
 */
function save_project_meta($db, $projectId, $key, $value)
{
    ensure_project_meta_table($db);

    // Validate key length
    if (strlen($key) > 50) {
        throw new Exception("Meta key too long");
    }

    // JSON encode if needed
    if (is_array($value) || is_object($value)) {
        $value = json_encode($value, JSON_UNESCAPED_UNICODE);
    }

    $stmt = $db->prepare("
        INSERT INTO dd_project_meta (project_id, meta_key, meta_value) 
        VALUES (?, ?, ?) 
        ON DUPLICATE KEY UPDATE 
            meta_value = VALUES(meta_value),
            updated_at = CURRENT_TIMESTAMP
    ");

    return $stmt->execute([$projectId, $key, $value]);
}
?>