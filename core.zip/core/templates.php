<?php
// core/templates.php

/**
 * Standard Element Templates
 * Hierarchical structure for bulk creation
 */

function get_standard_templates()
{
    return [
        'Standard Template 1' => [
            'description' => 'Standard struktur for bygningsdele (Udendørs, Skal, Indvendig, Teknik)',
            'structure' => [
                [
                    'name' => 'Udendørsarealer',
                    'children' => [
                        ['name' => 'Belægninger'],
                        ['name' => 'Grønne områder'],
                        ['name' => 'Hegn, porte og støttemure'],
                        ['name' => 'Udvendig belysning'],
                        ['name' => 'Afvanding af terræn'],
                        ['name' => 'Skilte og inventar']
                    ]
                ],
                [
                    'name' => 'Bygningsskal',
                    'children' => [
                        ['name' => 'Fundamenter og terrændæk'],
                        ['name' => 'Facader'],
                        ['name' => 'Vinduer og yderdøre'],
                        ['name' => 'Tage'],
                        ['name' => 'Altaner og udvendige trapper'],
                        ['name' => 'Porte og ramper']
                    ]
                ],
                [
                    'name' => 'Indvendige bygningsdele',
                    'children' => [
                        ['name' => 'Indvendige vægge'],
                        ['name' => 'Indvendige døre'],
                        ['name' => 'Gulve'],
                        ['name' => 'Lofter'],
                        ['name' => 'Indvendige trapper'],
                        ['name' => 'Inventar']
                    ]
                ],
                [
                    'name' => 'Tekniske installationer',
                    'children' => [
                        ['name' => 'Vand'],
                        ['name' => 'Afløb'],
                        ['name' => 'Varme'],
                        ['name' => 'Køling'],
                        ['name' => 'Ventilation'],
                        ['name' => 'El-grundinstallationer'],
                        ['name' => 'Belysning'],
                        ['name' => 'Elevatorer'],
                        ['name' => 'Brandsikring'],
                        ['name' => 'CTS']
                    ]
                ]
            ]
        ]
    ];
}
