<?php
// core/input_lock.php - Conflict Prevention System
// Adapted from GitHub reference

class InputLock
{
    private static $db = null;

    private static function getDB()
    {
        if (self::$db === null) {
            self::$db = get_db_connection();
        }
        return self::$db;
    }

    /**
     * Ensure input_locks table exists
     */
    public static function ensureTable()
    {
        $db = self::getDB();
        $sql = "
            CREATE TABLE IF NOT EXISTS input_locks (
                id INT(11) AUTO_INCREMENT PRIMARY KEY,
                table_name VARCHAR(64) NOT NULL,
                row_id INT(11) NOT NULL,
                field_name VARCHAR(64) DEFAULT NULL,
                user_id INT(11) NOT NULL,
                client_id VARCHAR(64) DEFAULT NULL,
                ip_address VARCHAR(45) DEFAULT NULL,
                locked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY unique_lock (table_name, row_id, field_name),
                KEY idx_user (user_id),
                KEY idx_locked_at (locked_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ";

        try {
            $db->exec($sql);
        } catch (Exception $e) {
            // Table might already exist
        }
    }

    /**
     * Acquire a lock on a field/row
     * 
     * @param string $table Table name
     * @param int $rowId Row ID
     * @param string|null $field Field name (null for whole row)
     * @param string|null $clientId Unique client identifier (browser tab)
     * @return array ['success' => bool, 'locked_by' => string|null]
     */
    public static function acquireLock($table, $rowId, $field = null, $clientId = null)
    {
        $db = self::getDB();
        $userId = $_SESSION['user_id'] ?? null;

        if (!$userId) {
            return ['success' => false, 'error' => 'Not authenticated'];
        }

        // 1. Clean up old locks (> 60 seconds)
        $db->exec("DELETE FROM input_locks WHERE locked_at < DATE_SUB(NOW(), INTERVAL 60 SECOND)");

        // 2. Check for existing lock
        $sql = "SELECT l.*, u.name as username 
                FROM input_locks l 
                JOIN dd_users u ON l.user_id = u.id
                WHERE l.table_name = ? AND l.row_id = ?";
        $params = [$table, $rowId];

        if ($field) {
            $sql .= " AND l.field_name = ?";
            $params[] = $field;
        }

        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $existing = $stmt->fetch();

        if ($existing) {
            // Locked by different user
            if ($existing['user_id'] != $userId) {
                return [
                    'success' => false,
                    'locked_by' => $existing['username'],
                    'locked_at' => $existing['locked_at']
                ];
            }

            // Same user, different window/tab
            if ($clientId && $existing['client_id'] && $existing['client_id'] !== $clientId) {
                return [
                    'success' => false,
                    'locked_by' => 'dig selv i et andet vindue',
                    'locked_at' => $existing['locked_at']
                ];
            }

            // Same user, same client - refresh lock
            self::refreshLock($existing['id']);
            return ['success' => true, 'refreshed' => true];
        }

        // 3. Create new lock
        try {
            $stmt = $db->prepare("
                INSERT INTO input_locks (table_name, row_id, field_name, user_id, client_id, ip_address, locked_at)
                VALUES (?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([
                $table,
                $rowId,
                $field,
                $userId,
                $clientId,
                get_client_ip()
            ]);

            return ['success' => true];
        } catch (PDOException $e) {
            return ['success' => false, 'error' => 'Could not acquire lock'];
        }
    }

    /**
     * Refresh a lock (extend timeout)
     */
    public static function refreshLock($lockId)
    {
        $db = self::getDB();
        $stmt = $db->prepare("UPDATE input_locks SET locked_at = NOW() WHERE id = ?");
        $stmt->execute([$lockId]);
    }

    /**
     * Release a lock
     */
    public static function releaseLock($table, $rowId, $field = null)
    {
        $db = self::getDB();
        $userId = $_SESSION['user_id'] ?? null;

        if (!$userId) {
            return false;
        }

        $sql = "DELETE FROM input_locks WHERE table_name = ? AND row_id = ? AND user_id = ?";
        $params = [$table, $rowId, $userId];

        if ($field) {
            $sql .= " AND field_name = ?";
            $params[] = $field;
        }

        $stmt = $db->prepare($sql);
        $stmt->execute($params);

        return true;
    }

    /**
     * Get all active locks for a user
     */
    public static function getUserLocks($userId = null)
    {
        $db = self::getDB();
        $userId = $userId ?? ($_SESSION['user_id'] ?? null);

        if (!$userId) {
            return [];
        }

        $stmt = $db->prepare("SELECT * FROM input_locks WHERE user_id = ?");
        $stmt->execute([$userId]);
        return $stmt->fetchAll();
    }

    /**
     * Cleanup old locks (for cron job)
     */
    public static function cleanup($olderThanMinutes = 60)
    {
        $db = self::getDB();
        $stmt = $db->prepare("
            DELETE FROM input_locks 
            WHERE locked_at < DATE_SUB(NOW(), INTERVAL ? MINUTE)
        ");
        $stmt->execute([$olderThanMinutes]);
        return $stmt->rowCount();
    }
}

// Initialize table on first load
InputLock::ensureTable();
?>