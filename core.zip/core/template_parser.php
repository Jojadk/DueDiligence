<?php
// core/template_parser.php
// Simple custom template parser supporting {if}, {else}, {endif}, {while}, and variable filters.
// Caching is enabled via CACHE_ENABLED constant; compiled PHP files are stored in cache/templates/.

if (!defined('CACHE_ENABLED')) {
    define('CACHE_ENABLED', false);
}

/**
 * Parse a template file and return rendered HTML.
 * @param string $templatePath Absolute path to .tpl file.
 * @param array $data Variables to be used in the template.
 * @return string Rendered content.
 */
function parse_template(string $templatePath, array $data = []): string
{
    // Resolve cache path
    $cacheDir = __DIR__ . '/../cache/templates';
    if (!is_dir($cacheDir)) {
        mkdir($cacheDir, 0755, true);
    }
    $cacheFile = $cacheDir . '/' . md5($templatePath) . '.php';

    if (CACHE_ENABLED && file_exists($cacheFile) && filemtime($cacheFile) >= filemtime($templatePath)) {
        // Use cached compiled template
        extract($data);
        ob_start();
        include $cacheFile;
        return ob_get_clean();
    }

    $content = file_get_contents($templatePath);
    if ($content === false) {
        throw new Exception('Unable to read template: ' . $templatePath);
    }

    // Replace variable tags {{var}} or {{var|filter}} with PHP echo
    $content = preg_replace_callback('/\{\{\s*([a-zA-Z0-9_|]+)\s*\}\}/', function ($m) {
        $parts = explode('|', $m[1]);
        $var = trim($parts[0]);
        $filter = isset($parts[1]) ? trim($parts[1]) : '';

        switch ($filter) {
            case 'money':
                return "<?php echo number_format((float)\${$var}, 2, ',', ' ') . ' kr'; ?>";
            case 'date':
                return "<?php echo date('Y-m-d', strtotime(\${$var})); ?>";
            case 'json_encode':
                return "<?php echo json_encode(\${$var} ?? null); ?>";
            case 'raw':
                return "<?php echo \${$var} ?? ''; ?>";
            default:
                return "<?php echo htmlspecialchars((string)(\${$var} ?? ''), ENT_QUOTES, 'UTF-8'); ?>";
        }
    }, $content);

    // Simple {if $cond} ... {else} ... {endif}
    $content = preg_replace('/\{if\s+([^}]+)\}/', '<?php if ($1): ?>', $content);
    $content = str_replace('{else}', '<?php else: ?>', $content);
    $content = str_replace('{endif}', '<?php endif; ?>', $content);

    // Simple {while $array as $item} ... {endwhile}
    $content = preg_replace('/\{while\s+([^}]+)\}/', '<?php while ($1): ?>', $content);
    $content = str_replace('{endwhile}', '<?php endwhile; ?>', $content);

    // Write compiled version if caching enabled
    if (CACHE_ENABLED) {
        file_put_contents($cacheFile, $content);
    }

    // Evaluate the compiled template
    extract($data);
    ob_start();
    eval ('?>' . $content);
    return ob_get_clean();
}
?>