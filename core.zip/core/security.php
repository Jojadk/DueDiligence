<?php
// core/security.php - Security utilities for DueDiligence SPA

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/**
 * Generate a CSRF token and store it in session.
 * @return string
 */
function generate_csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token from request.
 * @param string|null $token
 * @return bool
 */
function verify_csrf_token(?string $token): bool
{
    return $token !== null && hash_equals($_SESSION['csrf_token'] ?? '', $token);
}

/**
 * Check if the current user has a specific permission flag.
 * @param string $flagName e.g., 'allow_manage_projects'
 * @return bool
 */
function has_permission(string $flagName): bool
{
    if (session_status() === PHP_SESSION_NONE)
        session_start();
    if (!isset($_SESSION['user_id']))
        return false;

    // Check session cache first
    // if (isset($_SESSION['permissions']) && isset($_SESSION['permissions'][$flagName])) {
    //    return (bool) $_SESSION['permissions'][$flagName];
    // }

    // Fallback to DB
    include_once __DIR__ . '/core.php';
    $db = get_db_connection();
    $stmt = $db->prepare("
        SELECT g.* 
        FROM dd_user_Groups g
        JOIN dd_users u ON u.group_id = g.id
        WHERE u.id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $group = $stmt->fetch();

    if (!$group)
        return false;

    // Cache all permissions in session
    $_SESSION['permissions'] = $group;

    return isset($group[$flagName]) && (bool) $group[$flagName];
}

/**
 * Require a specific permission flag to proceed.
 */
function require_permission(string $flagName): void
{
    if (!has_permission($flagName)) {
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'Unauthorized: Missing permission ' . $flagName]);
            exit;
        } else {
            die("Access Denied: Missing permission " . $flagName);
        }
    }
}

/**
 * Require a specific role (backward compatibility or simple checks).
 */
function require_role($role)
{
    if (session_status() === PHP_SESSION_NONE)
        session_start();

    $user_role = $_SESSION['user_role'] ?? 'guest';

    if ($role === 'admin' && $user_role !== 'admin') {
        require_permission('allow_manage_configuration');
    }

    if ($role === 'editor' && !in_array($user_role, ['admin', 'editor', 'manager'])) {
        require_permission('allow_manage_projects');
    }
}

/**
 * Authenticate a user.
 * Uses password_verify() for secure bcrypt/argon2 password verification.
 */
function login_user(string $email, string $password, string $totpCode = ''): bool
{
    require_once __DIR__ . '/rate_limiter.php';
    require_once __DIR__ . '/totp.php';
    include_once __DIR__ . '/core.php';

    $db = get_db_connection();
    $clientIP = get_client_ip();

    // Rate limiting check
    $rateLimit = RateLimiter::checkLimit($clientIP, 'login', 5, 300);
    if (!$rateLimit['allowed']) {
        Logger::log("Login rate limit exceeded", 'WARNING', ['ip' => $clientIP, 'email' => $email]);
        return false;
    }

    $stmt = $db->prepare("SELECT id, name, password, group_id, totp_secret, totp_enabled FROM dd_users WHERE email = ? AND active = 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        // Record failed attempt
        RateLimiter::recordAttempt($clientIP, 'login', false);
        Logger::log("Failed login attempt", 'WARNING', ['ip' => $clientIP, 'email' => $email]);
        return false;
    }

    // Check 2FA if enabled
    if ($user['totp_enabled'] && $user['totp_secret']) {
        if (empty($totpCode) || !TOTP::verify($user['totp_secret'], $totpCode)) {
            RateLimiter::recordAttempt($clientIP, 'login', false);
            Logger::log("Failed 2FA verification", 'WARNING', ['ip' => $clientIP, 'email' => $email]);
            $_SESSION['2fa_pending'] = $user['id']; // Store for 2FA prompt
            return false;
        }
    }

    // Success - reset rate limit and set session
    RateLimiter::recordAttempt($clientIP, 'login', true);

    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_role'] = 'user';

    // Fetch Group Name for role
    if ($user['group_id']) {
        $gStmt = $db->prepare("SELECT name FROM dd_user_Groups WHERE id = ?");
        $gStmt->execute([$user['group_id']]);
        $group = $gStmt->fetch();
        if ($group && strtolower($group['name']) === 'admin') {
            $_SESSION['user_role'] = 'admin';
        }
    }

    // Initialize session fingerprint
    initialize_session_fingerprint();
    session_regenerate_id(true);

    Logger::log("Successful login", 'INFO', ['user_id' => $user['id'], 'ip' => $clientIP]);
    return true;
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }
    session_destroy();
}

function is_authenticated(): bool
{
    return !empty($_SESSION['user_id']);
}

/**
 * Session Fingerprinting - Prevents session hijacking
 */
function generate_session_fingerprint(): string
{
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
    $ip = get_client_ip();
    return hash('sha256', $userAgent . $ip);
}

function validate_session_fingerprint(): bool
{
    if (!isset($_SESSION['fingerprint'])) {
        return false;
    }
    return hash_equals($_SESSION['fingerprint'], generate_session_fingerprint());
}

function initialize_session_fingerprint(): void
{
    $_SESSION['fingerprint'] = generate_session_fingerprint();
    $_SESSION['created_at'] = time();
    $_SESSION['last_activity'] = time();
}

function get_client_ip(): string
{
    $ipKeys = [
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'REMOTE_ADDR'
    ];

    foreach ($ipKeys as $key) {
        if (array_key_exists($key, $_SERVER)) {
            $ips = explode(',', $_SERVER[$key]);
            $ip = trim($ips[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }
    return '0.0.0.0';
}

/**
 * Check session timeout (30 minutes default)
 */
function check_session_timeout(int $timeout = 1800): bool
{
    if (!isset($_SESSION['last_activity'])) {
        return false;
    }

    if ((time() - $_SESSION['last_activity']) > $timeout) {
        return false;
    }

    $_SESSION['last_activity'] = time();
    return true;
}

/**
 * Regenerate session with fingerprint (enhanced security)
 */
function regenerate_session_secure(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_regenerate_id(true);
        $_SESSION['fingerprint'] = generate_session_fingerprint();
        $_SESSION['last_activity'] = time();
    }
}

/**
 * Configure secure session settings
 */
function configure_secure_session(): void
{
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_secure', '1'); // HTTPS only
    ini_set('session.cookie_samesite', 'Strict');
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
}

/**
 * Sanitize input for XSS protection
 */
function sanitize_input($data)
{
    if (is_array($data)) {
        return array_map('sanitize_input', $data);
    }

    if (is_string($data)) {
        $data = str_replace("\0", '', $data); // Remove null bytes
        $data = trim($data);
        $data = htmlspecialchars($data, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    return $data;
}
?>