<?php
// core/constants.php - Global constants for DueDiligence SPA
require_once __DIR__ . '/logger.php';

// Base URL of the application (Supports subdirectories like /tdd/)
if (!defined('BASE_URL')) {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $script = $_SERVER['SCRIPT_NAME'];
    $dir = str_replace('\\', '/', dirname($script));
    if ($dir !== '/')
        $dir .= '/';
    define('BASE_URL', $protocol . $host . $dir);
}

// Database connection settings (to be configured by the deployment environment)
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'due_diligence');
define('DB_USER', 'root');
define('DB_PASS', 'merRoot2026!');
define('DB_CHARSET', 'utf8mb4');

// Caching toggle for template engine
define('CACHE_ENABLED', false); // Disabled for development
define('APP_VERSION', time()); // Dynamic versioning to bust browser cache
ini_set('display_errors', 0); // Hide errors in production (logged via logger.php)

// Session Hardening - Anti-Hijacking
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_samesite', 'Lax');
session_set_cookie_params([
    'lifetime' => 0,
    'path' => $dir, // Limit cookie to the subdirectory
    'domain' => '',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Lax'
]);
session_start();

// Session Fingerprinting to prevent hijacking
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
if (!isset($_SESSION['user_agent'])) {
    $_SESSION['user_agent'] = $userAgent;
} elseif ($_SESSION['user_agent'] !== $userAgent) {
    session_destroy();
    session_start();
}

// Other global settings
define('APP_PREFIX', 'dd'); // Prefix for tables and assets
define('BUDGET_HORIZON_DEFAULT', 10); // Standard CAPEX horizon in years

// Image and Upload Settings
define('UPLOAD_DIR', 'assets/uploads/');
define('UPLOAD_PATH', __DIR__ . '/../' . UPLOAD_DIR);
define('UPLOAD_URL', BASE_URL . UPLOAD_DIR);
define('IMAGE_QUALITY', 80); // Compression quality (1-100)
define('IMAGE_COMPRESSION_TYPE', 'webp'); // Target format
// AI Settings
define('GEMINI_API_KEY', 'AIzaSyBn3ZqMm5xwUfy01K3yM-Sp38ytDImkIrc');
?>