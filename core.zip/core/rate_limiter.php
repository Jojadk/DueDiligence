<?php
// core/rate_limiter.php - Rate limiting for brute force protection
// Adapted from GitHub reference, simplified for procedural use

class RateLimiter
{
    private static $db = null;

    private static function getDB()
    {
        if (self::$db === null) {
            self::$db = get_db_connection();
        }
        return self::$db;
    }

    /**
     * Ensure rate_limits table exists
     */
    public static function ensureTable()
    {
        $db = self::getDB();
        $sql = "
            CREATE TABLE IF NOT EXISTS rate_limits (
                id INT(11) AUTO_INCREMENT PRIMARY KEY,
                identifier VARCHAR(255) NOT NULL,
                action VARCHAR(50) NOT NULL,
                attempts INT DEFAULT 0,
                first_attempt_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_attempt_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                blocked_until TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY unique_rate_limit (identifier, action)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ";

        try {
            $db->exec($sql);
        } catch (Exception $e) {
            // Table might already exist
        }
    }

    /**
     * Check if action is allowed
     */
    public static function checkLimit($identifier, $action, $maxAttempts = 5, $windowSeconds = 300)
    {
        $db = self::getDB();

        $stmt = $db->prepare("SELECT * FROM rate_limits WHERE identifier = ? AND action = ?");
        $stmt->execute([$identifier, $action]);
        $record = $stmt->fetch();

        $now = time();

        // Check if blocked
        if ($record && $record['blocked_until']) {
            $blockedUntil = strtotime($record['blocked_until']);
            if ($blockedUntil > $now) {
                return [
                    'allowed' => false,
                    'remaining' => 0,
                    'reset_at' => $blockedUntil,
                    'blocked' => true,
                    'message' => 'Too many attempts. Try again in ' . ceil(($blockedUntil - $now) / 60) . ' minutes.'
                ];
            } else {
                // Block expired, reset
                self::reset($identifier, $action);
                $record = null;
            }
        }

        // No record
        if (!$record) {
            return [
                'allowed' => true,
                'remaining' => $maxAttempts - 1,
                'reset_at' => $now + $windowSeconds,
                'blocked' => false
            ];
        }

        $firstAttempt = strtotime($record['first_attempt_at']);
        $attempts = (int) $record['attempts'];

        // Window expired
        if (($now - $firstAttempt) > $windowSeconds) {
            self::reset($identifier, $action);
            return [
                'allowed' => true,
                'remaining' => $maxAttempts - 1,
                'reset_at' => $now + $windowSeconds,
                'blocked' => false
            ];
        }

        // Limit exceeded
        if ($attempts >= $maxAttempts) {
            $blockDuration = self::calculateBackoff($attempts);
            self::block($identifier, $action, $blockDuration);

            return [
                'allowed' => false,
                'remaining' => 0,
                'reset_at' => $now + $blockDuration,
                'blocked' => true,
                'message' => 'Rate limit exceeded. Blocked for ' . ceil($blockDuration / 60) . ' minutes.'
            ];
        }

        return [
            'allowed' => true,
            'remaining' => $maxAttempts - $attempts - 1,
            'reset_at' => $firstAttempt + $windowSeconds,
            'blocked' => false
        ];
    }

    /**
     * Record an attempt
     */
    public static function recordAttempt($identifier, $action, $success = false)
    {
        if ($success) {
            self::reset($identifier, $action);
            return;
        }

        $db = self::getDB();

        $stmt = $db->prepare("SELECT id FROM rate_limits WHERE identifier = ? AND action = ?");
        $stmt->execute([$identifier, $action]);
        $record = $stmt->fetch();

        if ($record) {
            $stmt = $db->prepare("
                UPDATE rate_limits 
                SET attempts = attempts + 1, last_attempt_at = NOW()
                WHERE identifier = ? AND action = ?
            ");
            $stmt->execute([$identifier, $action]);
        } else {
            $stmt = $db->prepare("
                INSERT INTO rate_limits (identifier, action, attempts, first_attempt_at, last_attempt_at)
                VALUES (?, ?, 1, NOW(), NOW())
            ");
            $stmt->execute([$identifier, $action]);
        }
    }

    private static function block($identifier, $action, $duration)
    {
        $db = self::getDB();
        $stmt = $db->prepare("
            UPDATE rate_limits 
            SET blocked_until = DATE_ADD(NOW(), INTERVAL ? SECOND)
            WHERE identifier = ? AND action = ?
        ");
        $stmt->execute([$duration, $identifier, $action]);

        Logger::log("Rate limit block", 'WARNING', [
            'identifier' => $identifier,
            'action' => $action,
            'duration' => $duration
        ]);
    }

    public static function reset($identifier, $action)
    {
        $db = self::getDB();
        $stmt = $db->prepare("DELETE FROM rate_limits WHERE identifier = ? AND action = ?");
        $stmt->execute([$identifier, $action]);
    }

    private static function calculateBackoff($attempts)
    {
        // Exponential backoff: 5, 15, 30, 60 minutes
        $multipliers = [5, 15, 30, 60];
        $index = min($attempts - 5, count($multipliers) - 1);
        return $multipliers[$index] * 60;
    }

    public static function cleanup($olderThanDays = 7)
    {
        $db = self::getDB();
        $stmt = $db->prepare("
            DELETE FROM rate_limits 
            WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)
            AND blocked_until IS NULL
        ");
        $stmt->execute([$olderThanDays]);
        return $stmt->rowCount();
    }
}

// Initialize table on first load
RateLimiter::ensureTable();
?>