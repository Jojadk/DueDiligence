<?php
/**
 * NDA Privacy Helper Functions
 * Controls access to NDA/Restricted projects
 */

class NDAPrivacy
{

    /**
     * Check if user can view NDA project
     * @param array $user Current user data
     * @param array $project Project data
     * @return bool
     */
    public static function canViewNDAProject($user, $project)
    {
        // Not NDA restricted - everyone can see
        if (!$project['nda_required']) {
            return true;
        }

        // Admin and developers can always see NDA projects
        if (in_array($user['role'], ['admin', 'developer'])) {
            return true;
        }

        // Project manager can see their own projects
        if (isset($project['project_manager_id']) && $project['project_manager_id'] == $user['id']) {
            return true;
        }

        // Project creator can see
        if (isset($project['created_by']) && $project['created_by'] == $user['id']) {
            return true;
        }

        return false;
    }

    /**
     * Filter projects array based on NDA privacy
     * @param array $projects Array of projects
     * @param array $user Current user data
     * @return array Filtered projects
     */
    public static function filterProjects($projects, $user)
    {
        return array_filter($projects, function ($project) use ($user) {
            return self::canViewNDAProject($user, $project);
        });
    }

    /**
     * Get SQL WHERE clause for NDA filtering
     * @param array $user Current user data
     * @param string $table_alias Table alias (default: 'p')
     * @return string SQL WHERE clause
     */
    public static function getSQLFilter($user, $table_alias = 'p')
    {
        // Admin and developers see everything
        if (in_array($user['role'], ['admin', 'developer'])) {
            return '1=1';
        }

        $userId = (int) $user['id'];

        return "
            (
                {$table_alias}.nda_required = 0 
                OR {$table_alias}.project_manager_id = {$userId}
                OR {$table_alias}.created_by = {$userId}
            )
        ";
    }

    /**
     * Get dashboard statistics with NDA filtering
     * @param mysqli $db Database connection
     * @param array $user Current user data
     * @return array Statistics
     */
    public static function getDashboardStats($db, $user)
    {
        $filter = self::getSQLFilter($user, 'p');

        $query = "
            SELECT 
                COUNT(*) as total_projects,
                SUM(CASE WHEN status = 'open' THEN 1 ELSE 0 END) as active_projects,
                SUM(CASE WHEN status = 'closed' THEN 1 ELSE 0 END) as completed_projects,
                SUM(CASE WHEN status = 'on_hold' THEN 1 ELSE 0 END) as on_hold_projects,
                SUM(CASE WHEN nda_required = 1 THEN 1 ELSE 0 END) as nda_projects
            FROM dd_projects p
            WHERE {$filter}
        ";

        $result = $db->query($query);
        return $result ? $result->fetch_assoc() : [];
    }
}
