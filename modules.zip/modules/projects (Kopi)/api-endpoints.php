<?php
// modules/projects/api-endpoints.php

function handle_api($action, $db)
{
    switch ($action) {
        case 'list':
            return list_projects_paged($db);
        case 'get':
            return get_project($db);
        case 'create':
            return create_project_module($db);
        case 'update':
            return update_project_module($db);
        case 'delete':
            return delete_project_module($db);
        case 'get_condition_distribution':
            return get_condition_distribution($db);
        case 'get_dashboard_stats':
            return get_project_stats($db);
        default:
            throw new Exception("Unknown projects action: " . $action);
    }
}

function list_projects_paged($db)
{
    $page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int) $_GET['limit'] : 20;
    $sort = isset($_GET['sort']) ? $_GET['sort'] : 'created_at';
    $order = isset($_GET['order']) && strtoupper($_GET['order']) === 'ASC' ? 'ASC' : 'DESC';
    $search = isset($_GET['search']) ? $_GET['search'] : '';

    $offset = ($page - 1) * $limit;

    // Allowed sort columns
    $allowedSorts = ['id', 'name', 'status', 'start_date', 'created_at', 'customer_name'];
    if (!in_array($sort, $allowedSorts)) {
        $sort = 'created_at';
    }

    // Alias handling
    $orderBy = "p.$sort";
    if ($sort === 'customer_name') {
        $orderBy = "c.name";
    }

    $whereClause = "WHERE 1=1";
    $params = [];

    if (!empty($search)) {
        $whereClause .= " AND (p.name LIKE ? OR c.name LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }

    if (!empty($_GET['customer_id'])) {
        $whereClause .= " AND p.customer_id = ?";
        $params[] = (int) $_GET['customer_id'];
    }

    // Count Total
    $countStmt = $db->prepare("SELECT COUNT(*) FROM dd_projects p LEFT JOIN dd_customers c ON p.customer_id = c.id $whereClause");
    $countStmt->execute($params);
    $total = $countStmt->fetchColumn();

    // Fetch Data
    $query = "
        SELECT p.*, c.name as customer_name 
        FROM dd_projects p 
        LEFT JOIN dd_customers c ON p.customer_id = c.id 
        $whereClause 
        ORDER BY $orderBy $order 
        LIMIT $limit OFFSET $offset
    ";

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $data = $stmt->fetchAll();

    return [
        'data' => $data,
        'pagination' => [
            'total' => (int) $total,
            'page' => $page,
            'limit' => $limit,
            'last_page' => ceil($total / $limit)
        ]
    ];
}

// ... existing imports ...

// Helper to ensure meta table exists (lazy init)
function ensure_project_meta_table($db)
{
    static $checked = false;
    if ($checked)
        return;

    // Check if exists
    try {
        $result = $db->query("SHOW TABLES LIKE 'dd_project_meta'");
        if ($result->rowCount() > 0) {
            $checked = true;
            return;
        }
    } catch (Exception $e) {
    }

    // Create if not
    $sql = "CREATE TABLE IF NOT EXISTS dd_project_meta (
        id INT AUTO_INCREMENT PRIMARY KEY,
        project_id INT NOT NULL,
        meta_key VARCHAR(50) NOT NULL,
        meta_value TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY unique_project_key (project_id, meta_key),
        FOREIGN KEY (project_id) REFERENCES dd_projects(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
    $db->exec($sql);
    $checked = true;
}

function get_project_meta($db, $projectId)
{
    ensure_project_meta_table($db);
    $stmt = $db->prepare("SELECT meta_key, meta_value FROM dd_project_meta WHERE project_id = ?");
    $stmt->execute([$projectId]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $meta = [];
    foreach ($rows as $row) {
        $val = $row['meta_value'];
        // Try simple JSON decode
        $decoded = json_decode($val, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            $val = $decoded;
        }
        $meta[$row['meta_key']] = $val;
    }
    return $meta;
}

function save_project_meta($db, $projectId, $key, $value)
{
    ensure_project_meta_table($db);
    if (is_array($value) || is_object($value)) {
        $value = json_encode($value);
    }
    $stmt = $db->prepare("INSERT INTO dd_project_meta (project_id, meta_key, meta_value) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value)");
    $stmt->execute([$projectId, $key, $value]);
}

function get_project($db)
{
    $id = (int) ($_GET['id'] ?? 0);
    if (!$id)
        throw new Exception("Project ID required");

    $stmt = $db->prepare("SELECT p.*, c.name as customer_name FROM dd_projects p LEFT JOIN dd_customers c ON p.customer_id = c.id WHERE p.id = ?");
    $stmt->execute([$id]);
    $res = $stmt->fetch(PDO::FETCH_ASSOC); // Fetch as associative array
    if (!$res)
        throw new Exception("Project not found");

    // Fetch Custom Fields
    $stmtFields = $db->prepare("SELECT * FROM dd_project_custom_fields WHERE project_id = ? ORDER BY sort_order ASC, id ASC");
    $stmtFields->execute([$id]);
    $res['custom_fields'] = $stmtFields->fetchAll(PDO::FETCH_ASSOC);

    // Fetch Meta Data (Report Config, Constants, Capex/Opex)
    $meta = get_project_meta($db, $id);

    // Merge meta keys into response if they exist in standard keys
    // Defined standard keys the JS expects
    $standardMeta = ['report_config', 'constants', 'capex_opex', 'dashboard_config'];
    foreach ($standardMeta as $key) {
        if (isset($meta[$key])) {
            $res[$key] = $meta[$key];
        } else {
            // Provide sensible defaults if missing to prevent JS read property of undefined errors
            if ($key === 'report_config')
                $res[$key] = [];
            if ($key === 'constants')
                $res[$key] = [];
            if ($key === 'capex_opex')
                $res[$key] = [];
        }
    }

    // Try to fetch System Constants if project constants are empty?
    // User requested "fetch project info... like project tab".
    // We already fetch custom fields. The JS also expects 'constants.currency' etc.
    // If we have no local constants, we might want to inject defaults?
    // JS defaults seem fine, but let's ensure we return objects.

    return $res;
}

function create_project_module($db)
{
    require_permission('allow_manage_projects');
    $data = json_decode(file_get_contents('php://input'), true);
    if (empty($data['name']) || empty($data['customer_id'])) {
        throw new Exception("Name and Customer ID required");
    }

    $project_manager_id = !empty($data['project_manager_id']) ? $data['project_manager_id'] : null;
    $qa_id = !empty($data['qa_id']) ? $data['qa_id'] : null;
    $nda_required = $data['nda_required'] ?? 0;

    $stmt = $db->prepare("INSERT INTO dd_projects (customer_id, name, description, status, start_date, created_by, nda_required, project_manager_id, qa_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $data['customer_id'],
        $data['name'],
        $data['description'] ?? '',
        $data['status'] ?? 'open',
        $data['start_date'] ?? null,
        $_SESSION['user_id'] ?? 0,
        $nda_required,
        $project_manager_id,
        $qa_id
    ]);

    $projectId = $db->lastInsertId();

    // Save Meta Data
    foreach (['report_config', 'constants', 'capex_opex'] as $key) {
        if (isset($data[$key])) {
            save_project_meta($db, $projectId, $key, $data[$key]);
        }
    }

    // Handle Custom Fields (Legacy / Parallel implementation)
    if (!empty($data['custom_fields']) && is_array($data['custom_fields'])) {
        $stmtField = $db->prepare("INSERT INTO dd_project_custom_fields (project_id, label, type, options, sort_order) VALUES (?, ?, ?, ?, ?)");
        foreach ($data['custom_fields'] as $i => $field) {
            if (empty($field['label']))
                continue;
            $stmtField->execute([
                $projectId,
                $field['label'],
                $field['type'] ?? 'text',
                $field['options'] ?? null,
                $i
            ]);
        }
    }

    return ['id' => $projectId, 'message' => 'Project created'];
}

function update_project_module($db)
{
    require_permission('allow_manage_projects');
    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['id'] ?? 0;
    if (!$id)
        throw new Exception("ID required");

    $project_manager_id = !empty($data['project_manager_id']) ? $data['project_manager_id'] : null;
    $qa_id = !empty($data['qa_id']) ? $data['qa_id'] : null;
    $nda_required = $data['nda_required'] ?? 0;

    $stmt = $db->prepare("UPDATE dd_projects SET name = ?, description = ?, status = ?, start_date = ?, nda_required = ?, project_manager_id = ?, qa_id = ? WHERE id = ?");
    $stmt->execute([
        $data['name'],
        $data['description'] ?? '',
        $data['status'] ?? 'open',
        $data['start_date'] ?? null,
        $nda_required,
        $project_manager_id,
        $qa_id,
        $id
    ]);

    // Save Meta Data
    foreach (['report_config', 'constants', 'capex_opex'] as $key) {
        if (isset($data[$key])) {
            save_project_meta($db, $id, $key, $data[$key]);
        }
    }

    // Sync Custom Fields
    $db->prepare("DELETE FROM dd_project_custom_fields WHERE project_id = ?")->execute([$id]);
    if (!empty($data['custom_fields']) && is_array($data['custom_fields'])) {
        $stmtField = $db->prepare("INSERT INTO dd_project_custom_fields (project_id, label, type, options, sort_order) VALUES (?, ?, ?, ?, ?)");
        foreach ($data['custom_fields'] as $i => $field) {
            if (empty($field['label']))
                continue;
            $stmtField->execute([
                $id,
                $field['label'],
                $field['type'] ?? 'text',
                $field['options'] ?? null,
                $i
            ]);
        }
    }

    return ['message' => 'Project updated'];
}

function delete_project_module($db)
{
    require_permission('allow_manage_projects');
    $id = (int) ($_GET['id'] ?? 0);
    if (!$id)
        throw new Exception("ID required");

    $stmt = $db->prepare("DELETE FROM dd_projects WHERE id = ?");
    $stmt->execute([$id]);
    // Cascade delete handles meta table? Yes if FK set. 
    // If ensuring meta table with create_meta_table, we added ON DELETE CASCADE.

    return ['message' => 'Project deleted'];
}

function get_project_stats($db)
{
    $id = (int) ($_GET['id'] ?? 0);
    if (!$id)
        return ['buildings' => 0, 'elements' => 0, 'progress' => 0];

    // Buildings Count
    $stmt = $db->prepare("SELECT COUNT(*) FROM dd_buildings WHERE project_id = ?");
    $stmt->execute([$id]);
    $buildings = $stmt->fetchColumn();

    // Elements Count & Progress
    $stmt = $db->prepare("
        SELECT 
            COUNT(*) as total,
            COUNT(CASE WHEN condition_rating IS NOT NULL AND condition_rating > 0 THEN 1 END) as completed
        FROM dd_building_Elements e 
        LEFT JOIN dd_buildings b ON e.building_id = b.id 
        WHERE b.project_id = ?
    ");
    $stmt->execute([$id]);
    $res = $stmt->fetch();

    $elements = $res['total'];
    $completed = $res['completed'];
    $progress = $elements > 0 ? round(($completed / $elements) * 100) : 0;

    return [
        'buildings' => (int) $buildings,
        'elements' => (int) $elements,
        'progress' => (int) $progress
    ];
}

function get_condition_distribution($db)
{
    $projectId = (int) ($_GET['bind_id'] ?? 0);

    $stmt = $db->prepare(
        "SELECT e.condition_rating, COUNT(*) as count 
         FROM dd_building_Elements e 
         LEFT JOIN dd_buildings b ON e.building_id = b.id 
         WHERE b.project_id = ? 
         GROUP BY e.condition_rating"
    );
    $stmt->execute([$projectId]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $distribution = ["1" => 0, "2" => 0, "3" => 0, "4" => 0, "5" => 0];
    foreach ($rows as $row) {
        if (isset($distribution[$row['condition_rating']])) {
            $distribution[$row['condition_rating']] = (int) $row['count'];
        }
    }

    return $distribution;
}
?>