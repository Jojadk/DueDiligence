<div class="dd-card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
        <div>
            <h2 style="margin: 0;">Projects</h2>
            <p style="margin: 0.25rem 0 0 0; color: var(--gray-500); font-size: 0.875rem;"><span id="project-count">0</span> projects</p>
        </div>
        <button id="btn-add-project-main" name="btn_add_project_main" class="dd-btn dd-btn-primary" onclick="App.customer.showAddProjectModal()"> <!-- Reuse customer wizard or create new? Reuse seems fine -->
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
            New Project
        </button>
    </div>

    <div style="display: flex; gap: 1rem; margin-bottom: 1rem;">
        <input type="text" id="projects-list-search" name="projects_list_search" class="dd-input" placeholder="Search projects..." style="flex: 1;" onkeyup="App.projects.handleSearch(this.value)">
    </div>

    <div class="dd-table-wrapper">
        <table id="projects-list-table" name="projects_list_table" class="dd-table">
            <thead>
                <tr>
                    <th onclick="App.projects.sort('id')" style="cursor:pointer;" data-sort="id">ID <span class="sort-icon">⇅</span></th>
                    <th onclick="App.projects.sort('name')" style="cursor:pointer;" data-sort="name">Project Name <span class="sort-icon">⇅</span></th>
                    <th onclick="App.projects.sort('customer_name')" style="cursor:pointer;" data-sort="customer_name">Customer <span class="sort-icon">⇅</span></th>
                    <th onclick="App.projects.sort('status')" style="cursor:pointer;" data-sort="status">Status <span class="sort-icon">⇅</span></th>
                    <th onclick="App.projects.sort('start_date')" style="cursor:pointer;" data-sort="start_date">Start Date <span class="sort-icon">⇅</span></th>
                    <th style="text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody id="project-table-body">
                <tr><td colspan="6" style="text-align: center; padding: 2rem; color: var(--gray-500);">Loading...</td></tr>
            </tbody>
        </table>
    </div>
    <div id="project-pagination"></div>
</div>

<script>
    // SPA-compatible: Run immediately since DOMContentLoaded has already fired
    (function() {
        const checkAndInit = () => {
            if (App.projects && typeof App.projects.init === 'function') {
                App.projects.init();
            } else {
                setTimeout(checkAndInit, 50);
            }
        };
        checkAndInit();
    })();
</script>
