<?php
// modules/sync/api.php - Unified Sync API for Collaboration System

/**
 * Handle API requests for the Sync module.
 * @param string $action
 * @param PDO $db
 * @return array|mixed
 * @throws Exception
 */
function handle_api(string $action, PDO $db)
{
    // Ensure tables exist (one-time check or migration strategy)
    // For performance, this strictly shouldn't be here every time, but for this task/setup it's safe.
    ensure_sync_tables($db);

    switch ($action) {
        case 'get_state':
            return sync_get_state($db);
        case 'acquire':
            return sync_acquire_lock($db);
        case 'release':
            return sync_release_lock($db);
        case 'heartbeat':
            return sync_heartbeat($db);
        case 'log_change':
            return sync_log_change($db);
        case 'cleanup':
            return sync_cleanup($db);
        default:
            throw new Exception("Unknown sync action: $action");
    }
}

/**
 * Ensure necessary tables exist.
 */
function ensure_sync_tables(PDO $db)
{
    // Check if table exists to avoid costly CREATE IF NOT EXISTS on every request (though MySQL handles it okay)
    // We'll rely on CREATE TABLE IF NOT EXISTS.
    $sql = "
    CREATE TABLE IF NOT EXISTS record_locks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        record_type VARCHAR(50) NOT NULL,
        record_id INT NOT NULL,
        user_id INT NOT NULL,
        locked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        field_name VARCHAR(100),
        client_id VARCHAR(100),
        UNIQUE KEY unique_lock (record_type, record_id, field_name)
    );
    CREATE TABLE IF NOT EXISTS record_changes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        record_type VARCHAR(50) NOT NULL,
        record_id INT NOT NULL,
        field_name VARCHAR(100),
        changed_by_user_id INT,
        changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        change_type VARCHAR(20) DEFAULT 'update',
        details TEXT
    );
    ";
    // Indexes might fail if they exist, so we skip explicit index creation in this quick check
    // or wrap in try-catch.
    try {
        $db->exec($sql);
    } catch (Exception $e) {
        // Ignore if exists
    }
}

/**
 * GET_STATE: Validates local state against server state.
 * Returns changes since `since` timestamp, active locks status, and notifications.
 */
function sync_get_state(PDO $db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $client_id = $data['client_id'] ?? '';
    $since = $data['since'] ?? date('Y-m-d H:i:s', strtotime('-1 hour')); // Default to 1 hour ago if missing
    $record_type = $data['record_type'] ?? '';
    $record_id = $data['record_id'] ?? 0;

    // 1. Get Changes since timestamp
    $stmt = $db->prepare("
        SELECT c.*, u.name as changed_by_name 
        FROM record_changes c
        LEFT JOIN dd_users u ON c.changed_by_user_id = u.id
        WHERE c.record_type = ? AND c.record_id = ? AND c.changed_at > ?
        ORDER BY c.changed_at ASC
    ");
    $stmt->execute([$record_type, $record_id, $since]);
    $changes = $stmt->fetchAll();

    // 2. Get Locks Status for requested IDs (or all for this record)
    $stmt = $db->prepare("
        SELECT l.*, u.name as locked_by_user_name 
        FROM record_locks l
        LEFT JOIN dd_users u ON l.user_id = u.id
        WHERE l.record_type = ? AND l.record_id = ?
    ");
    $stmt->execute([$record_type, $record_id]);
    $rawLocks = $stmt->fetchAll();

    $locks = [];
    $current_user_id = $_SESSION['user_id'] ?? 0;

    foreach ($rawLocks as $l) {
        $key = "{$l['record_type']}:{$l['record_id']}:{$l['field_name']}";
        $is_self = ($l['client_id'] === $client_id) || ($l['user_id'] == $current_user_id && $client_id === '');

        $locks[$key] = [
            'locked' => true,
            'by_self' => $is_self,
            'by_user' => $l['locked_by_user_name'],
            'locked_at' => $l['locked_at'],
            'is_stale' => (strtotime($l['last_activity']) < time() - 120) // 120s timeout
        ];
    }

    // 3. Notifications (Mock example or real system)
    // Could hook into a notifications table if exists
    $notifications = [];

    return [
        'timestamp' => date('Y-m-d H:i:s'),
        'changes' => $changes,
        'locks' => $locks,
        'notifications' => $notifications
    ];
}

/**
 * ACQUIRE: Try to lock a field.
 */
function sync_acquire_lock(PDO $db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $client_id = $data['client_id'] ?? '';
    $record_type = $data['record_type'] ?? '';
    $record_id = $data['record_id'] ?? 0;
    $field_name = $data['field_name'] ?? '';
    $user_id = $_SESSION['user_id'] ?? 0;

    if (!$user_id)
        throw new Exception("Authentication required");

    // Cleanup stale locks for this field first
    $db->prepare("DELETE FROM record_locks WHERE record_type=? AND record_id=? AND field_name=? AND last_activity < NOW() - INTERVAL 120 SECOND")
        ->execute([$record_type, $record_id, $field_name]);

    try {
        $stmt = $db->prepare("
            INSERT INTO record_locks (record_type, record_id, user_id, field_name, client_id, last_activity)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([$record_type, $record_id, $user_id, $field_name, $client_id]);
        return ['success' => true, 'status' => 'acquired'];
    } catch (PDOException $e) {
        // Duplicate entry means locked by someone else
        // Check who has it
        $stmt = $db->prepare("SELECT u.name FROM record_locks l JOIN dd_users u ON l.user_id = u.id WHERE record_type=? AND record_id=? AND field_name=?");
        $stmt->execute([$record_type, $record_id, $field_name]);
        $owner = $stmt->fetchColumn();

        // If it's me (same user, different client_id? or same), refresh it?
        // Actually, 'client_id' check is better. If same user but different tab, we treat as separate usually, or same.
        // For simplicity: deny if exists.
        return ['success' => false, 'status' => 'denied', 'locked_by' => $owner];
    }
}

/**
 * RELEASE: Release a lock.
 */
function sync_release_lock(PDO $db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $client_id = $data['client_id'] ?? '';
    $record_type = $data['record_type'] ?? '';
    $record_id = $data['record_id'] ?? 0;
    $field_name = $data['field_name'] ?? '';
    $user_id = $_SESSION['user_id'] ?? 0;

    $stmt = $db->prepare("DELETE FROM record_locks WHERE record_type=? AND record_id=? AND field_name=? AND (client_id=? OR user_id=?)");
    $stmt->execute([$record_type, $record_id, $field_name, $client_id, $user_id]);

    return ['success' => true];
}

/**
 * HEARTBEAT: Update activity for locks.
 */
function sync_heartbeat(PDO $db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $client_id = $data['client_id'] ?? '';
    $locks = $data['locks'] ?? [];

    if (empty($locks))
        return ['success' => true];

    $stmt = $db->prepare("UPDATE record_locks SET last_activity = NOW() WHERE record_type=? AND record_id=? AND field_name=? AND client_id=?");

    foreach ($locks as $l) {
        $stmt->execute([
            $l['record_type'],
            $l['record_id'],
            $l['field_name'],
            $client_id
        ]);
    }

    return ['success' => true];
}

/**
 * LOG_CHANGE: Manually log a change (or used by backend triggers).
 */
function sync_log_change(PDO $db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $record_type = $data['record_type'] ?? '';
    $record_id = $data['record_id'] ?? 0;
    $field_name = $data['field_name'] ?? '';
    $change_type = $data['change_type'] ?? 'update';
    $details = $data['details'] ?? '';
    $user_id = $_SESSION['user_id'] ?? 0;

    $stmt = $db->prepare("
        INSERT INTO record_changes (record_type, record_id, field_name, changed_by_user_id, change_type, details)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([$record_type, $record_id, $field_name, $user_id, $change_type, $details]);

    return ['success' => true];
}

/**
 * CLEANUP: Remove stale locks (Admin or Auto task).
 */
function sync_cleanup(PDO $db)
{
    $stmt = $db->prepare("DELETE FROM record_locks WHERE last_activity < NOW() - INTERVAL 120 SECOND");
    $stmt->execute();
    return ['success' => true, 'deleted' => $stmt->rowCount()];
}
?>