<div class="dd-card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
        <div>
            <h2 style="margin: 0;">Buildings</h2>
            <p style="margin: 0.25rem 0 0 0; color: var(--gray-500); font-size: 0.875rem;"><span id="building-count">0</span> buildings</p>
        </div>
        <button id="btn-add-building" name="btn_add_building" class="dd-btn dd-btn-primary" onclick="App.buildings.showAddModal()">
            <span class="nav-icon" data-icon="add"></span>
            New Building
        </button>
    </div>

    <input type="text" id="buildings-search" name="buildings_search" class="dd-input" placeholder="Search buildings by name, address, or project..." style="margin-bottom: 1rem;" onkeyup="App.buildings.handleSearch(this.value)">

    <div class="dd-table-wrapper">
        <table id="buildings-table" name="buildings_table" class="dd-table">
            <thead>
                <tr>
                    <th onclick="App.buildings.sort('name')" style="cursor:pointer;" data-sort="name">Name <span class="sort-icon">⇅</span></th>
                    <th onclick="App.buildings.sort('address')" style="cursor:pointer;" data-sort="address">Address <span class="sort-icon">⇅</span></th>
                    <th onclick="App.buildings.sort('city')" style="cursor:pointer;" data-sort="city">City <span class="sort-icon">⇅</span></th>
                    <th onclick="App.buildings.sort('project_name')" style="cursor:pointer;" data-sort="project_name">Project <span class="sort-icon">⇅</span></th>
                    <th style="text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody id="buildings-list-body">
                <tr><td colspan="5" style="text-align: center; padding: 2rem; color: var(--gray-500);">Loading...</td></tr>
            </tbody>
        </table>
    </div>
    <div id="building-pagination"></div>
</div>

<script>
    // SPA-compatible: Run immediately since DOMContentLoaded has already fired
    (function() {
        const checkAndInit = () => {
            if (App.buildings && typeof App.buildings.init === 'function') {
                App.buildings.init();
            } else {
                setTimeout(checkAndInit, 50);
            }
        };
        checkAndInit();
    })();
</script>
