<?php
// modules/buildings/api-endpoints.php

function handle_api($action, $db)
{
    switch ($action) {
        case 'list':
            return list_buildings($db);
        case 'get':
            return get_building($db);
        case 'create':
            return create_building($db);
        case 'update':
            return update_building($db);
        case 'delete':
            return delete_building($db);
        case 'update_sort_order':
            return update_building_sort_order($db);
        default:
            throw new Exception("Unknown building action: " . $action);
    }
}

function list_buildings($db)
{
    $page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int) $_GET['limit'] : 20;
    $sort = isset($_GET['sort']) ? $_GET['sort'] : 'created_at';
    $order = isset($_GET['order']) && strtoupper($_GET['order']) === 'ASC' ? 'ASC' : 'DESC';
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $projectId = isset($_GET['project_id']) ? (int) $_GET['project_id'] : null;

    $offset = ($page - 1) * $limit;

    // Allowed sort columns
    $allowedSorts = ['id', 'name', 'address', 'city', 'project_name', 'created_at'];
    if (!in_array($sort, $allowedSorts)) {
        $sort = 'created_at';
    }

    $orderBy = "b.$sort";
    if ($sort === 'project_name')
        $orderBy = "p.name";

    $whereClause = "WHERE 1=1";
    $params = [];

    if ($projectId) {
        $whereClause .= " AND b.project_id = ?";
        $params[] = $projectId;
    }

    if (!empty($search)) {
        $whereClause .= " AND (b.name LIKE ? OR b.address LIKE ? OR b.city LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }

    // Count Total
    $countStmt = $db->prepare("SELECT COUNT(*) FROM dd_buildings b LEFT JOIN dd_projects p ON b.project_id = p.id $whereClause");
    $countStmt->execute($params);
    $total = $countStmt->fetchColumn();

    // Fetch Data
    $query = "
        SELECT b.*, p.name as project_name 
        FROM dd_buildings b
        LEFT JOIN dd_projects p ON b.project_id = p.id
        $whereClause
        ORDER BY $orderBy $order
        LIMIT $limit OFFSET $offset
    ";

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $data = $stmt->fetchAll();

    return [
        'data' => $data,
        'pagination' => [
            'total' => (int) $total,
            'page' => $page,
            'limit' => $limit,
            'last_page' => ceil($total / $limit)
        ]
    ];
}

function get_building($db)
{
    $id = (int) ($_GET['id'] ?? 0);
    if (!$id)
        throw new Exception("Building ID required");

    $stmt = $db->prepare("
        SELECT b.*, p.name as project_name 
        FROM dd_buildings b 
        LEFT JOIN dd_projects p ON b.project_id = p.id 
        WHERE b.id = ?
    ");
    $stmt->execute([$id]);
    $res = $stmt->fetch(PDO::FETCH_ASSOC);
    return $res;
}

function create_building($db)
{
    require_permission('allow_manage_projects'); // Assuming basic project mgmt allows building mgmt for now

    $data = json_decode(file_get_contents('php://input'), true);
    $projectId = $data['project_id'] ?? 0;
    $name = $data['name'] ?? '';
    $address = $data['address'] ?? '';
    $postalCode = $data['postal_code'] ?? '';
    $city = $data['city'] ?? '';
    $country = $data['country'] ?? 'Denmark';

    if (!$projectId || !$name)
        throw new Exception("Project ID and Name are required");

    $stmt = $db->prepare("
        INSERT INTO dd_buildings (project_id, name, address, postal_code, city, country, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([$projectId, $name, $address, $postalCode, $city, $country, $_SESSION['user_id'] ?? null]);

    return ['id' => $db->lastInsertId(), 'message' => 'Building created successfully'];
}

function update_building($db)
{
    require_permission('allow_manage_projects');

    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['id'] ?? 0;
    $name = $data['name'] ?? '';
    $address = $data['address'] ?? '';
    $postalCode = $data['postal_code'] ?? '';
    $city = $data['city'] ?? '';
    $country = $data['country'] ?? '';
    $description = $data['description'] ?? '';

    if (!$id || !$name)
        throw new Exception("ID and Name are required");

    $stmt = $db->prepare("
        UPDATE dd_buildings 
        SET name = ?, address = ?, postal_code = ?, city = ?, country = ?, description = ?
        WHERE id = ?
    ");
    $stmt->execute([$name, $address, $postalCode, $city, $country, $description, $id]);

    return ['message' => 'Building updated successfully'];
}

function delete_building($db)
{
    require_permission('allow_manage_projects');

    $id = (int) ($_GET['id'] ?? 0);
    if (!$id)
        throw new Exception("ID required");

    $stmt = $db->prepare("DELETE FROM dd_buildings WHERE id = ?");
    $stmt->execute([$id]);

    return ['message' => 'Building deleted successfully'];
}

function update_building_sort_order($db)
{
    require_permission('allow_manage_projects');

    $data = json_decode(file_get_contents('php://input'), true);
    $items = $data['items'] ?? [];

    if (empty($items)) {
        throw new Exception("No items to reorder");
    }

    $db->beginTransaction();
    try {
        $stmt = $db->prepare("UPDATE dd_buildings SET sort_order = ? WHERE id = ?");
        foreach ($items as $item) {
            $stmt->execute([(int) $item['order'], (int) $item['id']]);
        }
        $db->commit();
        return ['message' => 'Sort order updated'];
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}
?>