<?php
// modules/reports/api-endpoints.php

function handle_api($action, $db)
{
    switch ($action) {
        case 'get_full_summary':
            return get_full_summary($db);
        case 'export_pdf':
            $projectId = (int) ($_GET['project_id'] ?? 0);
            header('Location: api.php?module=elements&action=get_html_report&project_id=' . $projectId);
            exit;
        case 'export_excel':
            return export_csv($db);
        default:
            throw new Exception("Unknown report action: " . $action);
    }
}

function export_csv($db)
{
    $projectId = (int) ($_GET['project_id'] ?? 0);
    if (!$projectId)
        throw new Exception("Project ID required");

    // Use centralized batch fetching to ensure correct rounding and bucket calculation
    $buildings = get_project_data_batch($db, $projectId);

    $flatRows = [];
    foreach ($buildings as $b) {
        $buildingName = $b['name'];

        // Recursive helper to flatten the element tree for CSV
        $flatten = function ($elements) use (&$flatten, &$flatRows, $buildingName) {
            foreach ($elements as $el) {
                // Prepare CSV Row
                $flatRows[] = [
                    'Bygning' => $buildingName,
                    'Bygningsdel' => $el['name'],
                    'Observation' => $el['description'],
                    'Anbefaling' => $el['recommendation'],
                    'Mængde' => $el['quantity'],
                    'Enhed' => $el['unit'],
                    'Risiko' => $el['risk_level'],
                    'Tilstand' => $el['condition_rating'],
                    'Kvalitet' => $el['quality_rating'],
                    'Budget_Total' => $el['total_budget'],
                    'Aar_0_1' => $el['cost_buckets']['0_1'],
                    'Aar_1_2' => $el['cost_buckets']['1_2'],
                    'Aar_3_5' => $el['cost_buckets']['3_5'],
                    'Aar_5_10' => $el['cost_buckets']['5_10']
                ];

                if (!empty($el['children'])) {
                    $flatten($el['children']);
                }
            }
        };

        if (!empty($b['tree'])) {
            $flatten($b['tree']);
        }
    }

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=projekt_' . $projectId . '_export.csv');

    $output = fopen('php://output', 'w');
    fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF)); // BOM for Excel

    if (!empty($flatRows)) {
        // Headers
        fputcsv($output, array_keys($flatRows[0]), ';');
        // Data
        foreach ($flatRows as $row) {
            fputcsv($output, $row, ';');
        }
    }
    fclose($output);
    exit;
}

function get_full_summary($db)
{
    $projectId = (int) ($_GET['project_id'] ?? 0);
    if (!$projectId)
        throw new Exception("Project ID required");

    // Use centralized batch fetching to ensure correct rounding (roundup)
    $buildings = get_project_data_batch($db, $projectId);

    $flatElements = [];
    foreach ($buildings as $b) {
        $buildingName = $b['name'];

        // Recursive helper to flatten the element tree
        $flatten = function ($elements) use (&$flatten, &$flatElements, $buildingName) {
            foreach ($elements as $el) {
                // Copy values but keep it flat for the report table
                $row = $el;
                $row['building_name'] = $buildingName;

                // Ensure estimated_cost is present (calculated in get_project_data_batch)
                $row['estimated_cost'] = $el['total_budget'] ?? 0;

                $flatElements[] = $row;

                if (!empty($el['children'])) {
                    $flatten($el['children']);
                }
            }
        };

        if (!empty($b['tree'])) {
            $flatten($b['tree']);
        }
    }

    return $flatElements;
}
?>