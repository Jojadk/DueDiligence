<div class="dd-report">
    <h2>Technical Audit Summary</h2>
    <div id="report-filters" style="margin-bottom: 2rem; padding: 1rem; background: var(--bg-muted); border-radius: 4px;">
        <label>Select Project:</label>
        <select id="report-project-select" class="dd-input-sm" style="width: 200px;" onchange="App.reports.loadProjectReport(this.value)">
            <option value="">-- Select --</option>
        </select>
        <button class="dd-btn-secondary dd-btn-sm" onclick="window.print()" style="float: right; display:flex; align-items:center; gap:6px;">
            <span class="nav-icon" data-icon="print"></span> Print Report
        </button>
    </div>

    <div id="report-results">
        <p class="text-muted">Select a project to generate report.</p>
    </div>
</div>

<script>
    App.reports.init();
</script>
