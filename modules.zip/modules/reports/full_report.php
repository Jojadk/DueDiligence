<?php
// modules/reports/full_report.php
require_once __DIR__ . '/../../core/constants.php';
require_once __DIR__ . '/../../core/security.php';
require_once __DIR__ . '/../../core/core.php';

// Authentication Check
if (!is_authenticated()) {
    die("Access denied. Please login.");
}

$db = get_db_connection();
$projectId = (int) ($_GET['project_id'] ?? 0);

if (!$projectId) {
    die("Project ID required");
}

// 1. Fetch Project & Client Info
$stmt = $db->prepare("
    SELECT p.*, c.name as client_name, c.address as client_address 
    FROM dd_projects p 
    JOIN dd_customers c ON p.customer_id = c.id 
    WHERE p.id = ?
");
$stmt->execute([$projectId]);
$project = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$project) {
    die("Project not found");
}

// 2. Fetch Buildings
$stmt = $db->prepare("SELECT * FROM dd_buildings WHERE project_id = ? ORDER BY name ASC");
$stmt->execute([$projectId]);
$buildings = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($buildings as &$building) {
    $buildingId = $building['id'];

    // 3. Fetch Elements for this building
    $stmt = $db->prepare("
        SELECT e.* 
        FROM dd_building_Elements e
        WHERE e.building_id = ?
        ORDER BY e.sort_order ASC, e.id ASC
    ");
    $stmt->execute([$buildingId]);
    $elements = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 4. Build Tree for this building
    $byId = [];
    foreach ($elements as &$el) {
        $el['children'] = [];
        $el['media'] = [];
        $byId[$el['id']] = &$el;
    }
    unset($el);

    $treeItems = [];
    foreach ($byId as $id => &$node) {
        // Fetch budget items
        $bstmt = $db->prepare("SELECT * FROM dd_budget_items WHERE element_id = ?");
        $bstmt->execute([$id]);
        $node['budget_items'] = $bstmt->fetchAll(PDO::FETCH_ASSOC);

        // Fetch media
        $mstmt = $db->prepare("SELECT * FROM element_media WHERE element_id = ? ORDER BY sort_order ASC, id ASC");
        $mstmt->execute([$id]);
        $node['media'] = $mstmt->fetchAll(PDO::FETCH_ASSOC);

        if ($node['parent_id'] && isset($byId[$node['parent_id']])) {
            $byId[$node['parent_id']]['children'][] = &$node;
        } else {
            $treeItems[] = &$node;
        }
    }
    unset($node);
    $building['tree'] = $treeItems;
}

// Map buildings to tree for legacy template support if needed, but we'll update template
$tree = $buildings;

// Helper Translation Function (Simplified)
function translate($key)
{
    return $key;
}

?>
<!DOCTYPE html>
<html lang="da">

<head>
    <meta charset="UTF-8">
    <title>Tilstandsrapport -
        <?= htmlspecialchars($project['name']) ?>
    </title>
    <style>
        /* Styles adapted from sys_tdd */
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            color: #333;
            margin: 0;
            padding: 20px 0 20px 300px;
            background: #525659;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        /* Sidebar */
        #nav-sidebar {
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            width: 300px;
            background: #f8f9fa;
            border-right: 1px solid #ddd;
            overflow-y: auto;
            padding: 20px;
            z-index: 100;
            font-size: 0.9rem;
        }

        .nav-group-title {
            font-weight: 600;
            color: #34495e;
            display: block;
            margin-bottom: 5px;
            text-decoration: none;
        }

        .nav-links {
            list-style: none;
            padding-left: 15px;
            margin: 0;
        }

        .nav-links a {
            text-decoration: none;
            color: #666;
            font-size: 0.85rem;
            display: block;
            margin-bottom: 4px;
        }

        .nav-links a:hover {
            color: #2980b9;
        }

        /* A4 Page */
        .page {
            width: 210mm;
            height: 297mm;
            padding: 20mm;
            margin: 0 auto 20px auto;
            background: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            position: relative;
            overflow: hidden;
            break-after: always;
        }

        /* Typography */
        h1 {
            color: #2c3e50;
            font-size: 24pt;
            margin-bottom: 20px;
            font-weight: 600;
        }

        h2 {
            color: #2c3e50;
            font-size: 18pt;
            margin-top: 20px;
            border-bottom: 2px solid #eee;
            padding-bottom: 5px;
        }

        h3 {
            color: #34495e;
            font-size: 14pt;
            margin-top: 15px;
            font-weight: 500;
        }

        h4 {
            color: #7f8c8d;
            font-size: 11pt;
            margin-top: 10px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 5px;
        }

        p,
        li,
        td {
            font-size: 10pt;
            line-height: 1.5;
            color: #444;
            margin-bottom: 10px;
        }

        /* Tables & Grid */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            font-size: 9pt;
        }

        th {
            text-align: left;
            background: #f8f9fa;
            padding: 6px;
            font-weight: 600;
        }

        td {
            border-bottom: 1px solid #eee;
            padding: 6px;
        }

        .text-right {
            text-align: right;
        }

        .meta-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-top: 15px;
        }

        .image-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-top: 15px;
        }

        .report-img {
            width: 100%;
            height: 180px;
            object-fit: cover;
            background: #eee;
            border: 1px solid #ddd;
        }

        /* Print Override */
        @media print {
            body {
                background: white;
                padding: 0;
                display: block;
            }

            #nav-sidebar {
                display: none !important;
            }

            .page {
                margin: 0;
                border: none;
                box-shadow: none;
                width: 100%;
                height: auto;
                min-height: 297mm;
            }

            .no-print {
                display: none !important;
            }
        }

        /* Risk Badges */
        .risk-badge {
            padding: 2px 6px;
            border-radius: 3px;
            color: white;
            font-size: 8pt;
            font-weight: bold;
        }

        .risk-1 {
            background: #27ae60;
        }

        /* Good */
        .risk-2 {
            background: #f1c40f;
            color: #333;
        }

        /* Warning */
        .risk-3 {
            background: #e67e22;
        }

        /* Bad */
        .risk-4,
        .risk-5 {
            background: #e74c3c;
        }

        /* Critical */
    </style>
</head>

<body>

    <!-- Sidebar -->
    <div id="nav-sidebar" class="no-print">
        <h3>Indhold</h3>
        <?php foreach ($buildings as $bld): ?>
            <div class="nav-group-title" style="margin-top:10px; padding: 5px; background:#eee;">
                <?= htmlspecialchars($bld['name']) ?>
            </div>
            <?php
            $gC = 1;
            foreach ($bld['tree'] as $group):
                ?>
                <div class="nav-group">
                    <a href="#group-<?= $bld['id'] ?>-<?= $gC ?>" class="nav-group-title" style="padding-left:10px;">
                        <?= $gC ?>. <?= htmlspecialchars($group['name']) ?>
                    </a>
                    <ul class="nav-links">
                        <?php
                        $cC = 1;
                        foreach ($group['children'] as $child):
                            ?>
                            <li><a href="#elem-<?= $child['id'] ?>">
                                    <?= $gC ?>.<?= $cC ?>             <?= htmlspecialchars($child['name']) ?>
                                </a></li>
                            <?php $cC++; endforeach; ?>
                    </ul>
                </div>
                <?php $gC++; endforeach; ?>
        <?php endforeach; ?>
    </div>

    <!-- Cover Page -->
    <div class="page">
        <div style="height:100%; display:flex; flex-direction:column;">
            <div style="margin-top:60px;">
                <h1>Tilstandsrapport</h1>
                <div style="font-size:18pt; color:#7f8c8d;">
                    <?= htmlspecialchars($project['name']) ?>
                </div>
            </div>

            <div
                style="margin-top:auto; margin-bottom:40px; background:#f8f9fa; border-left:5px solid #2c3e50; padding:20px;">
                <div style="display:grid; grid-template-columns: 100px 1fr; gap:10px;">
                    <b>Kunde:</b> <span>
                        <?= htmlspecialchars($project['client_name']) ?>
                    </span>
                    <b>Adresse:</b> <span>
                        <?= htmlspecialchars($project['client_address']) ?>
                    </span>
                    <b>Dato:</b> <span>
                        <?= date('d.m.Y') ?>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- TOC & Intro -->
    <div class="page">
        <h2>Indholdsfortegnelse</h2>
        <ul style="list-style:none; padding:0;">
            <?php foreach ($buildings as $bld): ?>
                <li style="margin-top:10px; font-weight:800; border-bottom: 1px solid #ccc;">
                    <?= htmlspecialchars($bld['name']) ?>
                </li>
                <?php
                $groupCounter = 1;
                foreach ($bld['tree'] as $group):
                    ?>
                    <li style="margin-left:10px; margin-top:5px; font-weight:bold;">
                        <?= $groupCounter ?>. <?= htmlspecialchars($group['name']) ?>
                    </li>
                    <?php
                    $childCounter = 1;
                    foreach ($group['children'] as $child):
                        ?>
                        <li style="margin-left:30px; margin-bottom:2px; font-size:0.9em; color:#666;">
                            <?= $groupCounter ?>.<?= $childCounter ?>             <?= htmlspecialchars($child['name']) ?>
                        </li>
                        <?php $childCounter++; endforeach; ?>
                    <?php $groupCounter++; endforeach; ?>
            <?php endforeach; ?>
        </ul>

        <h2>Introduktion</h2>
        <p>
            <?= nl2br(htmlspecialchars($project['description'] ?? 'Ingen beskrivelse.')) ?>
        </p>
    </div>

    <!-- Content Pages -->
    <div style="width: 210mm; margin: 0 auto; background: white; padding: 20mm;">
        <?php foreach ($buildings as $bld): ?>
            <div
                style="break-before: page; margin-bottom: 40px; padding: 20px; background:#1e40af; color:white; border-radius:4px;">
                <h1 style="color:white; margin:0;">Bygning: <?= htmlspecialchars($bld['name']) ?></h1>
                <?php if (!empty($bld['address'])): ?>
                    <p style="color:white; margin:5px 0 0 0; font-style:italic;"><?= htmlspecialchars($bld['address']) ?></p>
                <?php endif; ?>
            </div>

            <?php
            $groupCounter = 1;
            foreach ($bld['tree'] as $group):
                ?>
                <div id="group-<?= $bld['id'] ?>-<?= $groupCounter ?>"
                    style="margin-top: 30px; border-bottom: 2px solid #eee; padding-bottom:5px;">
                    <h2 style="margin:0;">
                        <?= $groupCounter ?>. <?= htmlspecialchars($group['name']) ?>
                    </h2>
                </div>

                <?php
                $childCounter = 1;
                foreach ($group['children'] as $child):
                    ?>
                    <div id="elem-<?= $child['id'] ?>"
                        style="break-inside: avoid; margin-bottom: 40px; border-bottom: 1px solid #eee; padding-bottom: 20px;">
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:20px;">
                            <h3 style="margin:0;">
                                <?= $groupCounter ?>.<?= $childCounter ?>             <?= htmlspecialchars($child['name']) ?>
                            </h3>
                            <span class="risk-badge risk-<?= $child['condition_rating'] ?? 0 ?>">
                                Tilstand: <?= $child['condition_rating'] ?? 'N/A' ?>
                            </span>
                        </div>

                        <div class="meta-grid">
                            <div>
                                <?php if (!empty($child['description'])): ?>
                                    <h4 style="color:#64748b; font-size:8pt; margin-top:15px;">Observation</h4>
                                    <p style="margin-top:5px; color:#1e293b;"><?= nl2br(htmlspecialchars($child['description'])) ?></p>
                                <?php endif; ?>

                                <?php if (!empty($child['recommendation'])): ?>
                                    <h4 style="color:#1e40af; font-size:8pt; margin-top:15px;">Anbefaling</h4>
                                    <p style="margin-top:5px; color:#1e40af; font-weight:500;">
                                        <?= nl2br(htmlspecialchars($child['recommendation'])) ?>
                                    </p>
                                <?php endif; ?>

                                <?php if (empty($child['description']) && empty($child['recommendation'])): ?>
                                    <p style="color:#94a3b8; font-style:italic; margin-top:15px;">Ingen noter angivet</p>
                                <?php endif; ?>

                                <?php
                                $qty = (float) ($child['quantity'] ?? 0);
                                if ($qty > 0):
                                    ?>
                                    <div style="margin-top:15px; font-weight:600; font-size:9pt;">
                                        Omfang: <?= number_format($qty, 2, ',', '.') ?>                 <?= htmlspecialchars($child['unit'] ?? 'stk') ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Photo column -->
                            <div>
                                <?php if (!empty($child['media'])): ?>
                                    <div class="image-grid">
                                        <?php
                                        $lFIdx = 1;
                                        foreach ($child['media'] as $media):
                                            ?>
                                            <div style="text-align:center;">
                                                <img src="<?= get_image_url($media['file_path']) ?>" class="report-img">
                                                <div style="font-size: 8pt; color: #666; margin-top: 5px; font-style: italic;">
                                                    Fig. <?= $groupCounter ?>.<?= $childCounter ?>.<?= $lFIdx++ ?>:
                                                    <?= htmlspecialchars($media['caption'] ?? $child['name']) ?>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <div
                                        style="width: 100%; height: 60px; background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 4px; display: flex; align-items: center; justify-content: center; color: #cbd5e1; font-size: 8pt; margin-top:15px;">
                                        Ingen fotos</div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Budget -->
                        <?php
                        $elBudget = 0;
                        if (!empty($child['budget_items'])) {
                            foreach ($child['budget_items'] as $bi)
                                $elBudget += $bi['total_calculated'];
                        }
                        if ($elBudget > 0):
                            ?>
                            <div
                                style="margin-top:20px; background:#f8fafc; padding:15px; border-radius:4px; border:1px solid #e2e8f0;">
                                <h4 style="margin:0; font-size:9pt;">Overslag (CAPEX)</h4>
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Beskrivelse</th>
                                            <th class="text-right">Total (DKK)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($child['budget_items'] as $bItem): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($bItem['description']) ?></td>
                                                <td class="text-right"><?= number_format($bItem['total_calculated'], 2, ',', '.') ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                    <tfoot>
                                        <tr style="font-weight:bold;">
                                            <td style="border-top:2px solid #ddd;">I ALT</td>
                                            <td class="text-right" style="border-top:2px solid #ddd;">
                                                <?= number_format($elBudget, 2, ',', '.') ?>
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        <?php endif; ?>

                    </div>
                    <?php $childCounter++; endforeach; ?>

                <?php $groupCounter++; endforeach; ?>
        <?php endforeach; ?>
    </div>

    <script>
        function printReport() {
            window.print();
        }
    </script>
</body>

</html>