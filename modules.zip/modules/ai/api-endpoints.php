<?php
// modules/ai/api-endpoints.php

function handle_api($action, $db)
{
    switch ($action) {
        case 'list_agents':
            return list_agents($db);
        case 'get_agent':
            return get_agent($db);
        case 'save_agent':
            return save_agent($db);
        case 'delete_agent':
            return delete_agent($db);
        case 'list_models':
            return list_models();
        case 'run_assessment':
            return run_assessment($db);
        default:
            throw new Exception("Unknown AI action: " . $action);
    }
}

function list_agents($db)
{
    $stmt = $db->query("SELECT * FROM dd_ai_agents WHERE active = 1 ORDER BY name ASC");
    return $stmt->fetchAll();
}

function get_agent($db)
{
    $id = (int) ($_GET['id'] ?? 0);
    $stmt = $db->prepare("SELECT * FROM dd_ai_agents WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function save_agent($db)
{
    require_permission('allow_manage_configuration');
    $data = json_decode(file_get_contents('php://input'), true);
    $id = (int) ($data['id'] ?? 0);
    $name = $data['name'] ?? '';
    $description = $data['description'] ?? '';
    $prompt = $data['system_prompt'] ?? '';
    $model = $data['model'] ?? 'models/gemini-1.5-pro';
    $apiKey = $data['api_key'] ?? null;

    if (!$name)
        throw new Exception("Name required");

    if ($id) {
        $sql = "UPDATE dd_ai_agents SET name = ?, description = ?, system_prompt = ?, model = ?, api_key = ? WHERE id = ?";
        $stmt = $db->prepare($sql);
        $stmt->execute([$name, $description, $prompt, $model, $apiKey, $id]);
    } else {
        $sql = "INSERT INTO dd_ai_agents (name, description, system_prompt, model, api_key) VALUES (?, ?, ?, ?, ?)";
        $stmt = $db->prepare($sql);
        $stmt->execute([$name, $description, $prompt, $model, $apiKey]);
        $id = $db->lastInsertId();
    }

    return ['success' => true, 'id' => $id];
}

function delete_agent($db)
{
    require_permission('allow_manage_configuration');
    $id = (int) ($_GET['id'] ?? 0);
    $stmt = $db->prepare("UPDATE dd_ai_agents SET active = 0 WHERE id = ?");
    $stmt->execute([$id]);
    return ['success' => true];
}

function list_models()
{
    return [
        ['name' => 'models/gemini-2.0-flash', 'displayName' => 'Gemini 2.0 Flash'],
        ['name' => 'models/gemini-2.0-flash-001', 'displayName' => 'Gemini 2.0 Flash 001'],
        ['name' => 'models/gemini-2.0-flash-lite-preview-02-05', 'displayName' => 'Gemini 2.0 Flash-Lite (Feb 2025)'],
        ['name' => 'models/gemini-1.5-pro', 'displayName' => 'Gemini 1.5 Pro'],
        ['name' => 'models/gemini-1.5-flash', 'displayName' => 'Gemini 1.5 Flash'],
        ['name' => 'models/gemini-2.5-flash', 'displayName' => 'Gemini 2.5 Flash'],
        ['name' => 'models/gemini-2.5-pro', 'displayName' => 'Gemini 2.5 Pro'],
        ['name' => 'models/gemini-2.5-flash-lite', 'displayName' => 'Gemini 2.5 Flash-Lite'],
        ['name' => 'models/gemini-exp-1206', 'displayName' => 'Gemini Experimental 1206'],
        ['name' => 'models/gemma-3-27b-it', 'displayName' => 'Gemma 3 27B'],
        ['name' => 'models/deep-research-pro-preview-12-2025', 'displayName' => 'Deep Research Pro Preview (Dec-12-2025)']
    ];
}

function run_assessment($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $agentId = (int) ($data['agent_id'] ?? 0);
    $elementId = (int) ($data['element_id'] ?? 0);
    $language = $data['language'] ?? 'Dansk';

    if (!$agentId || !$elementId)
        throw new Exception("Agent ID and Element ID required");

    // 1. Fetch Agent
    $stmt = $db->prepare("SELECT * FROM dd_ai_agents WHERE id = ? AND active = 1");
    $stmt->execute([$agentId]);
    $agent = $stmt->fetch();
    if (!$agent)
        throw new Exception("Agent not found");

    // 2. Fetch Element Data
    $stmt = $db->prepare("SELECT e.*, b.name as building_name FROM dd_building_Elements e JOIN dd_buildings b ON e.building_id = b.id WHERE e.id = ?");
    $stmt->execute([$elementId]);
    $element = $stmt->fetch();
    if (!$element)
        throw new Exception("Element not found");

    // 3. Fetch Media
    $mediaIds = $data['media_ids'] ?? [];
    if (!empty($mediaIds)) {
        $placeholders = implode(',', array_fill(0, count($mediaIds), '?'));
        $stmt = $db->prepare("SELECT * FROM element_media WHERE element_id = ? AND id IN ($placeholders) ORDER BY sort_order ASC");
        $stmt->execute(array_merge([$elementId], $mediaIds));
    } else {
        $stmt = $db->prepare("SELECT * FROM element_media WHERE element_id = ? ORDER BY sort_order ASC LIMIT 4");
        $stmt->execute([$elementId]);
    }
    $media = $stmt->fetchAll();

    // 4. Construct Prompt
    $description = $element['description'] ?? '';
    $recommendation = $element['recommendation'] ?? '';

    // Support custom prompts from the UI
    $systemPrompt = !empty($data['custom_prompt']) ? $data['custom_prompt'] : $agent['system_prompt'];

    // Requirement for JSON output
    $jsonInstruction = "\n\nDU SKAL RETURNERE DIT SVAR SOM ET JSON OBJEKT med følgende struktur:\n" .
        "{\n" .
        "  \"observation\": \"Din tekniske analyse...\",\n" .
        "  \"recommendation\": \"Din anbefaling...\",\n" .
        "  \"flags\": [\"Flag 1\", \"Flag 2\"],\n" .
        "  \"condition\": \"God|Fornuftig|Acceptabel|Forventet|Dårlig\"\n" .
        "}\n" .
        "Sørg for at JSON er valid og ikke indeholder markdown-formatering uden om (ingen ```json blox).";

    // Add Tag definitions
    $tagDefinitions = "\n\nDEFINITION AF SYSTEM-TAGS:\n" .
        "- {{navn}}: Navnet på bygningsdelen\n" .
        "- {{placering}}: Beskrivelse af placering\n" .
        "- {{observation}}: Brugerens tekniske observation\n" .
        "- {{anbefaling}}: Brugerens foreslåede handling\n" .
        "- {{bygning}}: Navnet på bygningen\n" .
        "AI kan foreslå tekst der indeholder disse tags, hvis data mangler eller skal refereres.";

    $fullPrompt = $systemPrompt;
    $fullPrompt .= $jsonInstruction;
    $fullPrompt .= $tagDefinitions;
    $fullPrompt .= "\n\nSprog: " . $language;
    $fullPrompt .= "\n\nBygningsdel: " . $element['name'];
    $fullPrompt .= "\nBygning: " . $element['building_name'];
    $fullPrompt .= "\nBrugerens observation: " . $description;
    $fullPrompt .= "\nBrugerens anbefaling: " . $recommendation;

    // Check for annotations
    $hasAnnotations = false;
    foreach ($media as $m) {
        if (!empty($m['annotations'])) {
            $hasAnnotations = true;
            break;
        }
    }

    if ($hasAnnotations) {
        $fullPrompt .= "\n\nVIGTIGT: Nogle af de vedhæftede billeder indeholder annoteringer (viste cirkler/pile).";
        $fullPrompt .= "\nDu skal i din besvarelse (i 'observation' feltet) lave to særskilte sektioner for disse billeder:";
        $fullPrompt .= "\n1. En vurdering uden hensyntagen til annoteringer (hvad du generelt ser).";
        $fullPrompt .= "\n2. En kommentar specifikt rettet mod hvad brugeren har markeret/annoteret.";
    }

    $parts = [["text" => $fullPrompt]];

    // 5. Build Image Parts
    foreach ($media as $m) {
        $path = __DIR__ . '/../../assets/uploads/' . $m['file_path'];
        if (file_exists($path)) {
            $imageData = base64_encode(file_get_contents($path));
            $parts[] = [
                "inline_data" => [
                    "mime_type" => "image/jpeg",
                    "data" => $imageData
                ]
            ];
        }
    }

    // 6. Call Gemini
    $apiKey = $agent['api_key'] ?: GEMINI_API_KEY;
    $apiUrl = "https://generativelanguage.googleapis.com/v1beta/" . $agent['model'] . ":generateContent?key=" . $apiKey;

    $payload = [
        "contents" => [["parts" => $parts]],
        "generationConfig" => [
            "response_mime_type" => "application/json"
        ]
    ];

    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60); // Increased timeout for heavy vision tasks

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($httpCode !== 200) {
        $errData = json_decode($response, true);
        $errMsg = $errData['error']['message'] ?? ($curlError ?: "HTTP $httpCode");

        // Handle specific token/safety errors from Gemini
        if (strpos($errMsg, 'limit') !== false || strpos($errMsg, 'token') !== false) {
            throw new Exception("AI grænsen er nået (Token Limit). Prøv med færre billeder eller kortere prompt.");
        }
        throw new Exception("Gemini API Fejl: " . $errMsg);
    }

    $result = json_decode($response, true);

    // Check finish reason
    $finishReason = $result['candidates'][0]['finishReason'] ?? 'OTHER';
    if ($finishReason === 'SAFETY') {
        throw new Exception("AI nægtede at svare pga. sikkerhedsindstillinger (Safety Filter).");
    }
    if ($finishReason === 'MAX_TOKENS') {
        throw new Exception("AI svaret blev afbrudt fordi det var for langt (Max Tokens).");
    }

    $assessmentRaw = $result['candidates'][0]['content']['parts'][0]['text'] ?? '';

    // Attempt to parse JSON
    $assessment = json_decode($assessmentRaw, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        // Fallback if not JSON
        $assessment = [
            'observation' => $assessmentRaw,
            'recommendation' => 'Se observation',
            'flags' => [],
            'condition' => 'Forventet'
        ];
    }

    // 7. Persist to DB (Store full JSON in ai_assessment)
    $stmt = $db->prepare("UPDATE dd_building_Elements SET ai_assessment = ?, ai_assessment_date = NOW() WHERE id = ?");
    $stmt->execute([json_encode($assessment), $elementId]);

    return [
        'success' => true,
        'assessment' => $assessment, // Return object
        'agent_name' => $agent['name']
    ];
}
