<?php
// modules/dashboard/api-endpoints.php

function handle_api($action, $db)
{
    switch ($action) {
        case 'stats':
            return get_stats($db);
        case 'recent_activity':
            return get_recent_activity($db);
        case 'health':
            return get_system_health($db);
        default:
            throw new Exception("Unknown dashboard action: " . $action);
    }
}

function get_stats($db)
{
    // Combined Query for better performance
    $stmt = $db->query("
        SELECT 
            (SELECT COUNT(*) FROM dd_customers) as customers,
            (SELECT COUNT(*) FROM dd_projects) as projects,
            (SELECT COUNT(*) FROM dd_tasks WHERE status IN ('todo', 'in_progress')) as tasks,
            (SELECT COUNT(*) FROM dd_buildings) as buildings,
            (SELECT COUNT(*) FROM dd_users) as users
    ");
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);

    return [
        'customers' => (int) ($stats['customers'] ?? 0),
        'projects' => (int) ($stats['projects'] ?? 0),
        'tasks' => (int) ($stats['tasks'] ?? 0),
        'buildings' => (int) ($stats['buildings'] ?? 0),
        'users' => (int) ($stats['users'] ?? 0)
    ];
}

function get_recent_activity($db)
{
    require_permission('allow_view_all');
    // Fetch last 5 logs
    $logFile = __DIR__ . '/../../logs/system.log';
    if (!file_exists($logFile)) {
        return [];
    }

    $lines = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!$lines)
        return [];

    $lastLines = array_slice($lines, -5);
    $parsed = [];

    foreach ($lastLines as $line) {
        // Simple parse: extract timestamp and message part
        // Format: [YYYY-MM-DD HH:MM:SS] [LEVEL] ...
        if (preg_match('/^\[(.*?)\] \[(.*?)\] (.*)$/', $line, $matches)) {
            $parsed[] = [
                'time' => $matches[1],
                'level' => $matches[2],
                'message' => substr($matches[3], 0, 80) . (strlen($matches[3]) > 80 ? '...' : '')
            ];
        }
    }

    return array_reverse($parsed);
}

function get_system_health($db)
{
    require_permission('allow_manage_configuration');

    // DB Check
    try {
        $db->query("SELECT 1");
        $dbStatus = 'online';
    } catch (Exception $e) {
        $dbStatus = 'offline';
    }

    // Disk Space (Mock for restricted env, or use available if possible)
    $diskFree = @disk_free_space(__DIR__);
    $diskTotal = @disk_total_space(__DIR__);

    $diskUsage = 'Unknown';
    if ($diskTotal) {
        $diskUsage = round((($diskTotal - $diskFree) / $diskTotal) * 100) . '%';
    }

    return [
        'database' => $dbStatus,
        'disk_usage' => $diskUsage,
        'php_version' => phpversion(),
        'server_time' => date('Y-m-d H:i:s')
    ];
}
?>