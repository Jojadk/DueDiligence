<div class="module-header">
    <h1>Dashboard</h1>
</div>

<div class="dashboard-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; padding: 20px;">
    <div class="card" style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
        <h3>Welcome, Admin</h3>
        <p>System Version: {{app_version}}</p>
        <p>Select a module from the sidebar to get started.</p>
    </div>


    <!-- Quick Stats -->
    <div class="card" style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); grid-column: span 2;">
        <h3>System Overview</h3>
        <div id="dashboard-stats" style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; margin-top: 10px;">
            <div class="stat-box" style="text-align: center; padding: 1rem; background: #f9fafb; border-radius: 6px;">
                <span style="font-size: 2rem; font-weight: bold; color: #2563eb;" id="stat-customers">-</span>
                <div style="font-size: 0.85rem; color: #6b7280;">Customers</div>
            </div>
            <div class="stat-box" style="text-align: center; padding: 1rem; background: #f9fafb; border-radius: 6px;">
                <span style="font-size: 2rem; font-weight: bold; color: #2563eb;" id="stat-projects">-</span>
                <div style="font-size: 0.85rem; color: #6b7280;">Projects</div>
            </div>
            <div class="stat-box" style="text-align: center; padding: 1rem; background: #f9fafb; border-radius: 6px;">
                <span style="font-size: 2rem; font-weight: bold; color: #2563eb;" id="stat-buildings">-</span>
                <div style="font-size: 0.85rem; color: #6b7280;">Buildings</div>
            </div>
             <div class="stat-box" style="text-align: center; padding: 1rem; background: #f9fafb; border-radius: 6px; cursor: pointer;" onclick="App.router.navigate('tasks&template=list')">
                <span style="font-size: 2rem; font-weight: bold; color: #d97706;" id="stat-tasks">-</span>
                <div style="font-size: 0.85rem; color: #6b7280;">Open Tasks</div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card" style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
        <h3>Quick Actions</h3>
        <div style="display: grid; gap: 10px; margin-top: 10px;">
             <button id="dash-btn-add-customer" name="dash_add_customer" class="dd-btn dd-btn-primary" onclick="if(App.customer && App.customer.showAddModal) App.customer.showAddModal(); else App.router.navigate('customer');">
                <span class="nav-icon" data-icon="add"></span> New Customer
            </button>
             <button id="dash-btn-add-user" name="dash_add_user" class="dd-btn dd-btn-secondary" onclick="if(App.users && App.users.showAddModal) App.users.showAddModal(); else App.router.navigate('system&template=users');">
                <span class="nav-icon" data-icon="user"></span> Invite User
            </button>
             <button id="dash-btn-view-logs" name="dash_view_logs" class="dd-btn dd-btn-secondary" onclick="App.router.navigate('system&template=audit_log')">
                <span class="nav-icon" data-icon="history"></span> View System Logs
            </button>
        </div>
    </div>

    <!-- Recent Activity -->
    <div class="card" style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); grid-column: span 2;">
        <h3>Recent Activity</h3>
        <ul id="recent-activity-list" style="list-style: none; padding: 0; margin-top: 10px;">
            <li style="color: #6b7280; text-align: center; padding: 1rem;">Loading activity...</li>
        </ul>
    </div>

    <!-- System Health -->
    <div class="card" style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
        <h3>System Health</h3>
        <div id="system-health" style="margin-top: 10px; font-size: 0.9rem;">
            <div style="display: flex; justify-content: space-between; padding: 5px 0; border-bottom: 1px solid #f3f4f6;">
                <span>Database</span>
                <span id="health-db" style="font-weight: 500;">Checking...</span>
            </div>
             <div style="display: flex; justify-content: space-between; padding: 5px 0; border-bottom: 1px solid #f3f4f6;">
                <span>Disk Usage</span>
                <span id="health-disk" style="font-weight: 500;">...</span>
            </div>
             <div style="display: flex; justify-content: space-between; padding: 5px 0; border-bottom: 1px solid #f3f4f6;">
                <span>PHP Version</span>
                <span id="health-php" style="font-weight: 500;">...</span>
            </div>
             <div style="display: flex; justify-content: space-between; padding: 5px 0;">
                <span>Server Time</span>
                <span id="health-time" style="font-weight: 500;">...</span>
            </div>
        </div>
    </div>
</div>

<script>
(function() {
    // Stats
    App.core.ajax('api.php?module=dashboard&action=stats').then(res => {
        if (res.success) {
            document.getElementById('stat-customers').textContent = res.data.customers;
            document.getElementById('stat-projects').textContent = res.data.projects;
            document.getElementById('stat-buildings').textContent = res.data.buildings;
            document.getElementById('stat-tasks').textContent = res.data.tasks;
        }
    }).catch(console.error);

    // Recent Activity
    App.core.ajax('api.php?module=dashboard&action=recent_activity').then(res => {
        const list = document.getElementById('recent-activity-list');
        if (res.success && res.data.length > 0) {
            list.innerHTML = res.data.map((log, idx) => {
                let message = log.message;
                let details = '';
                
                // Try to detect and format JSON
                if (message && (message.startsWith('{') || message.startsWith('['))) {
                    try {
                        const parsed = JSON.parse(message);
                        message = 'System configuration or data update'; // User friendly summary
                        details = `<details style="margin-top:5px; font-size:0.8rem; background:var(--gray-50); padding:8px; border-radius:4px;">
                                    <summary style="cursor:pointer; color:var(--primary-600);">View Details</summary>
                                    <pre style="margin-top:5px; overflow-x:auto;">${JSON.stringify(parsed, null, 2)}</pre>
                                   </details>`;
                    } catch(e) {}
                }

                return `
                    <li style="border-bottom: 1px solid #f3f4f6; padding: 12px 0; font-size: 0.9rem;">
                        <div style="display: flex; gap: 10px; align-items: flex-start;">
                            <span style="color: #9ca3af; font-family: monospace; font-size: 0.8rem; white-space: nowrap; margin-top: 2px;">${log.time.split(' ')[1]}</span>
                            <div style="flex: 1;">
                                <span style="${log.level.includes('ERROR') ? 'color:#ef4444' : 'color:#374151'}; font-weight: 500;">${message}</span>
                                ${details}
                            </div>
                        </div>
                    </li>
                `;
            }).join('');
        } else {
            list.innerHTML = '<li style="color: #9ca3af; text-align: center; padding: 2rem;">No recent activity.</li>';
        }
    }).catch(err => {
        document.getElementById('recent-activity-list').innerHTML = '<li style="color: #ef4444; padding: 1rem;">Failed to load activity.</li>';
    });

    // Health
    App.core.ajax('api.php?module=dashboard&action=health').then(res => {
        if (res.success) {
            const dbEl = document.getElementById('health-db');
            dbEl.textContent = res.data.database;
            dbEl.style.color = res.data.database === 'online' ? '#10b981' : '#ef4444';
            
            document.getElementById('health-disk').textContent = res.data.disk_usage;
            document.getElementById('health-php').textContent = res.data.php_version;
            document.getElementById('health-time').textContent = res.data.server_time.split(' ')[1];
        }
    }).catch(console.error);

})();
</script>
