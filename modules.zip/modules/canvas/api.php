<?php
// modules/canvas/api.php

function handle_api($action, $db)
{
    switch ($action) {
        case 'canvas_get':
            return get_canvas_data($db);
        case 'canvas_save':
            return save_canvas_data($db);
        default:
            throw new Exception("Unknown canvas action: " . $action);
    }
}

function get_canvas_data($db)
{
    // Need attachment ID or Element ID?
    // Usually we want to load canvas for a specific image (attachment).
    $attachmentId = (int) ($_GET['attachment_id'] ?? 0);
    $elementId = (int) ($_GET['element_id'] ?? 0);

    if ($attachmentId) {
        $stmt = $db->prepare("SELECT id, filename, file_path, annotations FROM dd_system_Attachments WHERE id = ?");
        $stmt->execute([$attachmentId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // If getting by element, return list of annotatable images?
    if ($elementId) {
        $stmt = $db->prepare("SELECT id, filename, file_path, annotations FROM dd_system_Attachments WHERE bind_type = 'building_elements' AND bind_id = ?");
        $stmt->execute([$elementId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    throw new Exception("Attachment ID or Element ID required");
}

function save_canvas_data($db)
{
    $input = json_decode(file_get_contents('php://input'), true);
    $attachmentId = (int) ($input['attachment_id'] ?? 0);
    $annotations = $input['annotations'] ?? null; // JSON string or array

    if (!$attachmentId) {
        throw new Exception("Attachment ID required");
    }

    // Ensure annotations is string
    if (!is_string($annotations)) {
        $annotations = json_encode($annotations);
    }

    $stmt = $db->prepare("UPDATE dd_system_Attachments SET annotations = ? WHERE id = ?");
    $stmt->execute([$annotations, $attachmentId]);

    return ['success' => true, 'message' => 'Annotations saved'];
}
?>