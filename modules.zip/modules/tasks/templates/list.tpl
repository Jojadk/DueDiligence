<!-- modules/tasks/list.tpl -->
<div class="dd-module-container">
    <!-- Header -->
    <div class="dd-module-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; padding-bottom: 1rem; border-bottom: 2px solid var(--gray-200);">
        <div>
            <h2 style="margin: 0; font-size: 1.5rem; font-weight: 700; color: var(--gray-800);">
                <?= App::icons('tasks') ?> Tasks
                <span id="task-count" style="font-size: 0.9rem; color: var(--gray-500); font-weight: 400; margin-left: 0.5rem;">0</span>
            </h2>
            <p style="margin: 0.5rem 0 0 0; color: var(--gray-600); font-size: 0.9rem;">
                Manage and track tasks for your project
            </p>
        </div>
        <button class="dd-btn-primary" onclick="App.tasks.showAddModal()" style="display: flex; align-items: center; gap: 8px;">
            <?= App::icons('plus') ?> Add Task
        </button>
    </div>

    <!-- Filters and View Toggle -->
    <div style="background: white; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; border: 1px solid var(--gray-200); box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
        <div style="display: flex; gap: 1rem; flex-wrap: wrap; align-items: center; justify-content: space-between;">
            <!-- Search -->
            <div style="flex: 1; min-width: 250px;">
                <div style="position: relative;">
                    <span style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--gray-400);">
                        <?= App::icons('search') ?>
                    </span>
                    <input 
                        type="text" 
                        id="tasks-search" 
                        class="dd-input" 
                        placeholder="Search tasks..." 
                        oninput="App.tasks.handleSearch(this.value)"
                        style="padding-left: 2.5rem;"
                    >
                </div>
            </div>

            <!-- Filters -->
            <div style="display: flex; gap: 0.75rem; flex-wrap: wrap;">
                <select id="tasks-filter-status" class="dd-input" onchange="App.tasks.handleFilter()" style="width: auto; min-width: 150px;">
                    <option value="">All Statuses</option>
                    <option value="todo">To Do</option>
                    <option value="in_progress">In Progress</option>
                    <option value="review">Review</option>
                    <option value="completed">Completed</option>
                </select>

                <select id="tasks-filter-priority" class="dd-input" onchange="App.tasks.handleFilter()" style="width: auto; min-width: 140px;">
                    <option value="">All Priorities</option>
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                </select>

                <select id="tasks-filter-assigned" class="dd-input" onchange="App.tasks.handleFilter()" style="width: auto; min-width: 150px;">
                    <option value="">All Assignees</option>
                    <!-- Users populated via JS -->
                </select>
            </div>

            <!-- View Toggle -->
            <div style="display: flex; gap: 0.5rem; background: var(--gray-100); padding: 4px; border-radius: 6px;">
                <button 
                    class="view-toggle-btn active" 
                    data-view="kanban"
                    onclick="App.tasks.switchView('kanban')"
                    style="padding: 6px 16px; border: none; background: white; color: var(--gray-700); border-radius: 4px; cursor: pointer; font-size: 0.85rem; font-weight: 500; transition: all 0.2s; display: flex; align-items: center; gap: 6px;"
                >
                    <?= App::icons('grid') ?> Kanban
                </button>
                <button 
                    class="view-toggle-btn" 
                    data-view="list"
                    onclick="App.tasks.switchView('list')"
                    style="padding: 6px 16px; border: none; background: transparent; color: var(--gray-600); border-radius: 4px; cursor: pointer; font-size: 0.85rem; font-weight: 500; transition: all 0.2s; display: flex; align-items: center; gap: 6px;"
                >
                    <?= App::icons('list') ?> List
                </button>
            </div>
        </div>
    </div>

    <!-- Kanban View -->
    <div id="kanban-board" style="display: block;">
        <!-- Populated by JavaScript -->
    </div>

    <!-- List View -->
    <div id="list-view" style="display: none;">
        <div class="dd-table-container" style="background: white; border-radius: 8px; overflow: hidden; border: 1px solid var(--gray-200); box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
            <table class="dd-table" style="width: 100%; border-collapse: collapse;">
                <thead style="background: var(--gray-50); border-bottom: 2px solid var(--gray-200);">
                    <tr>
                        <th onclick="App.tasks.sort('title')" data-sort="title" style="padding: 0.875rem; text-align: left; font-weight: 600; color: var(--gray-700); cursor: pointer; user-select: none; font-size: 0.85rem;">
                            Task <span class="sort-icon">⇅</span>
                        </th>
                        <th onclick="App.tasks.sort('status')" data-sort="status" style="padding: 0.875rem; text-align: left; font-weight: 600; color: var(--gray-700); cursor: pointer; user-select: none; font-size: 0.85rem;">
                            Status <span class="sort-icon">⇅</span>
                        </th>
                        <th onclick="App.tasks.sort('priority')" data-sort="priority" style="padding: 0.875rem; text-align: left; font-weight: 600; color: var(--gray-700); cursor: pointer; user-select: none; font-size: 0.85rem;">
                            Priority <span class="sort-icon">⇅</span>
                        </th>
                        <th style="padding: 0.875rem; text-align: left; font-weight: 600; color: var(--gray-700); font-size: 0.85rem;">
                            Assigned To
                        </th>
                        <th onclick="App.tasks.sort('due_date')" data-sort="due_date" style="padding: 0.875rem; text-align: left; font-weight: 600; color: var(--gray-700); cursor: pointer; user-select: none; font-size: 0.85rem;">
                            Due Date <span class="sort-icon">⇅</span>
                        </th>
                        <th style="padding: 0.875rem; text-align: center; font-weight: 600; color: var(--gray-700); font-size: 0.85rem;">
                            Activity
                        </th>
                        <th style="padding: 0.875rem; text-align: right; font-weight: 600; color: var(--gray-700); font-size: 0.85rem; width: 100px;">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody id="tasks-list-body">
                    <tr>
                        <td colspan="7" style="padding: 2rem; text-align: center; color: var(--gray-500);">
                            Loading tasks...
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div id="task-pagination"></div>
    </div>
</div>

<!-- Styles -->
<style>
.view-toggle-btn.active {
    background: white !important;
    color: var(--primary-600) !important;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.view-toggle-btn:hover:not(.active) {
    background: rgba(255,255,255,0.5);
}

.kanban-card {
    transition: all 0.2s ease;
}

.kanban-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1) !important;
    border-color: var(--primary-300) !important;
}

.kanban-column-tasks {
    scrollbar-width: thin;
    scrollbar-color: var(--gray-400) var(--gray-100);
}

.kanban-column-tasks::-webkit-scrollbar {
    width: 6px;
}

.kanban-column-tasks::-webkit-scrollbar-track {
    background: var(--gray-100);
    border-radius: 3px;
}

.kanban-column-tasks::-webkit-scrollbar-thumb {
    background: var(--gray-400);
    border-radius: 3px;
}

.kanban-column-tasks::-webkit-scrollbar-thumb:hover {
    background: var(--gray-500);
}

.dd-table tbody tr:hover {
    background: var(--gray-50) !important;
}

.sort-icon {
    display: inline-block;
    margin-left: 4px;
    opacity: 0.5;
    font-size: 0.9em;
}

[data-sort]:hover .sort-icon {
    opacity: 1;
}

/* Responsive */
@media (max-width: 1200px) {
    .kanban-container {
        grid-template-columns: repeat(2, 1fr) !important;
    }
}

@media (max-width: 768px) {
    .kanban-container {
        grid-template-columns: 1fr !important;
    }
    
    .dd-module-header {
        flex-direction: column;
        align-items: flex-start !important;
        gap: 1rem;
    }
    
    .dd-module-header button {
        width: 100%;
        justify-content: center;
    }
}
</style>

<!-- Initialize -->
<script>
(function() {
    // Get project ID from URL or context
    const urlParams = new URLSearchParams(window.location.search);
    const projectId = urlParams.get('project_id') || <?= $project_id ?? 0 ?>;
    
    // Always initialize, even if projectId is 0 (to show all tasks)
    App.tasks.init(projectId);
    
    // Load users for filter dropdown
    App.tasks.loadUsersForSelect('tasks-filter-assigned');

    // Handle view switching
    const viewButtons = document.querySelectorAll('[data-view]');
    const kanbanBoard = document.getElementById('kanban-board');
    const listView = document.getElementById('list-view');

    viewButtons.forEach(btn => {
        btn.onclick = function() {
            const view = this.dataset.view;
            
            // Update button states
            viewButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            // Toggle views
            if (kanbanBoard) kanbanBoard.style.display = view === 'kanban' ? 'block' : 'none';
            if (listView) listView.style.display = view === 'list' ? 'block' : 'none';

            // Ensure data is loaded for the view
            App.tasks.state.view = view;
            App.tasks.loadView();
        };
    });
})();
</script>
