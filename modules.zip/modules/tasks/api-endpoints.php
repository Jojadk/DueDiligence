<?php
// modules/tasks/api-endpoints.php

function handle_api($action, $db)
{
    switch ($action) {
        case 'list':
        case 'kanban':
        case 'get':
        case 'stats':
            require_permission('allow_view_all');
            break;
        case 'create':
        case 'update':
        case 'delete':
        case 'add_comment':
        case 'update_sort':
        case 'update_status':
        case 'bulk_update':
            require_permission('allow_manage_tasks');
            break;
    }

    switch ($action) {
        case 'list':
            return list_tasks($db);
        case 'kanban':
            return get_kanban_data($db);
        case 'get':
            return get_task($db);
        case 'create':
            return create_task($db);
        case 'update':
            return update_task($db);
        case 'delete':
            return delete_task($db);
        case 'add_comment':
            return add_comment($db);
        case 'update_sort':
            return update_sort($db);
        case 'update_status':
            return update_task_status($db);
        case 'bulk_update':
            return bulk_update_tasks($db);
        case 'stats':
            return get_project_stats($db);
        default:
            throw new Exception("Unknown task action: " . $action);
    }
}

function list_tasks($db)
{
    $projectId = (int) ($_GET['project_id'] ?? 0);
    // Removed strict requirement for project_id to allow global task view from dashboard

    $status = $_GET['status'] ?? null;
    $assignedTo = $_GET['assigned_to'] ?? null;
    $priority = $_GET['priority'] ?? null;
    $search = $_GET['search'] ?? '';

    $page = max(1, (int) ($_GET['page'] ?? 1));
    $limit = min(100, max(10, (int) ($_GET['limit'] ?? 20)));
    $offset = ($page - 1) * $limit;

    $sort = $_GET['sort'] ?? 'created_at';
    $order = strtoupper($_GET['order'] ?? 'DESC') === 'ASC' ? 'ASC' : 'DESC';

    $allowedSort = ['id', 'title', 'status', 'priority', 'created_at', 'due_date', 'sort_order'];
    if (!in_array($sort, $allowedSort)) {
        $sort = 'created_at';
    }

    $query = "
        SELECT t.*, 
               u.name as assigned_name,
               u.photo as assigned_photo,
               c.name as creator_name,
               p.name as project_title,
               COUNT(DISTINCT comm.id) as comment_count,
               COUNT(DISTINCT att.id) as attachment_count
        FROM v_dd_tasks t
        LEFT JOIN dd_users u ON t.assigned_to = u.id
        LEFT JOIN dd_users c ON t.created_by = c.id
        LEFT JOIN dd_projects p ON t.project_id = p.id
        LEFT JOIN dd_task_comments comm ON t.id = comm.task_id
        LEFT JOIN dd_task_attachments att ON t.id = att.task_id
        WHERE 1=1
    ";

    $params = [];

    if ($projectId) {
        $query .= " AND t.project_id = ?";
        $params[] = $projectId;
    }

    if ($status) {
        $query .= " AND t.status = ?";
        $params[] = $status;
    }

    if ($assignedTo) {
        $query .= " AND t.assigned_to = ?";
        $params[] = $assignedTo;
    }

    if ($priority) {
        $query .= " AND t.priority = ?";
        $params[] = $priority;
    }

    if ($search) {
        $query .= " AND (t.title LIKE ? OR t.description LIKE ?)";
        $searchTerm = '%' . $search . '%';
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }

    // Count total
    $countQuery = "SELECT COUNT(*) as total FROM (" . $query . ") as counted";
    $countStmt = $db->prepare($countQuery);
    $countStmt->execute($params);
    $total = $countStmt->fetch()['total'];

    // Use intval for LIMIT and OFFSET to avoid quoting issues in PDO emulation
    $query .= " GROUP BY t.id";
    $query .= " ORDER BY t.{$sort} {$order}";
    $query .= " LIMIT " . (int) $limit . " OFFSET " . (int) $offset;

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $tasks = $stmt->fetchAll();

    return [
        'data' => $tasks,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'last_page' => ceil($total / $limit)
        ]
    ];
}

function get_kanban_data($db)
{
    $projectId = (int) ($_GET['project_id'] ?? 0);

    $assignedTo = $_GET['assigned_to'] ?? null;
    $priority = $_GET['priority'] ?? null;
    $search = $_GET['search'] ?? '';

    $query = "
        SELECT t.*, 
               u.name as assigned_name,
               u.photo as assigned_photo,
               c.name as creator_name,
               (SELECT COUNT(*) FROM dd_task_comments WHERE task_id = t.id) as comment_count,
               (SELECT COUNT(*) FROM dd_task_attachments WHERE task_id = t.id) as attachment_count
        FROM dd_tasks t
        LEFT JOIN dd_users u ON t.assigned_to = u.id
        LEFT JOIN dd_users c ON t.created_by = c.id
        WHERE t.deleted_at IS NULL
    ";

    $params = [];
    if ($projectId) {
        $query .= " AND t.project_id = ?";
        $params[] = $projectId;
    }

    if ($assignedTo) {
        $query .= " AND t.assigned_to = ?";
        $params[] = $assignedTo;
    }

    if ($priority) {
        $query .= " AND t.priority = ?";
        $params[] = $priority;
    }

    if ($search) {
        $query .= " AND (t.title LIKE ? OR t.description LIKE ?)";
        $searchTerm = '%' . $search . '%';
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }

    $query .= " ORDER BY t.sort_order ASC, t.created_at DESC";

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $tasks = $stmt->fetchAll();

    // Group by status
    $columns = [
        'todo' => [],
        'in_progress' => [],
        'review' => [],
        'completed' => []
    ];

    foreach ($tasks as $task) {
        $status = $task['status'] ?? 'todo';
        if (isset($columns[$status])) {
            $columns[$status][] = $task;
        } else {
            $columns['todo'][] = $task;
        }
    }

    return [
        'columns' => $columns,
        'stats' => [
            'total' => count($tasks),
            'todo' => count($columns['todo']),
            'in_progress' => count($columns['in_progress']),
            'review' => count($columns['review']),
            'completed' => count($columns['completed'])
        ]
    ];
}

function get_task($db)
{
    $taskId = (int) ($_GET['id'] ?? 0);
    if (!$taskId) {
        throw new Exception('Task ID required');
    }

    $stmt = $db->prepare("
        SELECT t.*, 
               u.name as assigned_name,
               u.photo as assigned_photo,
               u.email as assigned_email,
               c.name as creator_name,
               c.photo as creator_photo,
               p.name as project_title,
               b.name as building_name,
               e.name as element_name
        FROM dd_tasks t
        LEFT JOIN dd_users u ON t.assigned_to = u.id
        LEFT JOIN dd_users c ON t.created_by = c.id
        LEFT JOIN dd_projects p ON t.project_id = p.id
        LEFT JOIN dd_buildings b ON t.building_id = b.id
        LEFT JOIN dd_building_Elements e ON t.element_id = e.id
        WHERE t.id = ?
    ");
    $stmt->execute([$taskId]);
    $task = $stmt->fetch();

    if (!$task) {
        throw new Exception('Task not found');
    }

    // Get comments
    $stmt = $db->prepare("
        SELECT c.*, u.name as user_name, u.photo as user_photo
        FROM dd_task_comments c
        LEFT JOIN dd_users u ON c.user_id = u.id
        WHERE c.task_id = ?
        ORDER BY c.created_at ASC
    ");
    $stmt->execute([$taskId]);
    $task['comments'] = $stmt->fetchAll();

    // Get attachments
    $stmt = $db->prepare("
        SELECT a.*, u.name as uploaded_by_name
        FROM dd_task_attachments a
        LEFT JOIN dd_users u ON a.uploaded_by = u.id
        WHERE a.task_id = ?
        ORDER BY a.created_at DESC
    ");
    $stmt->execute([$taskId]);
    $task['attachments'] = $stmt->fetchAll();

    // Get activity
    $stmt = $db->prepare("
        SELECT a.*, u.name as user_name, u.photo as user_photo
        FROM dd_task_activity a
        LEFT JOIN dd_users u ON a.user_id = u.id
        WHERE a.task_id = ?
        ORDER BY a.created_at DESC
        LIMIT 50
    ");
    $stmt->execute([$taskId]);
    $task['activity'] = $stmt->fetchAll();

    return $task;
}

function create_task($db)
{
    $data = json_decode(file_get_contents('php://input'), true);

    $required = ['project_id', 'title'];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            throw new Exception("Field '{$field}' is required");
        }
    }

    // Get max sort order for this project
    $stmt = $db->prepare("SELECT COALESCE(MAX(sort_order), 0) + 1 as next_order FROM dd_tasks WHERE project_id = ?");
    $stmt->execute([$data['project_id']]);
    $sortOrder = $stmt->fetch()['next_order'];

    $stmt = $db->prepare("
        INSERT INTO dd_tasks (
            project_id, building_id, element_id, title, description,
            status, priority, assigned_to, created_by, due_date,
            estimated_hours, tags, sort_order
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $userId = $_SESSION['user_id'] ?? 0;

    $stmt->execute([
        $data['project_id'],
        $data['building_id'] ?? null,
        $data['element_id'] ?? null,
        $data['title'],
        $data['description'] ?? null,
        $data['status'] ?? 'todo',
        $data['priority'] ?? 'medium',
        $data['assigned_to'] ?? null,
        $userId,
        $data['due_date'] ?? null,
        $data['estimated_hours'] ?? null,
        $data['tags'] ?? null,
        $sortOrder
    ]);

    $taskId = $db->lastInsertId();
    logTaskActivity($db, $taskId, $userId, 'created', null, 'Task created');

    return ['id' => $taskId, 'message' => 'Task created successfully'];
}

function update_task($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $taskId = (int) ($data['id'] ?? 0);

    if (!$taskId) {
        throw new Exception('Task ID required');
    }

    $stmt = $db->prepare("SELECT * FROM dd_tasks WHERE id = ?");
    $stmt->execute([$taskId]);
    $oldTask = $stmt->fetch();

    if (!$oldTask) {
        throw new Exception('Task not found');
    }

    $getVal = function ($key) use ($data, $oldTask) {
        return array_key_exists($key, $data) ? $data[$key] : $oldTask[$key];
    };

    $title = $getVal('title');
    $description = $getVal('description');
    $status = $getVal('status');
    $priority = $getVal('priority');
    $assignedTo = $getVal('assigned_to');
    $dueDate = $getVal('due_date');
    $estimatedHours = $getVal('estimated_hours');
    $actualHours = $getVal('actual_hours');
    $tags = $getVal('tags');
    $buildingId = $getVal('building_id');
    $elementId = $getVal('element_id');

    $stmt = $db->prepare("
        UPDATE dd_tasks SET
            title = ?,
            description = ?,
            status = ?,
            priority = ?,
            assigned_to = ?,
            due_date = ?,
            estimated_hours = ?,
            actual_hours = ?,
            tags = ?,
            building_id = ?,
            element_id = ?,
            project_id = ?
        WHERE id = ?
    ");

    $stmt->execute([
        $title,
        $description,
        $status,
        $priority,
        $assignedTo,
        $dueDate,
        $estimatedHours,
        $actualHours,
        $tags,
        $buildingId,
        $elementId,
        $taskId
    ]);

    $userId = $_SESSION['user_id'] ?? 0;

    // Log changes
    $trackFields = [
        'title' => 'updated title',
        'status' => 'changed status',
        'priority' => 'changed priority',
        'assigned_to' => 'reassigned task',
        'due_date' => 'changed due date',
        'building_id' => 'changed building',
        'element_id' => 'changed element'
    ];

    foreach ($trackFields as $field => $action) {
        $newVal = $getVal($field);
        if ($newVal != $oldTask[$field]) {
            logTaskActivity($db, $taskId, $userId, $action, $oldTask[$field], $newVal);
        }
    }

    return ['message' => 'Task updated successfully'];
}

function update_task_status($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $taskId = (int) ($data['id'] ?? 0);
    $newStatus = $data['status'] ?? '';

    if (!$taskId || !$newStatus) {
        throw new Exception('Task ID and status required');
    }

    $validStatuses = ['todo', 'in_progress', 'review', 'completed'];
    if (!in_array($newStatus, $validStatuses)) {
        throw new Exception('Invalid status');
    }

    $stmt = $db->prepare("SELECT status FROM dd_tasks WHERE id = ?");
    $stmt->execute([$taskId]);
    $oldStatus = $stmt->fetch()['status'] ?? null;

    if (!$oldStatus) {
        throw new Exception('Task not found');
    }

    $stmt = $db->prepare("UPDATE dd_tasks SET status = ? WHERE id = ?");
    $stmt->execute([$newStatus, $taskId]);

    $userId = $_SESSION['user_id'] ?? 0;
    logTaskActivity($db, $taskId, $userId, 'changed status', $oldStatus, $newStatus);

    return ['message' => 'Status updated successfully'];
}

function delete_task($db)
{
    $taskId = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);

    if (!$taskId) {
        throw new Exception('Task ID required');
    }

    $stmt = $db->prepare("CALL sp_SoftDelete('task', ?)");
    $stmt->execute([$taskId]);

    return ['message' => 'Task soft-deleted successfully'];
}

function add_comment($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $taskId = (int) ($data['task_id'] ?? 0);
    $comment = trim($data['comment'] ?? '');

    if (!$taskId || !$comment) {
        throw new Exception('Task ID and comment required');
    }

    $userId = $_SESSION['user_id'] ?? 0;

    $stmt = $db->prepare("
        INSERT INTO dd_task_comments (task_id, user_id, comment)
        VALUES (?, ?, ?)
    ");
    $stmt->execute([$taskId, $userId, $comment]);

    $commentId = $db->lastInsertId();
    logTaskActivity($db, $taskId, $userId, 'commented', null, 'Added a comment');

    // Get the created comment with user info
    $stmt = $db->prepare("
        SELECT c.*, u.name as user_name, u.photo as user_photo
        FROM dd_task_comments c
        LEFT JOIN dd_users u ON c.user_id = u.id
        WHERE c.id = ?
    ");
    $stmt->execute([$commentId]);
    $comment = $stmt->fetch();

    return ['id' => $commentId, 'message' => 'Comment added', 'comment' => $comment];
}

function update_sort($db)
{
    $data = json_decode(file_get_contents('php://input'), true);

    if (!isset($data['tasks']) || !is_array($data['tasks'])) {
        throw new Exception('Tasks array required');
    }

    $db->beginTransaction();
    try {
        foreach ($data['tasks'] as $index => $taskId) {
            $stmt = $db->prepare("UPDATE dd_tasks SET sort_order = ? WHERE id = ?");
            $stmt->execute([$index, $taskId]);
        }

        // Update status if provided
        if (isset($data['status']) && isset($data['task_id'])) {
            $stmt = $db->prepare("UPDATE dd_tasks SET status = ? WHERE id = ?");
            $stmt->execute([$data['status'], $data['task_id']]);

            $userId = $_SESSION['user_id'] ?? 0;
            logTaskActivity($db, $data['task_id'], $userId, 'changed status', null, $data['status']);
        }

        $db->commit();
        return ['message' => 'Sort order updated successfully'];
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

function bulk_update_tasks($db)
{
    $data = json_decode(file_get_contents('php://input'), true);

    if (!isset($data['task_ids']) || !is_array($data['task_ids'])) {
        throw new Exception('Task IDs required');
    }

    $updates = [];
    $params = [];

    if (isset($data['status'])) {
        $updates[] = "status = ?";
        $params[] = $data['status'];
    }

    if (isset($data['priority'])) {
        $updates[] = "priority = ?";
        $params[] = $data['priority'];
    }

    if (isset($data['assigned_to'])) {
        $updates[] = "assigned_to = ?";
        $params[] = $data['assigned_to'];
    }

    if (empty($updates)) {
        throw new Exception('No updates specified');
    }

    $placeholders = str_repeat('?,', count($data['task_ids']) - 1) . '?';
    $params = array_merge($params, $data['task_ids']);

    $sql = "UPDATE dd_tasks SET " . implode(', ', $updates) . " WHERE id IN ($placeholders)";

    $stmt = $db->prepare($sql);
    $stmt->execute($params);

    return ['message' => 'Tasks updated successfully', 'affected' => $stmt->rowCount()];
}

function get_project_stats($db)
{
    $projectId = (int) ($_GET['project_id'] ?? 0);
    if (!$projectId) {
        throw new Exception('Project ID required');
    }

    $stats = [];

    // Status counts
    $stmt = $db->prepare("
        SELECT status, COUNT(*) as count
        FROM dd_tasks
        WHERE project_id = ?
        GROUP BY status
    ");
    $stmt->execute([$projectId]);
    $stats['by_status'] = $stmt->fetchAll();

    // Priority counts
    $stmt = $db->prepare("
        SELECT priority, COUNT(*) as count
        FROM dd_tasks
        WHERE project_id = ?
        GROUP BY priority
    ");
    $stmt->execute([$projectId]);
    $stats['by_priority'] = $stmt->fetchAll();

    // Assigned counts
    $stmt = $db->prepare("
        SELECT assigned_to, u.name, COUNT(*) as count
        FROM dd_tasks t
        LEFT JOIN dd_users u ON t.assigned_to = u.id
        WHERE t.project_id = ?
        GROUP BY assigned_to
    ");
    $stmt->execute([$projectId]);
    $stats['by_assignee'] = $stmt->fetchAll();

    // Overdue tasks
    $stmt = $db->prepare("
        SELECT COUNT(*) as count
        FROM dd_tasks
        WHERE project_id = ? AND due_date < CURRENT_DATE AND status != 'completed'
    ");
    $stmt->execute([$projectId]);
    $stats['overdue'] = $stmt->fetch()['count'];

    return $stats;
}

function logTaskActivity($db, $taskId, $userId, $action, $oldValue, $newValue)
{
    // Schema check: "action" column might be missing based on logs.
    // If we can't change schema, we might need to put action in details/old_value/new_value or ignore.
    // Based on logs: "Unknown column 'action'".
    // Check if we can use a different structure or omitting action if not present.
    // Fallback: Using 'dd_system_logs' style or assuming older schema.

    // For now, attempting to fix by commenting out 'action' or assuming 'details' usage?
    // Actually, let's try to map it to 'details' if 'action' doesn't exist?
    // Schema provided says: CREATE TABLE dd_task_activity (...) action VARCHAR(100).
    // If logs say it's missing, the DB is out of sync.
    // Safest bet: Try to use 'new_value' to store "$action: $newValue" or similar if we can't alter DB.
    // BUT the best fix is ensuring the code matches the REAL DB.
    // Since I can't check REAL DB via SQL tool effectively right now, and user report says "Unknown column",
    // I will try to adapt to a likely schema: dd_task_activity(task_id, user_id, old_value, new_value) ??

    try {
        $stmt = $db->prepare("
            INSERT INTO dd_task_activity (task_id, user_id, old_value, new_value)
            VALUES (?, ?, ?, ?)
        ");
        // Prepend action to new_value to preserve context
        $combinedNew = $action . ": " . $newValue;
        $stmt->execute([$taskId, $userId, $oldValue, $combinedNew]);
    } catch (Exception $e) {
        // Silent fail for logging to prevent blocking main action
        error_log("Failed to log task activity: " . $e->getMessage());
    }
}
