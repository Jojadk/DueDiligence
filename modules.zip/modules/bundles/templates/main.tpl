<div class="bundles-layout">
    <div class="module-header">
        <h1 style="font-size:1.2rem; margin:0; display:flex; align-items:center;">
             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:10px;"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>
             Prispakker
        </h1>
        <div class="controls" style="display:flex; align-items:center;">
            <div class="search-box">
                 <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="search-icon"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                <input type="text" id="bundle-search" placeholder="Søg pakker..." onkeyup="App.bundles.search(this.value)">
            </div>
            <button class="dd-btn dd-btn-primary" onclick="App.bundles.createBundle()">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                Ny pakke
            </button>
        </div>
    </div>

    <div class="bundles-container">
        <div id="bundles-list" class="bundles-grid">
            <div class="loading-spinner"></div>
        </div>
    </div>
</div>

<link rel="stylesheet" href="public/css/bundles.css?v=<?php echo time(); ?>_12">
<script src="public/js/price_catalog_admin.js?v=<?php echo time(); ?>"></script>
<script src="public/js/bundles.js?v=<?php echo time(); ?>_12"></script>
<link rel="stylesheet" href="public/css/bundles.css">
<style>
    /* Bundles specific overrides if needed */
</style>
<script>
    (function() {
        var retries = 0;
        var initInterval = setInterval(function() {
            if (window.App && window.App.bundles) {
                clearInterval(initInterval);
                App.bundles.init('bundles-list');
            }
            retries++;
            if (retries > 50) clearInterval(initInterval);
        }, 100);
    })();
</script>
