<?php
// modules/bundles/api-endpoints.php

function handle_api($action, $db)
{
    switch ($action) {
        case 'list':
            return list_bundles($db);
        case 'get':
            return get_bundle($db);
        case 'save':
            return save_bundle($db);
        case 'delete':
            return delete_bundle($db);
        case 'toggle_favorite':
            return toggle_favorite_bundle($db);
        case 'update_tags':
            return update_tags_bundle($db);
        default:
            throw new Exception("Unknown bundles action: " . $action);
    }
}

function list_bundles($db)
{
    // Use stored total_price and unit. 
    // We still count items for consistency, or we could cache that too, but user only asked for price/unit.
    $stmt = $db->query("
        SELECT 
            b.*, 
            (SELECT COUNT(*) FROM dd_price_catalog_bundle_items WHERE bundle_id = b.id) as item_count
        FROM dd_price_catalog_bundles b 
        ORDER BY b.name ASC
    ");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function get_bundle($db)
{
    $id = $_GET['id'] ?? null;
    if (!$id)
        throw new Exception("ID required");

    $stmt = $db->prepare("SELECT * FROM dd_price_catalog_bundles WHERE id = ?");
    $stmt->execute([$id]);
    $bundle = $stmt->fetch();

    if (!$bundle)
        throw new Exception("Bundle not found");

    $stmt = $db->prepare("
        SELECT bi.*, pc.item_code, pc.description as catalog_name 
        FROM dd_price_catalog_bundle_items bi
        JOIN dd_price_catalogs pc ON bi.catalog_id = pc.id
        WHERE bi.bundle_id = ?
        ORDER BY bi.sort_order ASC
    ");
    $stmt->execute([$id]);
    $bundle['items'] = $stmt->fetchAll();

    return $bundle;
}

function save_bundle($db)
{
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input)
        throw new Exception("Invalid input");

    $id = $input['id'] ?? null;
    $name = $input['name'] ?? '';
    $description = $input['description'] ?? '';
    $tags = $input['tags'] ?? null;
    $unit = $input['unit'] ?? ''; // New field
    $is_favorite = isset($input['is_favorite']) ? ($input['is_favorite'] ? 1 : 0) : 0;
    $items = $input['items'] ?? [];

    if (empty($name))
        throw new Exception("Name required");

    $db->beginTransaction();
    try {
        // Calculate total price from items
        $total_price = 0;
        foreach ($items as $item) {
            $qty = floatval($item['quantity'] ?? 0);
            $uprice = floatval($item['unit_price'] ?? 0);
            $total_price += $qty * $uprice;
        }

        if ($id) {
            $stmt = $db->prepare("UPDATE dd_price_catalog_bundles SET name = ?, description = ?, tags = ?, unit = ?, total_price = ?, is_favorite = ? WHERE id = ?");
            $stmt->execute([$name, $description, $tags, $unit, $total_price, $is_favorite, $id]);
        } else {
            $stmt = $db->prepare("INSERT INTO dd_price_catalog_bundles (name, description, tags, unit, total_price, is_favorite) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$name, $description, $tags, $unit, $total_price, $is_favorite]);
            $id = $db->lastInsertId();
        }

        // Handle items
        $stmt = $db->prepare("DELETE FROM dd_price_catalog_bundle_items WHERE bundle_id = ?");
        $stmt->execute([$id]);

        $stmt = $db->prepare("
            INSERT INTO dd_price_catalog_bundle_items (bundle_id, catalog_id, quantity, unit, unit_price, sort_order)
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        foreach ($items as $idx => $item) {
            $stmt->execute([
                $id,
                $item['catalog_id'],
                $item['quantity'] ?? 1.0,
                $item['unit'] ?? '',
                $item['unit_price'] ?? 0.0,
                $idx
            ]);
        }

        $db->commit();
        return ['success' => true, 'id' => $id];
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

function delete_bundle($db)
{
    $id = $_GET['id'] ?? null;
    if (!$id)
        throw new Exception("ID required");

    $stmt = $db->prepare("DELETE FROM dd_price_catalog_bundles WHERE id = ?");
    $stmt->execute([$id]);

    return ['success' => true];
}

function toggle_favorite_bundle($db)
{
    $input = json_decode(file_get_contents('php://input'), true);
    $id = $input['id'] ?? null;
    $state = $input['state'] ?? null;

    if (!$id)
        throw new Exception("ID required");

    $stmt = $db->prepare("UPDATE dd_price_catalog_bundles SET is_favorite = ? WHERE id = ?");
    $stmt->execute([$state ? 1 : 0, $id]);

    return ['success' => true];
}

function update_tags_bundle($db)
{
    $input = json_decode(file_get_contents('php://input'), true);
    $id = $input['id'] ?? null;
    $tags = $input['tags'] ?? '';

    if (!$id)
        throw new Exception("ID required");

    $stmt = $db->prepare("UPDATE dd_price_catalog_bundles SET tags = ? WHERE id = ?");
    $stmt->execute([$tags, $id]);

    return ['success' => true];
}
