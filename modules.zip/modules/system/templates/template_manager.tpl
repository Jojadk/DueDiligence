<div class="dd-page-header">
    <div style="display: flex; justify-content: space-between; align-items: center; width: 100%;">
        <div>
            <h1>Skabeloner</h1>
            <p>Administrer standardstrukturer til bygningsdele</p>
        </div>
        <button class="dd-btn-primary" onclick="App.system.openCreateTemplateModal()">
            <span class="material-icons">add</span>
            Ny Skabelon
        </button>
    </div>
</div>

<div id="template-manager-container" class="dd-content-card" style="margin-top: 1.5rem;">
    <div id="templates-list-container" style="display: grid; gap: 1rem; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));">
        <!-- Templates will be loaded here -->
        <div class="dd-loading">Henter skabeloner...</div>
    </div>
</div>

<style>
    .template-card {
        padding: 1.5rem;
        border: 1px solid var(--gray-200);
        border-radius: var(--radius-md);
        background: white;
        transition: all 0.2s;
    }
    .template-card:hover {
        border-color: var(--primary-500);
        box-shadow: var(--shadow-md);
    }
    .template-card-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 1rem;
    }
    .template-card-title {
        font-weight: 600;
        font-size: 1.125rem;
        color: var(--gray-900);
    }
    .template-card-desc {
        color: var(--gray-500);
        font-size: 0.875rem;
        line-height: 1.4;
        margin-bottom: 1.5rem;
    }
    .template-card-actions {
        display: flex;
        gap: 0.5rem;
        border-top: 1px solid var(--gray-100);
        padding-top: 1rem;
    }
</style>

<script>
    // System Template Manager Logic
    App.system = App.system || {};

    // Polyfill for App.modal.confirm if it doesn't exist
    if (!App.modal.confirm) {
        App.modal.confirm = function(body, onConfirm, title) {
            // Assign the callback to a global temporary handler
            App.system._currentConfirmCallback = onConfirm;
            
            const buttons = [
                { label: 'Annuller', class: 'dd-btn-secondary', onclick: 'App.modal.close()' },
                { label: 'Gem', class: 'dd-btn-primary', onclick: 'App.system._handleConfirmClick()' }
            ];
            
            const content = App.utils.renderModal(body, buttons);
            App.modal.show(content, title, 'small');
        };
        
        App.system._handleConfirmClick = async function() {
            if (App.system._currentConfirmCallback) {
                const btn = document.querySelector('.dd-modal .dd-btn-primary');
                if(btn) {
                    const originalText = btn.innerHTML;
                    btn.innerHTML = '<div class="dd-spinner-white"></div>';
                    btn.disabled = true;
                    
                    try {
                        const result = await App.system._currentConfirmCallback();
                        if (result !== false) {
                            App.modal.close();
                        } else {
                             // Revert button if validation failed (returned false)
                             btn.innerHTML = originalText;
                             btn.disabled = false;
                        }
                    } catch(e) {
                         console.error(e);
                         btn.innerHTML = originalText;
                         btn.disabled = false;
                    }
                } else {
                    // Fallback if button not found (rare)
                     const result = await App.system._currentConfirmCallback();
                     if (result !== false) App.modal.close();
                }
            }
        };
    }

    // Simplified System Template Manager Logic
    App.system = App.system || {};

    App.system.initTemplateManager = async function() {
        try {
            const res = await App.core.ajax('api.php?module=elements&action=template_list');
            const templates = (res.data && res.data.data) ? res.data.data : (Array.isArray(res.data) ? res.data : []);
            this.renderTemplates(templates);
        } catch (e) {
            console.error(e);
            App.core.toast('error', 'Kunne ikke hente skabeloner');
        }
    };

    App.system.renderTemplates = function(templates) {
        const container = document.getElementById('templates-list-container');
        if (!container) return;

        if (templates.length === 0) {
            container.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 3rem; color: var(--gray-400);">Ingen skabeloner fundet. Opret en ny for at komme i gang.</div>';
            return;
        }

        container.innerHTML = templates.map(t => `
            <div class="template-card">
                <div class="template-card-header">
                    <div class="template-card-title">${t.name}</div>
                    <div class="dd-badge dd-badge-info">${t.node_count || 0} noder</div>
                </div>
                <div class="template-card-desc">${t.description || 'Ingen beskrivelse'}</div>
                <div class="template-card-actions">
                    <button class="dd-btn-secondary dd-btn-sm" onclick="App.system.openTemplateEditor(${t.id})">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                        Rediger
                    </button>
                    <button class="dd-btn-secondary dd-btn-sm" style="color: var(--red-600);" onclick="App.system.deleteTemplate(${t.id})">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                    </button>
                </div>
            </div>
        `).join('');
    };

    App.system.openCreateTemplateModal = function() {
        const body = `
            <div class="dd-form-row">
                <label class="dd-label">Navn</label>
                <input type="text" id="tpl-name" class="dd-input" placeholder="F.eks. Standard Bolig">
            </div>
            <div class="dd-form-row">
                <label class="dd-label">Beskrivelse</label>
                <textarea id="tpl-desc" class="dd-input" rows="3"></textarea>
            </div>
        `;
        
        // Simple manual modal implementation since we removed the polyfill to clean up
        const buttons = [
             { label: 'Annuller', class: 'dd-btn-secondary', onclick: 'App.modal.close()' },
             { label: 'Opret', class: 'dd-btn-primary', onclick: 'App.system.handleCreateTemplate()' }
        ];
        App.modal.show(App.utils.renderModal(body, buttons), 'Opret Skabelon', 'small');
    };

    App.system.handleCreateTemplate = async function() {
        const name = document.getElementById('tpl-name').value;
        const desc = document.getElementById('tpl-desc').value;
        if (!name) return;

        try {
            const res = await App.core.ajax('api.php?module=elements&action=template_create', {
                method: 'POST',
                body: { name, description: desc }
            });
            App.modal.close();
            App.system.initTemplateManager();
            // Open editor for the new template
            if(res.id) App.system.openTemplateEditor(res.id);
        } catch (e) {
            App.core.toast('error', e.message);
        }
    };

    // Open the Modal Shell
    App.system.openTemplateEditor = async function(id) {
        try {
            // First fetch basic info to set title
            const res = await App.core.ajax('api.php?module=elements&action=template_get_config&template_id=' + id);
            const data = res.data || {};
            
            // Add Styles for Drag Indicators
            const styles = `
                <style>
                    .dd-drag-indicator-top { position: absolute; top: 0; left: 0; width: 100%; height: 3px; background: var(--primary-500); display: none; z-index: 50; pointer-events: none; border-radius: 2px; }
                    .dd-drag-indicator-bottom { position: absolute; bottom: 0; left: 0; width: 100%; height: 3px; background: var(--primary-500); display: none; z-index: 50; pointer-events: none; border-radius: 2px; }
                    .dd-drag-indicator-left { position: absolute; top: 0; left: 0; width: 4px; height: 100%; background: var(--warning-500); display: none; z-index: 50; pointer-events: none; }
                    .dd-drag-indicator-box { position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: 2px solid var(--primary-500); background: rgba(var(--primary-500-rgb), 0.1); display: none; z-index: 40; pointer-events: none; border-radius: var(--radius-sm); }
                    .template-node-row { transition: background 0.1s; }

                    /* Ratings Ribbon Styles */
                    .dd-ratings-ribbon {
                        display: grid;
                        grid-template-columns: 1fr 1fr 1fr;
                        gap: 15px;
                        background: #f8fafc;
                        border: 1px solid #e2e8f0;
                        border-radius: 8px;
                        padding: 12px;
                        margin-bottom: 20px;
                    }
                    .rating-ribbon-item { display: flex; flex-direction: column; }
                    .rating-header-label {
                        font-size: 10px;
                        text-transform: uppercase;
                        color: var(--gray-500);
                        font-weight: 700;
                        margin-bottom: 6px;
                        letter-spacing: 0.5px;
                    }
                    .risk-multi-select {
                        display: flex;
                        align-items: center;
                        gap: 6px;
                        flex-wrap: wrap;
                        min-height: 32px;
                        background: white;
                        border: 1px solid var(--gray-200);
                        border-radius: 6px;
                        padding: 4px;
                    }
                    .risk-tag {
                        display: flex;
                        align-items: center;
                        gap: 4px;
                        padding: 2px 8px;
                        border-radius: 4px;
                        font-size: 0.75rem;
                        font-weight: 600;
                        background: var(--gray-100);
                        border: 1px solid var(--gray-200);
                    }
                    .risk-tag.risk-red { background: #fee2e2; color: #991b1b; border-color: #fecaca; }
                    .risk-tag.risk-yellow { background: #fef9c3; color: #854d0e; border-color: #fef08a; }
                    .risk-tag.risk-green { background: #dcfce7; color: #166534; border-color: #bbf7d0; }
                    .risk-tag.risk-blue { background: #dbeafe; color: #1e40af; border-color: #bfdbfe; }
                    .risk-tag.risk-gray { background: #f1f5f9; color: #475569; border-color: #e2e8f0; }
                    
                    .remove-risk { cursor: pointer; opacity: 0.5; margin-left: 4px; }
                    .remove-risk:hover { opacity: 1; }
                    
                    .add-risk-btn {
                        width: 20px; height: 20px; border-radius: 50%;
                        border: 1px dashed var(--gray-300);
                        display: flex; align-items: center; justify-content: center;
                        color: var(--gray-400); cursor: pointer; font-size: 10px;
                    }
                    .add-risk-btn:hover { border-color: var(--primary-500); color: var(--primary-500); }
                </style>
            `;

            const body = styles + `
                <div style="background: var(--gray-50); padding: 1rem; border-radius: var(--radius-sm); margin-bottom: 1rem; border: 1px solid var(--gray-200);">
                     <div class="dd-form-row">
                        <label class="dd-label">Navn</label>
                        <input type="text" id="tpl-edit-name" class="dd-input" value="${data.name || ''}" placeholder="Skabelon Navn">
                    </div>
                    <div class="dd-form-row" style="margin-bottom: 0;">
                        <label class="dd-label">Beskrivelse</label>
                        <textarea id="tpl-edit-desc" class="dd-input" rows="2">${data.description || ''}</textarea>
                    </div>
                </div>

                <div style="margin-bottom: 0.5rem; display: flex; justify-content: space-between; align-items: center;">
                    <div style="display: flex; align-items: center; gap: 1rem;">
                        <div style="font-size: 0.875rem; color: var(--gray-500);">Struktur (Drag & Drop)</div>
                        <div id="bulk-actions-container" style="display: none; align-items: center; gap: 0.5rem;">
                             <button class="dd-btn-secondary dd-btn-sm" onclick="App.system.openBulkEditNodes(${id})">
                                <span class="material-icons" style="font-size: 16px; margin-right: 4px;">edit</span>
                                Bulk Rediger (<span id="selected-count">0</span>)
                            </button>
                        </div>
                    </div>
                    <button class="dd-btn-primary dd-btn-sm" onclick="App.system.addNode(${id})">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                        <span style="margin-left: 0.5rem;">Tilføj Node</span>
                    </button>
                </div>
                <!-- Container for content refresh -->
                <div id="template-editor-nodes-container">
                    <div style="padding: 2rem; text-align: center;">Indlæser struktur...</div>
                </div>
            `;
            
            const buttons = [
                 { label: 'Luk', class: 'dd-btn-secondary', onclick: 'App.modal.close()' },
                 { label: 'Gem Ændringer', class: 'dd-btn-primary', onclick: `App.system.updateTemplateMetadata(${id})` }
            ];

            const winId = 'template-editor-' + id;
            App.wm.open(winId, 'Rediger Skabelon: ' + (data.name || 'Ny'), App.utils.renderModal(body, buttons), {
                size: 'large',
                width: 1000,
                height: 'auto', 
                isModal: true,
                type: 'html'
            });
            
            // Load content with slight delay to ensure DOM is ready
            setTimeout(() => App.system.loadTemplateStructure(id), 50);

        } catch (e) {
            console.error(e);
            App.core.toast('error', 'Kunne ikke åbne editor');
        }
    };

    // Load and Render only the tree part
    App.system.loadTemplateStructure = async function(id) {
        const container = document.getElementById('template-editor-nodes-container');
        if (!container) return; 

        try {
            const res = await App.core.ajax('api.php?module=elements&action=template_get_config&template_id=' + id);
            const structure = (res.data && res.data.structure) ? res.data.structure : [];
            App.system._cachedStructure = structure; 
            App.system.renderTemplateTree(structure, container, id);
        } catch(e) {
            container.innerHTML = '<div style="color:red; padding:1rem;">Fejl ved indlæsning: ' + e.message + '</div>';
        }
    };

    App.system.renderTemplateTree = function(structure, container, templateId) {
        const icons = {
            folder: `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-folder"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>`,
            file: `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file-text"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>`,
            edit: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit-2"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg>`,
            trash: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>`
        };

        const renderNode = (n, level = 0) => {
            const hasStandards = n.observation || n.recommendation || n.risk_level || n.condition_rating || n.quality_rating;
            return `
            <div class="template-node-row" 
                 draggable="true" 
                 data-id="${n.id}" 
                 data-parent-id="${n.parent_id || ''}" 
                 data-level="${level}"
                 style="padding-left: ${level * 1.5 + 0.5}rem; display: flex; align-items: center; padding-right: 0.5rem; padding-top:0.5rem; padding-bottom:0.5rem; border-bottom: 1px solid var(--gray-100); cursor: move; position: relative;"
                 ondragstart="App.system.handleDragStart(event, ${n.id})"
                 ondragover="App.system.handleDragOver(event)"
                 ondragleave="App.system.handleDragLeave(event)"
                 ondrop="App.system.handleDrop(event, ${n.id}, ${n.element_type === 'section'}, ${templateId})">
                
                <!-- Checkbox for bulk -->
                <input type="checkbox" class="node-bulk-cb" value="${n.id}" style="margin-right: 0.75rem; cursor: pointer;" onchange="App.system.handleNodeSelection()">

                <!-- Indicators -->
                <div class="dd-drag-indicator-top"></div>
                <div class="dd-drag-indicator-bottom"></div>
                <div class="dd-drag-indicator-left"></div>
                <div class="dd-drag-indicator-box"></div>
                
                <span style="margin-right: 0.5rem; color: var(--gray-400); display: flex;">${n.element_type === 'section' ? icons.folder : icons.file}</span>
                <span style="flex-grow: 1; font-size: 14px; ${hasStandards ? 'font-weight:600; color:var(--primary-700);' : ''}">${n.name} ${hasStandards ? '<small style="font-weight:400; font-size:10px; opacity:0.6;">(Standardsat)</small>' : ''}</span>
                <div style="display: flex; gap: 0.25rem;">
                    <button class="dd-btn-icon" title="Rediger" onclick="App.system.editNode(${n.id}, ${templateId})">
                        ${icons.edit}
                    </button>
                    <button class="dd-btn-icon" title="Slet" style="color: var(--red-500);" onclick="App.system.deleteNode(${n.id}, ${templateId})">
                        ${icons.trash}
                    </button>
                </div>
            </div>
            ${(n.children || []).map(c => renderNode(c, level + 1)).join('')}
        `;};

        const html = `
            <div id="template-editor-nodes" style="height: 50vh; max-height: 500px; overflow-y: auto; border: 1px solid var(--gray-200); border-radius: var(--radius-sm); background: white;">
                <div style="padding: 0.5rem 1rem; background: var(--gray-50); border-bottom: 1px solid var(--gray-200); display: flex; align-items: center;">
                    <input type="checkbox" id="node-select-all" style="margin-right: 0.75rem;" onchange="App.system.toggleSelectAllNodes(this)">
                    <label for="node-select-all" style="font-size: 12px; color: var(--gray-500); cursor: pointer;">Vælg alle</label>
                </div>
                ${structure.length > 0 ? structure.map(n => renderNode(n)).join('') : '<div style="padding: 2rem; text-align: center; color: var(--gray-400);">Ingen noder endnu. Brug "Tilføj Node".</div>'}
            </div>
        `;
        container.innerHTML = html;
    };

    App.system.handleNodeSelection = function() {
        const selected = document.querySelectorAll('.node-bulk-cb:checked');
        const count = selected.length;
        const container = document.getElementById('bulk-actions-container');
        const countEl = document.getElementById('selected-count');
        
        if (count > 0) {
            container.style.display = 'flex';
            countEl.textContent = count;
        } else {
            container.style.display = 'none';
        }
    };

    App.system.toggleSelectAllNodes = function(cb) {
        document.querySelectorAll('.node-bulk-cb').forEach(el => {
            el.checked = cb.checked;
        });
        App.system.handleNodeSelection();
    };
    
    // Update Metadata
    App.system.updateTemplateMetadata = async function(id) {
        const name = document.getElementById('tpl-edit-name').value;
        const desc = document.getElementById('tpl-edit-desc').value;
        if (!name) return;

        try {
            await App.core.ajax('api.php?module=elements&action=template_update', {
                method: 'POST',
                body: { id, name, description: desc }
            });
            App.core.toast('success', 'Skabelon opdateret');
            App.system.initTemplateManager(); // Refresh list background
        } catch (e) {
            App.core.toast('error', e.message);
        }
    };

    // Drag and Drop Logic
    App.system.dragSource = null;

    App.system.handleDragStart = function(e, id) {
        App.system.dragSource = { id };
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', id);
        e.target.style.opacity = '0.4';
    };
    
    App.system.handleDragLeave = function(e) {
         const row = e.currentTarget;
         row.querySelectorAll('div[class^="dd-drag-indicator-"]').forEach(el => el.style.display = 'none');
         row.style.background = '';
    };

    App.system.handleDragOver = function(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        
        const row = e.currentTarget;
        const rect = row.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const width = rect.width;
        const height = rect.height;
        
        // Hide all indicators initially
        row.querySelectorAll('div[class^="dd-drag-indicator-"]').forEach(el => el.style.display = 'none');
        row.style.background = '';

        // Check Zones
        if (x < width * 0.2) {
             // LEFT: Outdent
             row.querySelector('.dd-drag-indicator-left').style.display = 'block';
        } else if (x > width * 0.8) {
             // RIGHT: Child/Nest
             row.querySelector('.dd-drag-indicator-box').style.display = 'block';
        } else {
             // MID: Sibling
             if (y < height * 0.5) {
                 // Top half -> Before
                 row.querySelector('.dd-drag-indicator-top').style.display = 'block';
             } else {
                 // Bottom half -> After
                 row.querySelector('.dd-drag-indicator-bottom').style.display = 'block';
             }
        }
        return false;
    };

    App.system.handleDrop = async function(e, targetId, isTargetSection, templateId) {
        e.stopPropagation();
        e.preventDefault();
        
        if (!App.system.dragSource || !App.system.dragSource.id) {
             console.error("No drag source found");
             return false;
        }

        const sourceId = App.system.dragSource.id;
        if (sourceId == targetId) return;

        // Reset styling
        document.querySelectorAll('.template-node-row').forEach(el => {
             el.querySelectorAll('div[class^="dd-drag-indicator-"]').forEach(i => i.style.display = 'none');
             el.style.background = '';
        });

        const rect = e.currentTarget.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const width = rect.width;
        const height = rect.height;

        let position = 0; // 0=inside, -1=before, -2=after
        let finalTargetId = targetId;

        // Calculate Zone Logic
         if (x < width * 0.2) {
            // LEFT ZONE: Un-nest (After Parent)
            const parentId = e.currentTarget.getAttribute('data-parent-id');
            if (parentId && parentId !== '') {
                finalTargetId = parentId; 
                position = -2; // After parent
            } else {
                position = -2; // After root (remain root)
            }
        } 
        else if (x > width * 0.8) {
             // RIGHT ZONE: Child
             if (isTargetSection) {
                 position = 0; // Inside
             } else {
                 position = -2; // Fallback to sibling after if target is file
             }
        } 
        else {
             // MID ZONE: Sibling
             if (y < height * 0.5) {
                 position = -1; // Before
             } else {
                 position = -2; // After
             }
        }

        try {
             await App.core.ajax('api.php?module=elements&action=template_node_move', {
                 method: 'POST',
                 body: {
                     id: sourceId,
                     target_id: finalTargetId,
                     position: position,
                     template_id: templateId
                 }
            });
            App.system.loadTemplateStructure(templateId); 
        } catch (err) {
            App.core.toast('error', 'Kunne ikke flytte node: ' + err.message);
        }
        
        return false;
    };

    App.system.addNode = function(templateId, parentId = null) {
        // We do a flattened tree for the select dropdown
        const flatten = (nodes, depth=0, list=[]) => {
            nodes.forEach(n => {
                if(n.element_type === 'section') {
                    list.push({id: n.id, name: '- '.repeat(depth) + n.name});
                    if(n.children) flatten(n.children, depth+1, list);
                }
            });
            return list;
        };
        const sections = flatten(App.system._cachedStructure || []);
        const parentOptions = sections.map(s => `<option value="${s.id}" ${s.id == parentId ? 'selected' : ''}>${s.name}</option>`).join('');

        const body = `
            <div class="dd-form-row">
                <label class="dd-label">Navn</label>
                <input type="text" id="node-name" class="dd-input" placeholder="F.eks. Fundament">
            </div>
            <div class="dd-form-row">
                <label class="dd-label">Type</label>
                <select id="node-type" class="dd-input">
                    <option value="section">Afsnit (Folder)</option>
                    <option value="element">Bygningsdel</option>
                </select>
            </div>
            <div class="dd-form-row">
                <label class="dd-label">Placering (Forælder)</label>
                <select id="node-parent" class="dd-input">
                    <option value="">Topniveau (Ingen forælder)</option>
                    ${parentOptions}
                </select>
            </div>
        `;
        
        const saveNode = async () => {
             const name = document.getElementById('node-name').value;
             const type = document.getElementById('node-type').value;
             const pid = document.getElementById('node-parent').value;
             if (!name) return;
             try {
                await App.core.ajax('api.php?module=elements&action=template_node_create', {
                    method: 'POST',
                    body: { template_id: templateId, parent_id: pid, name, element_type: type }
                });
                App.modal.close();
                App.system.openTemplateEditor(templateId); // Re-open editor after sub-modal
             } catch(e) { App.core.toast('error', e.message); }
        };

        const buttons = [
             { label: 'Annuller', class: 'dd-btn-secondary', onclick: 'App.modal.close()' },
             { label: 'Tilføj', class: 'dd-btn-primary', onclick: 'App.system._currentSaveNode()' }
        ];
        
        App.system._currentSaveNode = saveNode;
        App.modal.show(App.utils.renderModal(body, buttons), 'Tilføj Node', 'small');
    };

    App.system.findNodeById = function(id, nodes = null) {
        if (!nodes) nodes = App.system._cachedStructure || [];
        for (const n of nodes) {
            if (n.id == id) return n;
            if (n.children) {
                const found = App.system.findNodeById(id, n.children);
                if (found) return found;
            }
        }
        return null;
    };

    App.system.editNode = function(id, templateId) {
        const node = App.system.findNodeById(id);
        if (!node) return App.core.toast('error', 'Node ikke fundet');

        const body = `
            <div class="dd-form-row">
                <label class="dd-label">Navn</label>
                <input type="text" id="node-edit-name" class="dd-input" value="${node.name || ''}">
            </div>
            <div class="dd-form-row">
                <label class="dd-label">Observation (Standard)</label>
                <textarea id="node-edit-observation" class="dd-input" rows="3">${node.observation || ''}</textarea>
            </div>
            <div class="dd-form-row">
                <label class="dd-label">Anbefaling (Standard)</label>
                <textarea id="node-edit-recommendation" class="dd-input" rows="3">${node.recommendation || ''}</textarea>
            </div>
            <div class="dd-ratings-ribbon">
                <div class="rating-ribbon-item">
                    <span class="rating-header-label">Risiko (Standard)</span>
                    <div id="risk-select-container" class="risk-multi-select"></div>
                </div>
                <div class="rating-ribbon-item">
                     <span class="rating-header-label">Tilstand (Standard)</span>
                     <div id="condition-select-container" class="risk-multi-select"></div>
                </div>
                <div class="rating-ribbon-item">
                     <span class="rating-header-label">Kvalitet (Standard)</span>
                     <div id="quality-select-container" class="risk-multi-select"></div>
                </div>
            </div>
        `;
        
        // Modal state management
        App.system._editingNodeState = {
            risk: (node.risk_level || '').split(',').filter(v => v),
            condition: (node.condition_rating || '').split(',').filter(v => v),
            quality: (node.quality_rating || '').split(',').filter(v => v)
        };

        const renderRibbons = () => {
            const riskCont = document.getElementById('risk-select-container');
            const condCont = document.getElementById('condition-select-container');
            const qualCont = document.getElementById('quality-select-container');
            if(!riskCont) return;

            const renderTags = (values, type) => {
                const getEmoji = (v, t) => {
                    if (t === 'risk') {
                        if (v.includes('Rød')) return '🔴';
                        if (v.includes('Gul')) return '🟡';
                        if (v.includes('Grøn')) return '🟢';
                        if (v.includes('Sort')) return '⚫️';
                        if (v.includes('Blå')) return '🔵';
                        return '⚪️';
                    } else {
                        if (v === 'God') return '🟢';
                        if (v === 'Fornuftig') return '🔵';
                        if (v === 'Acceptabel') return '🟡';
                        if (v === 'Forventet') return '⚪️';
                        if (v === 'Dårlig') return '🔴';
                        return '🔹';
                    }
                };

                const getColor = (v, t) => {
                    if (t === 'risk') {
                        if (v.includes('Rød')) return 'risk-red';
                        if (v.includes('Gul')) return 'risk-yellow';
                        if (v.includes('Grøn')) return 'risk-green';
                        if (v.includes('Sort')) return 'risk-black';
                        if (v.includes('Blå')) return 'risk-blue';
                        return 'risk-gray';
                    } else {
                        if (v === 'God') return 'risk-green';
                        if (v === 'Fornuftig') return 'risk-blue';
                        if (v === 'Acceptabel') return 'risk-yellow';
                        if (v === 'Forventet') return 'risk-gray';
                        if (v === 'Dårlig') return 'risk-red';
                        return 'risk-gray';
                    }
                };

                let html = values.map(v => {
                    return `
                        <div class="risk-tag ${getColor(v, type)}">
                            <span>${getEmoji(v, type)} ${v}</span>
                            <span class="remove-risk" onclick="App.system.toggleNodeRating('${type}', '${v}')"><i class="fas fa-times"></i></span>
                        </div>
                    `;
                }).join('');
                
                html += `<div class="add-risk-btn" onclick="App.system.showRatingDropdown(event, '${type}')"><i class="fas fa-plus"></i></div>`;
                return html;
            };

            riskCont.innerHTML = renderTags(App.system._editingNodeState.risk, 'risk');
            condCont.innerHTML = renderTags(App.system._editingNodeState.condition, 'condition');
            qualCont.innerHTML = renderTags(App.system._editingNodeState.quality, 'quality');
        };

        App.system.toggleNodeRating = function(type, val) {
            const list = App.system._editingNodeState[type];
            const idx = list.indexOf(val);
            if(idx > -1) list.splice(idx, 1);
            else list.push(val);
            renderRibbons();
        };

        App.system.showRatingDropdown = function(e, type) {
            e.stopPropagation();
            // Remove any existing dropdown
            const existing = document.getElementById('node-rating-dropdown');
            if (existing) existing.remove();

            const options = {
                risk: ['Rød', 'Gul', 'Grøn', 'Sort', 'Blå', 'Ikke relevant'],
                condition: ['God', 'Fornuftig', 'Acceptabel', 'Forventet', 'Dårlig'],
                quality: ['God', 'Fornuftig', 'Acceptabel', 'Forventet', 'Dårlig']
            }[type];

            const dropdown = document.createElement('div');
            dropdown.id = 'node-rating-dropdown';
            dropdown.className = 'dd-dropdown-menu';
            // High z-index to stay above modals (which are around 10000)
            dropdown.style.cssText = `
                display: block; 
                position: fixed; 
                min-width: 140px; 
                background: white; 
                border: 1px solid var(--gray-200); 
                z-index: 200000; 
                box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05); 
                border-radius: 6px;
                padding: 4px 0;
            `;

            const getEmoji = (v, t) => {
                if (t === 'risk') {
                    if (v.includes('Rød')) return '🔴';
                    if (v.includes('Gul')) return '🟡';
                    if (v.includes('Grøn')) return '🟢';
                    if (v.includes('Sort')) return '⚫️';
                    if (v.includes('Blå')) return '🔵';
                    return '⚪️';
                } else {
                    if (v === 'God') return '🟢';
                    if (v === 'Fornuftig') return '🔵';
                    if (v === 'Acceptabel') return '🟡';
                    if (v === 'Forventet') return '⚪️';
                    if (v === 'Dårlig') return '🔴';
                    return '🔹';
                }
            };

            dropdown.innerHTML = options.map(opt => `
                <div class="dropdown-item" style="padding: 8px 12px; cursor: pointer; font-size: 13px; transition: background 0.1s;" 
                     onmouseover="this.style.background='var(--gray-50)'" 
                     onmouseout="this.style.background='transparent'"
                     onclick="App.system.toggleNodeRating('${type}', '${opt}'); document.getElementById('node-rating-dropdown').remove();">
                    ${getEmoji(opt, type)} ${opt}
                </div>
            `).join('');
            
            document.body.appendChild(dropdown);
            
            // Precise positioning relative to the button
            const rect = e.currentTarget.getBoundingClientRect();
            const dropdownHeight = dropdown.offsetHeight;
            const spaceBelow = window.innerHeight - rect.bottom;
            
            if (spaceBelow < 200 && rect.top > 200) {
                // Not enough space below, open above
                dropdown.style.top = (rect.top - dropdown.scrollHeight - 5) + 'px';
            } else {
                dropdown.style.top = (rect.bottom + 5) + 'px';
            }
            dropdown.style.left = rect.left + 'px';

            // Close when clicking outside or resizing/scrolling
            const close = (ev) => { 
                if (!dropdown.contains(ev.target) && ev.target !== e.currentTarget) { 
                    dropdown.remove(); 
                    cleanup();
                } 
            };
            
            const cleanup = () => {
                document.removeEventListener('mousedown', close);
                window.removeEventListener('scroll', cleanup, true);
                window.removeEventListener('resize', cleanup);
            };

            setTimeout(() => {
                document.addEventListener('mousedown', close);
                window.addEventListener('scroll', cleanup, true);
                window.addEventListener('resize', cleanup);
            }, 10);
        };
        
        const updateNode = async () => {
             const data = {
                 id: id,
                 name: document.getElementById('node-edit-name').value,
                 element_type: node.element_type,
                 sort_order: node.sort_order,
                 observation: document.getElementById('node-edit-observation').value,
                 recommendation: document.getElementById('node-edit-recommendation').value,
                 risk_level: App.system._editingNodeState.risk.join(','),
                 condition_rating: App.system._editingNodeState.condition.join(','),
                 quality_rating: App.system._editingNodeState.quality.join(',')
             };
             
             if (!data.name) return;
             try {
                await App.core.ajax('api.php?module=elements&action=template_node_update', {
                    method: 'POST',
                    body: data
                });
                App.modal.close();
                if (templateId) App.system.loadTemplateStructure(templateId); 
             } catch(e) { App.core.toast('error', e.message); }
        };

        const buttons = [
             { label: 'Annuller', class: 'dd-btn-secondary', onclick: 'App.modal.close()' },
             { label: 'Gem', class: 'dd-btn-primary', onclick: 'App.system._currentUpdateNode()' }
        ];
        App.system._currentUpdateNode = updateNode;
        App.modal.show(App.utils.renderModal(body, buttons), 'Rediger Node', 'medium'); 
        
        // Init ribbons after modal show
        setTimeout(renderRibbons, 50);
    };

    App.system.openBulkEditNodes = function(templateId) {
        const selectedIds = Array.from(document.querySelectorAll('.node-bulk-cb:checked')).map(cb => cb.value);
        if (selectedIds.length === 0) return;

        const body = `
            <div style="margin-bottom: 1rem; padding: 0.75rem; background: var(--blue-50); border: 1px solid var(--blue-200); border-radius: 4px; font-size: 0.875rem;">
                Du redigerer nu ${selectedIds.length} valgte noder. De værdier du udfylder herunder vil overskrive eksisterende standarder på de valgte noder.
            </div>
            <div class="dd-form-row">
                <label class="dd-label">Observation (Standard)</label>
                <textarea id="bulk-edit-observation" class="dd-input" rows="2" placeholder="Overskriv alle valgte..."></textarea>
            </div>
            <div class="dd-form-row">
                <label class="dd-label">Anbefaling (Standard)</label>
                <textarea id="bulk-edit-recommendation" class="dd-input" rows="2" placeholder="Overskriv alle valgte..."></textarea>
            </div>
            <div class="dd-grid" style="grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div class="dd-form-row">
                    <label class="dd-label">Risiko (Standard)</label>
                    <select id="bulk-edit-risk" class="dd-input">
                        <option value="KEEP">Behold eksisterende</option>
                        <option value="">Ingen</option>
                        <option value="Rød">🔴 Rød</option>
                        <option value="Gul">🟡 Gul</option>
                        <option value="Grøn">🟢 Grøn</option>
                        <option value="Sort">⚫️ Sort</option>
                        <option value="Blå">🔵 Blå</option>
                        <option value="Ikke relevant">⚪️ Ikke relevant</option>
                    </select>
                </div>
                <div class="dd-form-row">
                    <label class="dd-label">Tilstand (Standard)</label>
                    <select id="bulk-edit-condition" class="dd-input">
                        <option value="KEEP">Behold eksisterende</option>
                        <option value="">Ingen</option>
                        <option value="God">🟢 God</option>
                        <option value="Fornuftig">🔵 Fornuftig</option>
                        <option value="Acceptabel">🟡 Acceptabel</option>
                        <option value="Forventet">⚪️ Forventet</option>
                        <option value="Dårlig">🔴 Dårlig</option>
                    </select>
                </div>
            </div>
            <div class="dd-form-row">
                <label class="dd-label">Kvalitet (Standard)</label>
                <select id="bulk-edit-quality" class="dd-input">
                    <option value="KEEP">Behold eksisterende</option>
                    <option value="">Ingen</option>
                    <option value="God">🟢 God</option>
                    <option value="Fornuftig">🔵 Fornuftig</option>
                    <option value="Acceptabel">🟡 Acceptabel</option>
                    <option value="Forventet">⚪️ Forventet</option>
                    <option value="Dårlig">🔴 Dårlig</option>
                </select>
            </div>
        `;

        const applyBulk = async () => {
            const obs = document.getElementById('bulk-edit-observation').value;
            const rec = document.getElementById('bulk-edit-recommendation').value;
            const risk = document.getElementById('bulk-edit-risk').value;
            const cond = document.getElementById('bulk-edit-condition').value;
            const qual = document.getElementById('bulk-edit-quality').value;

            App.core.toast('info', 'Arbejder på bulk opdatering...');
            
            try {
                for (const id of selectedIds) {
                    const node = App.system.findNodeById(id);
                    if (!node) continue;

                    const data = {
                        id: id,
                        name: node.name,
                        element_type: node.element_type,
                        sort_order: node.sort_order,
                        observation: obs || node.observation,
                        recommendation: rec || node.recommendation,
                        risk_level: risk === 'KEEP' ? node.risk_level : risk,
                        condition_rating: cond === 'KEEP' ? node.condition_rating : cond,
                        quality_rating: qual === 'KEEP' ? node.quality_rating : qual
                    };

                    await App.core.ajax('api.php?module=elements&action=template_node_update', {
                        method: 'POST',
                        body: data
                    });
                }
                App.modal.close();
                App.system.loadTemplateStructure(templateId);
                App.core.toast('success', 'Bulk opdatering fuldført');
            } catch (e) {
                App.core.toast('error', 'En fejl opstod under bulk opdatering: ' + e.message);
            }
        };

        const buttons = [
            { label: 'Annuller', class: 'dd-btn-secondary', onclick: 'App.modal.close()' },
            { label: 'Anvend på alle', class: 'dd-btn-primary', onclick: 'App.system._handleBulkApply()' }
        ];
        App.system._handleBulkApply = applyBulk;
        App.modal.show(App.utils.renderModal(body, buttons), 'Bulk Rediger Noder', 'medium');
    };

    // Fix: Redefine editNode and addNode to accept templateId so we can re-open.
    // I will update the renderNode string in openTemplateEditor to pass templateId.

    App.system.deleteNode = function(id, templateId) {
        App.alert.warning({
            title: 'Slet node',
            message: 'Er du sikker på du vil slette denne node?',
            onConfirm: async () => {
                try {
                    await App.core.ajax('api.php?module=elements&action=template_node_delete&id=' + id);
                    App.system.loadTemplateStructure(templateId);
                } catch (e) {
                    App.core.toast('error', e.message);
                }
            }
        });
    };

    App.system.deleteTemplate = function(id) {
        App.alert.warning({
            title: 'Slet skabelon',
            message: 'Er du sikker på at du vil slette denne skabelon?',
            onConfirm: async () => {
                try {
                    await App.core.ajax('api.php?module=elements&action=template_delete&id=' + id);
                    App.system.initTemplateManager();
                } catch(e) {
                    App.core.toast('error', e.message);
                }
            }
        });
    };

    App.system.initTemplateManager();
</script>
