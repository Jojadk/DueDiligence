<div class="module-header">
    <h1>Permissions Management</h1>
</div>

<div class="dd-card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
        <div>
            <h2 style="margin: 0;">Permissions</h2>
            <p style="margin: 0.25rem 0 0 0; color: var(--gray-500); font-size: 0.875rem;">Manage user group permissions</p>
        </div>
        <button id="btn-add-group-perm" name="btn_add_group_perm" class="dd-btn dd-btn-primary" onclick="App.system.showAddGroupModal()">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
            New Group
        </button>
    </div>

    <input type="text" id="permissions-search" name="permissions_search" class="dd-input" placeholder="Search groups..." style="margin-bottom: 1rem; max-width: 400px;" onkeyup="App.system.permissions.filter(this.value)">

    <div class="dd-table-wrapper">
        <table id="permissions-table" name="permissions_table" class="dd-table">
            <thead>
                <tr>
                    <th>Group Name</th>
                    <th>View All</th>
                    <th>Manage Projects</th>
                    <th>Manage Users</th>
                    <th>Manage Config</th>
                    <th style="text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody id="permissions-table-body">
                <tr><td colspan="6" style="text-align: center; padding: 2rem; color: var(--gray-500);">Loading...</td></tr>
            </tbody>
        </table>
    </div>
</div>

<script>
    App.system = App.system || {};
    App.system.permissions = {
        allGroups: [],
        
        init: function() {
            this.load();
        },
        load: async function() {
            const tbody = document.getElementById('permissions-table-body');
            try {
                const response = await App.core.ajax('api.php?module=system&action=get_user_groups');
                
                if (Array.isArray(response)) {
                    this.allGroups = response;
                } else if (response && Array.isArray(response.data)) {
                    this.allGroups = response.data;
                } else if (response && response.error) {
                    throw new Error(response.error);
                } else {
                    this.allGroups = [];
                    console.warn('Unexpected response format:', response);
                }
                
                this.filter();
            } catch (err) {
                tbody.innerHTML = `<tr><td colspan="6" style="color:red; text-align:center; padding: 2rem;">Error loading groups: ${err.message}</td></tr>`;
            }
        },
        
        filter: function(query) {
            const tbody = document.getElementById('permissions-table-body');
            if (!tbody) return;
            
            let data = this.allGroups;
            if (query) {
                const lowerQ = query.toLowerCase();
                data = data.filter(g => g.name.toLowerCase().includes(lowerQ));
            }
            
            if (data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;">No groups found.</td></tr>';
                return;
            }
            
            tbody.innerHTML = data.map(g => {
                const check = (val) => val == 1 ? '<span style="color:green;">Yes</span>' : '<span style="color:red; opacity:0.5;">No</span>';
                return `
                    <tr>
                        <td><strong>${g.name}</strong></td>
                        <td>${check(g.allow_view_all)}</td>
                        <td>${check(g.allow_manage_projects)}</td>
                        <td>${check(g.allow_manage_users)}</td>
                        <td>${check(g.allow_manage_configuration)}</td>
                        <td style="text-align: right;">
                            <button class="dd-btn-sm" onclick="App.system.editUserGroup(${g.id}, '${g.name}')">Edit</button>
                        </td>
                    </tr>
                `;
            }).join('');
        }
    };
    
    // Initialize
    App.system.permissions.init();
</script>
