<div class="dd-card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
        <div>
            <h2 style="margin: 0;">User Groups & Permissions</h2>
            <p style="margin: 0.25rem 0 0 0; color: var(--gray-500); font-size: 0.875rem;">Manage roles and access levels</p>
        </div>
        <button id="btn-add-group" name="btn_add_group" class="dd-btn dd-btn-primary" onclick="App.userGroups.showAddModal()">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
            New Group
        </button>
    </div>

    <input type="text" id="user-groups-search" name="user_groups_search" class="dd-input" placeholder="Search groups..." style="margin-bottom: 1rem; max-width: 400px;" onkeyup="App.userGroups.filter(this.value)">
    
    <div id="group-table-wrapper" class="dd-table-wrapper">
        <table id="user-groups-table" name="user_groups_table" class="dd-table">
            <thead>
                <tr>
                    <th onclick="App.userGroups.sort('name')" style="cursor: pointer;" data-sort="name">Group Name <span class="sort-icon">⇅</span></th>
                    <th>Permissions Summary</th>
                    <th onclick="App.userGroups.sort('created_at')" style="cursor: pointer;" data-sort="created_at">Created <span class="sort-icon">⇅</span></th>
                    <th style="text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody id="group-table-body">
                <tr><td colspan="4" style="text-align: center; padding: 2rem; color: var(--gray-500);">Loading groups...</td></tr>
            </tbody>
        </table>
    </div>
</div>

<script>
    window.App = window.App || {};
    window.App.userGroups = window.App.userGroups || {};

    if (typeof App.userGroups.init === 'undefined') {
        const script = document.createElement('script');
        script.src = 'public/js/admin-users.js?v=' + Date.now(); // user-groups logic is in admin-users.js
        script.onload = () => {
            if (App.userGroups.init) App.userGroups.init();
        };
        document.head.appendChild(script);
    } else {
        App.userGroups.init();
    }
</script>
