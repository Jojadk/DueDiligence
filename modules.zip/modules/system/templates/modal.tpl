<div class="dd-modal dd-{{size|raw}}" style="background: #fff; border-radius: 6px; position: relative; padding: 1rem; box-shadow: 0 4px 12px rgba(0,0,0,0.3); max-width: {{maxWidth|raw}};">
<div class="dd-modal-header" style="font-weight:600; margin-bottom:0.5rem;">{{title|raw}}</div>
        <button class="dd-modal-minimize" title="Minimize" style="border: none; background: transparent; cursor: pointer;">{{icon_minimize|raw}}</button>
        <button class="dd-modal-maximize" title="Maximize" style="border: none; background: transparent; cursor: pointer;">{{icon_maximize|raw}}</button>
        <button class="dd-modal-close" title="Close" style="border: none; background: transparent; cursor: pointer;">{{icon_close|raw}}</button>
    </div>
    <div class="dd-modal-body">
        {{body|raw}}
    </div>
</div>
