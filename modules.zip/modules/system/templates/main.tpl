<div class="dd-page-header">
    <h1>System Administration</h1>
    <p>Configure implementation details and system settings</p>
</div>

<div class="dd-settings-grid" style="
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: 1.5rem;
    padding: 1rem 0;
">
    <!-- User Management Card -->
    <div class="dd-card dd-setting-card" onclick="App.router.navigate(null, true, {module: 'system', template: 'users'})" style="
        cursor: pointer;
        transition: all 0.2s;
    " onmouseover="this.style.transform='translateY(-4px)'; this.style.boxShadow='var(--shadow-xl)'" onmouseout="this.style.transform=''; this.style.boxShadow='var(--shadow-sm)'">
        <div style="
            width: 48px;
            height: 48px;
            border-radius: var(--radius-lg);
            background: linear-gradient(135deg, #FF9A8B 0%, #FF6A88 55%, #FF99AC 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
        ">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                <circle cx="9" cy="7" r="4"/>
                <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
            </svg>
        </div>
        <h3 style="margin: 0 0 0.5rem 0; font-size: 1.125rem; font-weight: 600;">User Management</h3>
        <p style="margin: 0; color: var(--gray-600); font-size: 0.875rem; line-height: 1.5;">
            Create and manage users, passwords and account status.
        </p>
    </div>

    <!-- User Groups Card -->
    <div class="dd-card dd-setting-card" onclick="App.router.navigate(null, true, {module: 'system', template: 'user_groups'})" style="
        cursor: pointer;
        transition: all 0.2s;
    " onmouseover="this.style.transform='translateY(-4px)'; this.style.boxShadow='var(--shadow-xl)'" onmouseout="this.style.transform=''; this.style.boxShadow='var(--shadow-sm)'">
        <div style="
            width: 48px;
            height: 48px;
            border-radius: var(--radius-lg);
            background: linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
        ">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
        </div>
        <h3 style="margin: 0 0 0.5rem 0; font-size: 1.125rem; font-weight: 600;">Groups & Permissions</h3>
        <p style="margin: 0; color: var(--gray-600); font-size: 0.875rem; line-height: 1.5;">
            Define roles and set access level permissions for each group.
        </p>
    </div>

    <!-- Permissions Card -->
    <div class="dd-card dd-setting-card" onclick="App.router.navigate(null, true, {module: 'system', template: 'permissions'})" style="
        cursor: pointer;
        transition: all 0.2s;
    " onmouseover="this.style.transform='translateY(-4px)'; this.style.boxShadow='var(--shadow-xl)'" onmouseout="this.style.transform=''; this.style.boxShadow='var(--shadow-sm)'">
        <div style="
            width: 48px;
            height: 48px;
            border-radius: var(--radius-lg);
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
        ">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
                <path d="M12 15v2m-6 4h12a2 2 0 0 0 2-2v-6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2"/>
                <circle cx="12" cy="4" r="2"/>
            </svg>
        </div>
        <h3 style="margin: 0 0 0.5rem 0; font-size: 1.125rem; font-weight: 600;">Permissions</h3>
        <p style="margin: 0; color: var(--gray-600); font-size: 0.875rem; line-height: 1.5;">
            Manage user groups, roles, and access controls for the platform.
        </p>
    </div>

    <!-- Menu Manager Card -->
    <div class="dd-card dd-setting-card" onclick="App.router.navigate('?module=system&template=menu_manager')" style="
        cursor: pointer;
        transition: all 0.2s;
    " onmouseover="this.style.transform='translateY(-4px)'; this.style.boxShadow='var(--shadow-xl)'" onmouseout="this.style.transform=''; this.style.boxShadow='var(--shadow-sm)'">
        <div style="
            width: 48px;
            height: 48px;
            border-radius: var(--radius-lg);
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
        ">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
                <line x1="3" y1="12" x2="21" y2="12"/>
                <line x1="3" y1="6" x2="21" y2="6"/>
                <line x1="3" y1="18" x2="21" y2="18"/>
            </svg>
        </div>
        <h3 style="margin: 0 0 0.5rem 0; font-size: 1.125rem; font-weight: 600;">Menu Manager</h3>
        <p style="margin: 0; color: var(--gray-600); font-size: 0.875rem; line-height: 1.5;">
            Configure the sidebar navigation structure and icons.
        </p>
    </div>

    <!-- Element Templates Card -->
    <div class="dd-card dd-setting-card" onclick="App.router.navigate('?module=system&template=template_manager')" style="
        cursor: pointer;
        transition: all 0.2s;
    " onmouseover="this.style.transform='translateY(-4px)'; this.style.boxShadow='var(--shadow-xl)'" onmouseout="this.style.transform=''; this.style.boxShadow='var(--shadow-sm)'">
        <div style="
            width: 48px;
            height: 48px;
            border-radius: var(--radius-lg);
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
        ">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
                <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
                <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
            </svg>
        </div>
        <h3 style="margin: 0 0 0.5rem 0; font-size: 1.125rem; font-weight: 600;">Element Templates</h3>
        <p style="margin: 0; color: var(--gray-600); font-size: 0.875rem; line-height: 1.5;">
            Manage standard building element structures and templates.
        </p>
    </div>

    <div class="dd-card dd-setting-card" onclick="App.router.navigate('?module=system&template=audit_log')" style="
        cursor: pointer;
        transition: all 0.2s;
    " onmouseover="this.style.transform='translateY(-4px)'; this.style.boxShadow='var(--shadow-xl)'" onmouseout="this.style.transform=''; this.style.boxShadow='var(--shadow-sm)'">
        <div style="
            width: 48px;
            height: 48px;
            border-radius: var(--radius-lg);
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
        ">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                <polyline points="14 2 14 8 20 8"/>
                <line x1="16" y1="13" x2="8" y2="13"/>
                <line x1="16" y1="17" x2="8" y2="17"/>
                <polyline points="10 9 9 9 8 9"/>
            </svg>
        </div>
        <h3 style="margin: 0 0 0.5rem 0; font-size: 1.125rem; font-weight: 600;">Audit Log</h3>
        <p style="margin: 0; color: var(--gray-600); font-size: 0.875rem; line-height: 1.5;">
            View system activity logs and user actions history.
        </p>
    </div>

    <!-- PC Admin Card -->
    <div class="dd-card dd-setting-card" onclick="App.router.navigate('?module=price_catalogs&template=admin')" style="
        cursor: pointer;
        transition: all 0.2s;
    " onmouseover="this.style.transform='translateY(-4px)'; this.style.boxShadow='var(--shadow-xl)'" onmouseout="this.style.transform=''; this.style.boxShadow='var(--shadow-sm)'">
        <div style="
            width: 48px;
            height: 48px;
            border-radius: var(--radius-lg);
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
        ">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
            </svg>
        </div>
        <h3 style="margin: 0 0 0.5rem 0; font-size: 1.125rem; font-weight: 600;">Price Catalog</h3>
        <p style="margin: 0; color: var(--gray-600); font-size: 0.875rem; line-height: 1.5;">
            Manage categories, items, prices and favorites.
        </p>
    </div>

    <!-- System Settings Card -->
    <div class="dd-card dd-setting-card" onclick="App.router.navigate('?module=system&template=settings')" style="
        cursor: pointer;
        transition: all 0.2s;
    " onmouseover="this.style.transform='translateY(-4px)'; this.style.boxShadow='var(--shadow-xl)'" onmouseout="this.style.transform=''; this.style.boxShadow='var(--shadow-sm)'">
        <div style="
            width: 48px;
            height: 48px;
            border-radius: var(--radius-lg);
            background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
        ">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
                <circle cx="12" cy="12" r="3"/>
                <path d="M12 1v6m0 6v6m-7-7h6m6 0h6"/>
            </svg>
        </div>
        <h3 style="margin: 0 0 0.5rem 0; font-size: 1.125rem; font-weight: 600;">System Settings</h3>
        <p style="margin: 0; color: var(--gray-600); font-size: 0.875rem; line-height: 1.5;">
            Configure global system preferences and defaults.
        </p>
    </div>
</div>
