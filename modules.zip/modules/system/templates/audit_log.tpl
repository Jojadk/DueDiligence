<div class="dd-page-header">
    <div class="dd-page-title">
        <h1>Audit Log</h1>
        <p>Systemaktiviteter og fejlhistorik</p>
    </div>
     <div class="dd-page-actions">
         <button id="btn-refresh-logs" name="btn_refresh_logs" class="dd-btn dd-btn-secondary" onclick="App.system.logs.reload()">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>
            Opdater
        </button>
    </div>
</div>

<div class="dd-card">
    <div style="margin-bottom: 1.5rem; display: flex; gap: 10px;">
        <div class="input-icon-wrapper" style="flex-grow: 1;">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="input-icon"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
            <input type="text" id="logs-filter-input" class="dd-input pl-10" placeholder="Søg i logs..." onkeyup="App.system.logs.filter(this.value)">
        </div>
    </div>

    <div class="dd-card-body" style="padding:0;">
        <div id="logs-container" style="max-height: 70vh; overflow-y: auto;">
            <!-- Premium List Style -->
            <ul id="recent-activity-list" style="list-style: none; padding: 0; margin: 0;">
                <li style="text-align:center; padding: 2rem; color: var(--gray-500);">
                    <div class="spinner small"></div> Indlæser logs...
                </li>
            </ul>
        </div>
    </div>
</div>

<script>
    window.App = window.App || {};
    window.App.system = window.App.system || {};
    
    if (typeof App.system.logs === 'undefined' || !App.system.logs.filter) {
        App.system.logs = {
            allLogs: [],
            
            init: function() {
                this.reload();
            },
            
            reload: async function() {
                const container = document.getElementById('recent-activity-list');
                
                try {
                    const res = await App.core.ajax('api.php?module=system&action=get_logs');
                    
                    // Parse raw lines into objects if possible
                    this.allLogs = (res.logs || []).map(line => this.parseLogLine(line));
                    
                    const filterVal = document.getElementById('logs-filter-input')?.value || '';
                    this.filter(filterVal);
                    
                } catch (err) {
                    container.innerHTML = `<li style="padding: 20px; color: var(--red-600); text-align: center;">Kunne ikke hente logs: ${err.message}</li>`;
                }
            },
            
            parseLogLine: function(line) {
                // Default structure
                let log = {
                    raw: line,
                    time: '',
                    user: 'System',
                    ip: '',
                    level: 'INFO',
                    message: line,
                    color: '#3b82f6'
                };

                // Example Regex for standard log format: [2024-01-31 20:22:18] [INFO] [User:1] Message...
                // Or format from user request: [User: 1] [IP: 10.0.10.78] ...
                
                try {
                    // Extract Timestamp (approximate match)
                    const timeMatch = line.match(/\[(\d{4}-\d{2}-\d{2}\s)?(\d{2}:\d{2}:\d{2})\]/);
                    if (timeMatch) log.time = timeMatch[2]; // Get just time part

                    // Extract Level
                    if (line.includes('ERROR') || line.includes('Exception')) { 
                        log.level = 'ERROR'; 
                        log.color = '#ef4444'; 
                    }
                    else if (line.includes('WARNING')) { 
                        log.level = 'WARNING'; 
                        log.color = '#f59e0b'; 
                    }

                    // Extract User
                    const userMatch = line.match(/User:\s*(\w+)/i);
                    if (userMatch) log.user = userMatch[1];

                    // Extract IP
                    const ipMatch = line.match(/IP:\s*([\d\.]+)/);
                    if (ipMatch) log.ip = ipMatch[1];
                    
                    // Cleanup message (remove metadata parts if desired, or keep full)
                    // For now, let's try to strip the common prefixes to make message cleaner
                    let cleanMsg = line;
                    // Remove timestamps, user tags, ip tags
                    cleanMsg = cleanMsg.replace(/\[\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}\]/, ''); 
                    cleanMsg = cleanMsg.replace(/\[User:[^\]]+\]/, '');
                    cleanMsg = cleanMsg.replace(/\[IP:[^\]]+\]/, '');
                    cleanMsg = cleanMsg.replace(/\[(INFO|ERROR|WARNING)\]/, '');
                    
                    log.message = cleanMsg.trim();

                } catch (e) {
                    console.warn("Log parse error", e);
                }

                return log;
            },
            
            filter: function(query) {
                const container = document.getElementById('recent-activity-list');
                if (!container) return; 
                
                let logs = this.allLogs;
                
                if (query) {
                    const lowerQ = query.toLowerCase();
                    logs = logs.filter(l => l.raw.toLowerCase().includes(lowerQ));
                }
                
                if (logs.length === 0) {
                     container.innerHTML = '<li style="padding: 20px; text-align: center; color: var(--gray-500);">Ingen logs fundet.</li>';
                     return;
                }
                
                container.innerHTML = logs.map(log => `
                    <li style="border-bottom: 1px solid #f3f4f6; padding: 12px 16px; font-size: 0.9rem; transition: background 0.1s;" onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background='white'">
                        <div style="display: flex; gap: 14px; align-items: flex-start;">
                            <span style="color: #9ca3af; font-family: var(--font-mono, monospace); font-size: 0.8rem; white-space: nowrap; margin-top: 3px; width: 60px; text-align:right;">${log.time}</span>
                            <div style="flex: 1;">
                                <div style="margin-bottom: 2px;">
                                    ${log.level === 'ERROR' ? 
                                        '<span style="display:inline-block; width:8px; height:8px; background:#ef4444; border-radius:50%; margin-right:6px;"></span>' : 
                                        '<span style="display:inline-block; width:8px; height:8px; background:#e2e8f0; border-radius:50%; margin-right:6px;"></span>'
                                    }
                                    <span style="color:${log.color}; font-weight: 500;">
                                        ${log.user !== 'System' ? `<span style="color:#64748b; font-weight:normal; font-size:0.8em; border:1px solid #e2e8f0; border-radius:4px; padding:1px 4px; margin-right:6px;">${log.user}</span>` : ''}
                                        ${log.ip ? `<span style="color:#94a3b8; font-weight:normal; font-size:0.8em; margin-right:6px;" title="IP Address">${log.ip}</span>` : ''}
                                        ${this.highlight(log.message, query)}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </li>
                `).join('');
            },

            highlight: function(text, query) {
                if (!query) return text;
                const reg = new RegExp(`(${query})`, 'gi');
                return text.replace(reg, '<mark style="background:#fef08a; color:#854d0e; padding:0 2px; border-radius:2px;">$1</mark>');
            }
        };
    }
    
    // Auto-init with slight delay to ensure DOM is ready
    setTimeout(() => App.system.logs.init(), 50);
</script>
