<div class="dd-card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
        <div>
            <h2 style="margin: 0;">Menu Manager</h2>
            <p style="margin: 0.25rem 0 0 0; color: var(--gray-500); font-size: 0.875rem;">Configure application sidebar menu</p>
        </div>
        <button id="btn-add-menu-item" name="btn_add_menu_item" class="dd-btn dd-btn-primary" onclick="App.menuManager.showAddModal()">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
            New Menu Item
        </button>
    </div>

    <style>
        .dd-menu-tree { list-style: none; padding-left: 0; margin: 0; }
        .dd-menu-tree .dd-menu-tree { padding-left: 2rem; border-left: 1px dashed var(--gray-300); }
        .dd-menu-item { margin-bottom: 0.5rem; background: white; border: 1px solid var(--border); border-radius: 4px; }
        .dd-menu-content { display: flex; align-items: center; padding: 0.5rem 1rem; gap: 1rem; }
        .dd-drag-handle { cursor: grab; color: var(--gray-400); font-weight: bold; }
        .dd-menu-item.dragging { opacity: 0.5; border: 1px dashed var(--primary-500); }
        .dd-menu-placeholder { height: 40px; background: var(--primary-100); border: 1px dashed var(--primary-500); margin-bottom: 0.5rem; border-radius: 4px; }
        .dd-menu-actions { margin-left: auto; display: flex; gap: 0.5rem; }
        .dd-menu-actions button { background: none; border: none; cursor: pointer; color: var(--gray-500); padding: 4px; }
        .dd-menu-actions button:hover { color: var(--primary-500); }
    </style>

    <div id="menu-tree-container" style="padding: 1rem;">
        <div style="text-align: center; padding: 2rem; color: var(--gray-500);">Loading menu structure...</div>
    </div>
</div>

<script>
    window.App = window.App || {};
    
    if (typeof App.menuManager === 'undefined') {
        // Defines stub immediately to prevent race conditions or undefined errors
        App.menuManager = {
            init: function() { console.log('MenuManager loading...'); },
            showAddModal: function() { App.core.toast('info', 'Module loading...'); }
        };
        
        const script = document.createElement('script');
        script.src = 'public/js/menu_manager.js?v=' + Date.now();
        script.onload = () => {
             if (App.menuManager.init) App.menuManager.init(); 
        };
        document.body.appendChild(script);
    } else {
        App.menuManager.init();
    }
</script>
