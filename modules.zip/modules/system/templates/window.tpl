<div class="wm-header">
    <div class="wm-controls">
        <button class="wm-btn wm-close" title="Close"></button>
        <button class="wm-btn wm-min" title="Minimize"></button>
        <button class="wm-btn wm-max" title="Maximize"></button>
    </div>
    <span class="wm-title">{{title|raw}}</span>
</div>
<div class="wm-body">
    <div class="wm-loader">
        <div class="spinner"></div>
        <span>Indlæser...</span>
    </div>
    <div class="wm-content"></div>
</div>
