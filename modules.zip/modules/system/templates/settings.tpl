<div class="dd-page-header">
    <div class="header-left">
        <button class="dd-btn dd-btn-secondary" onclick="window.history.back()">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>
            Tilbage
        </button>
        <div>
            <h1>System Settings</h1>
            <p>Konfigurer system-brede indstillinger, indeksering og API integrationer</p>
        </div>
    </div>
</div>

<div class="dd-container" style="max-width: 1200px; margin: 0 auto; padding: 2rem 0;">
    <div style="display: flex; gap: 2rem; align-items: flex-start;">
        
        <!-- Sidebar Tabs -->
        <div style="width: 280px; flex-shrink: 0; position: sticky; top: 2rem;">
            <div class="dd-card" style="padding: 10px;">
                <nav class="settings-nav">
                    <button class="nav-item active" onclick="SystemSettings.switchTab('general', this)">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                        Generelt
                    </button>
                    <button class="nav-item" onclick="SystemSettings.switchTab('economy', this)">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
                        Økonomi & Indeks
                    </button>
                    <button class="nav-item" onclick="SystemSettings.switchTab('ai_api', this)">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>
                        AI & API Integration
                    </button>
                    <button class="nav-item" onclick="SystemSettings.switchTab('security', this)">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                        Sikkerhed
                    </button>
                </nav>
            </div>
        </div>

        <!-- Content Area -->
        <div style="flex-grow: 1;">
            
            <!-- General Tab -->
            <div id="tab-general" class="settings-tab active">
                <div class="dd-card">
                    <div class="tab-header">
                        <h3>Generelle Indstillinger</h3>
                        <p>Grundlæggende informationer om systemet</p>
                    </div>
                    <div class="tab-body">
                        <div class="wm-form-group">
                            <label>System Navn</label>
                            <input type="text" class="dd-input" data-key="app_name" placeholder="DueDiligence System">
                        </div>
                        <div class="wm-form-group">
                            <label>Logo URL</label>
                            <input type="text" class="dd-input" data-key="app_logo_url" placeholder="https://example.com/logo.png">
                            <div class="form-hint">URL til firmaets logo. Anvendes i rapporter og mails.</div>
                        </div>
                        <div class="wm-form-group">
                            <label>Standard Budgethorisont (År)</label>
                            <input type="number" class="dd-input" data-key="default_budget_horizon" placeholder="10">
                            <div class="form-hint">Standard antal år for CAPEX beregninger.</div>
                        </div>
                    </div>
                    <div class="tab-footer">
                        <button class="dd-btn dd-btn-primary" onclick="SystemSettings.saveTab('general')">Gem Generelt</button>
                    </div>
                </div>
            </div>

            <!-- Economy Tab -->
            <div id="tab-economy" class="settings-tab">
                <div class="dd-card">
                    <div class="tab-header">
                        <h3>Økonomi & Indeksering</h3>
                        <p>Prisindeksering og valutaformater</p>
                    </div>
                    <div class="tab-body">
                        <div style="background: #f0f9ff; padding: 1rem; border-radius: 8px; border: 1px solid #bae6fd; margin-bottom: 2rem;">
                            <div style="display: flex; gap: 15px; align-items: center;">
                                <div style="font-size: 1.5rem;">📈</div>
                                <div>
                                    <h4 style="margin: 0; color: #0369a1;">Pris Indeksering</h4>
                                    <p style="margin: 2px 0 0 0; font-size: 0.9rem; color: #0c4a6e;">Alle katalogpriser i systemet tager udgangspunkt i <strong>2024 = Indeks 100</strong>.</p>
                                </div>
                            </div>
                        </div>

                        <div class="dd-grid-2">
                            <div class="wm-form-group">
                                <label>Nuværende Prisindeks</label>
                                <input type="number" class="dd-input" data-key="price_index" step="0.1" placeholder="100.0" onchange="SystemSettings.calculatePreview(this.value)">
                                <div class="form-hint">F.eks. 112.5 for 12.5% fremskrivning.</div>
                            </div>
                            <div class="wm-form-group">
                                <label>Valuta Symbol</label>
                                <input type="text" class="dd-input" data-key="currency_symbol" placeholder="kr.">
                            </div>
                        </div>

                        <div style="margin-top: 1.5rem; padding: 1.5rem; background: #f8fafc; border-radius: 8px; border: 1px dashed #cbd5e1;">
                            <h4 style="margin: 0 0 12px 0; font-size: 0.95rem; color: var(--gray-600);">Eksempel på indekseret pris:</h4>
                            <div style="display: flex; align-items: center; justify-content: space-between; font-family: monospace; font-size: 1.1rem;">
                                <div>
                                    <span style="color: var(--gray-500); font-size: 0.8rem; display:block;">Basis (2024)</span>
                                    <strong>1.000,00 kr.</strong>
                                </div>
                                <div style="color: var(--gray-300);">➔</div>
                                <div>
                                    <span style="color: var(--gray-500); font-size: 0.8rem; display:block;">Nutidsværdi</span>
                                    <strong id="preview-price-econ" style="color: var(--primary-600);">1.000,00 kr.</strong>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-footer">
                        <button class="dd-btn dd-btn-primary" onclick="SystemSettings.saveTab('economy')">Gem Økonomi</button>
                    </div>
                </div>
            </div>

            <!-- AI & API Tab -->
            <div id="tab-ai_api" class="settings-tab">
                <div class="dd-card">
                    <div class="tab-header">
                        <h3>AI & API Integration</h3>
                        <p>Google Gemini og eksterne services</p>
                    </div>
                    <div class="tab-body">
                        <div class="wm-form-group">
                            <label>Google Gemini API Nøgle</label>
                            <input type="password" class="dd-input" data-key="gemini_api_key" placeholder="AIzaSy...">
                            <div class="form-hint">Nødvendigt for intelligent data-matching og rapport-generering.</div>
                        </div>
                        <div class="wm-form-group">
                            <label>Gemini Model</label>
                            <select class="dd-input" data-key="gemini_model_name">
                                <option value="gemini-1.5-pro">Gemini 1.5 Pro (Bedste præcision)</option>
                                <option value="gemini-1.5-flash">Gemini 1.5 Flash (Foretrukket - hurtig & billig)</option>
                                <option value="gemini-2.0-flash-exp">Gemini 2.0 Flash (Eksperimentel)</option>
                            </select>
                        </div>
                    </div>
                    <div class="tab-footer">
                        <button class="dd-btn dd-btn-primary" onclick="SystemSettings.saveTab('ai_api')">Gem API Indstillinger</button>
                    </div>
                </div>
            </div>

            <!-- Security Tab -->
            <div id="tab-security" class="settings-tab">
                <div class="dd-card">
                    <div class="tab-header">
                        <h3>Sikkerhed</h3>
                        <p>Brugeradgang og session styring</p>
                    </div>
                    <div class="tab-body">
                        <div class="wm-form-group">
                            <label>Session Timeout (Minutter)</label>
                            <input type="number" class="dd-input" data-key="session_timeout_minutes" placeholder="60">
                            <div class="form-hint">Hvor længe en bruger kan være inaktiv før logud.</div>
                        </div>
                        <div class="wm-form-group">
                            <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                                <input type="checkbox" data-key="enforce_2fa" value="1">
                                <span>Tving 2-faktor autentificering for alle administratorer</span>
                            </label>
                        </div>
                    </div>
                    <div class="tab-footer">
                        <button class="dd-btn dd-btn-primary" onclick="SystemSettings.saveTab('security')">Gem Sikkerhed</button>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<style>
.settings-nav {
    display: flex;
    flex-direction: column;
    gap: 4px;
}
.nav-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    background: transparent;
    border: none;
    border-radius: 8px;
    color: var(--gray-600);
    text-align: left;
    cursor: pointer;
    font-weight: 500;
    transition: all 0.2s;
}
.nav-item:hover {
    background: var(--gray-50);
    color: var(--primary-600);
}
.nav-item.active {
    background: var(--primary-50);
    color: var(--primary-700);
}
.settings-tab {
    display: none;
}
.settings-tab.active {
    display: block;
}
.tab-header {
    padding: 1.5rem;
    border-bottom: 1px solid var(--gray-100);
}
.tab-header h3 {
    margin: 0;
    font-size: 1.25rem;
}
.tab-header p {
    margin: 4px 0 0 0;
    color: var(--gray-500);
    font-size: 0.9rem;
}
.tab-body {
    padding: 2rem;
}
.tab-footer {
    padding: 1.25rem 2rem;
    background: var(--gray-50);
    border-top: 1px solid var(--gray-100);
    text-align: right;
    border-bottom-left-radius: 12px;
    border-bottom-right-radius: 12px;
}
.pl-10 { padding-left: 40px !important; }
</style>

<script>
(function() {
    const SystemSettings = {
        constants: [],
        
        init: function() {
            this.load();
        },

        switchTab: function(tabId, btn) {
            // Update buttons
            document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            // Update tabs
            document.querySelectorAll('.settings-tab').forEach(t => t.classList.remove('active'));
            document.getElementById('tab-' + tabId).classList.add('active');
        },

        load: async function() {
            try {
                this.constants = await App.core.ajax('api.php?module=system&action=get_constants') || [];
                
                // Populate all inputs with data-key
                document.querySelectorAll('[data-key]').forEach(el => {
                    const key = el.getAttribute('data-key');
                    const constant = this.constants.find(c => c.key_name === key);
                    
                    if (constant) {
                        if (el.type === 'checkbox') {
                            el.checked = constant.value == 1;
                        } else {
                            el.value = constant.value;
                        }
                    }
                });
                
                // Initial preview
                const indexConst = this.constants.find(c => c.key_name === 'price_index');
                this.calculatePreview(indexConst ? indexConst.value : 100);
                
            } catch (e) {
                console.error("Settings load error", e);
                App.core.toast('error', 'Kunne ikke hente systemindstillinger');
            }
        },

        calculatePreview: function(val) {
            const index = parseFloat(val) || 100;
            const res = 1000 * (index / 100);
            const el = document.getElementById('preview-price-econ');
            if (el) el.innerText = App.core.formatNumber(res) + ' kr.';
        },

        saveTab: async function(tabId) {
            const tabEl = document.getElementById('tab-' + tabId);
            const inputs = tabEl.querySelectorAll('[data-key]');
            
            const btn = tabEl.querySelector('.dd-btn-primary');
            const originalText = btn.innerText;
            btn.innerHTML = '<div class="spinner small white" style="display:inline-block; margin-right:8px;"></div> Gemmer...';
            btn.disabled = true;

            try {
                // We save each constant in the tab
                for (const input of inputs) {
                    const key = input.getAttribute('data-key');
                    const value = input.type === 'checkbox' ? (input.checked ? '1' : '0') : input.value;
                    const existing = this.constants.find(c => c.key_name === key);
                    
                    await App.core.ajax('api.php?module=system&action=save_constant', {
                        method: 'POST',
                        body: {
                            id: existing ? existing.id : 0,
                            key_name: key,
                            value: value,
                            description: 'System Setting: ' + key
                        }
                    });
                }
                
                App.core.toast('success', 'Indstillinger for ' + tabId + ' er gemt');
                this.load(); // Refresh state
                
            } catch (e) {
                App.core.toast('error', 'Fejl ved gem: ' + e.message);
            } finally {
                btn.innerText = originalText;
                btn.disabled = false;
            }
        }
    };

    window.SystemSettings = SystemSettings;
    SystemSettings.init();
})();
</script>
