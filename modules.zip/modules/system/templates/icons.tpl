<div class="dd-card" style="padding: 2rem;">
    <h2>Icon Catalog</h2>
    <p class="text-muted">Over 100 SVG pictograms available for the system. Use <code>App.icons.get('name')</code> to retrieve them.</p>
    
    <input type="text" class="dd-input" placeholder="Search icons..." style="margin-top: 1rem; max-width: 300px;" id="icon-search">

    <div id="icon-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 1rem; margin-top: 1rem;">
        <!-- Icons will be injected here -->
    </div>
</div>

<script>
    (function() {
        const grid = document.getElementById('icon-grid');
        const search = document.getElementById('icon-search');
        const allIcons = App.icons.list_all();
        
        function render(icons) {
            grid.innerHTML = icons.map(name => `
                <div class="dd-card-sm" style="text-align: center; padding: 1rem; border: 1px solid var(--border); border-radius: 8px;">
                    <div style="color: var(--primary); margin-bottom: 0.5rem;">${App.icons.get(name)}</div>
                    <div style="font-size: 0.7rem; color: #666; word-break: break-all;">${name}</div>
                </div>
            `).join('');
        }
        
        render(allIcons);
        
        search.addEventListener('keyup', (e) => {
            const val = e.target.value.toLowerCase();
            const filtered = allIcons.filter(i => i.toLowerCase().includes(val));
            render(filtered);
        });
    })();
</script>
