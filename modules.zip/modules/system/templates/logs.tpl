<div class="dd-page-header">
    <div class="dd-page-title">
        <h1>System Logs</h1>
        <p>Viewing the last 100 entries from system.log</p>
    </div>
    <div class="dd-page-actions">
         <button class="dd-btn" onclick="App.system.logs.reload()">
            <i class="fas fa-sync"></i> Refresh
        </button>
    </div>
</div>

<div class="dd-card">
    <div style="margin-bottom: 1rem; display: flex; gap: 10px;">
        <input type="text" class="dd-input" placeholder="Filter logs..." style="flex-grow: 1;" onkeyup="App.system.logs.filter(this.value)">
    </div>
    
    <div class="dd-card-body" style="padding:0;">
        <div id="logs-container" style="background:#1e293b; color:#cbd5e1; padding:1rem; font-family:monospace; height:70vh; overflow-y:auto; border-radius:8px; font-size:0.85rem; line-height:1.6;">
            Loading logs...
        </div>
    </div>
</div>

<script>
    App.system = App.system || {};
    App.system.logs = {
        allLogs: [],
        
        init: function() {
            this.reload();
        },
        
        reload: async function() {
            const container = document.getElementById('logs-container');
            container.innerHTML = '<span style="color:#94a3b8">Loading...</span>';
            
            try {
                const res = await App.core.ajax('api.php?module=system&action=get_logs');
                this.allLogs = res.logs || [];
                
                // Check if filter input has value
                const filterVal = document.querySelector('input[placeholder="Filter logs..."]')?.value || '';
                this.filter(filterVal);
                
            } catch (err) {
                container.innerHTML = `<span style="color:#ef4444">Failed to load logs: ${err.message}</span>`;
            }
        },
        
        filter: function(query) {
            const container = document.getElementById('logs-container');
            let logs = this.allLogs;
            
            if (query) {
                const lowerQ = query.toLowerCase();
                logs = logs.filter(l => l.toLowerCase().includes(lowerQ));
            }
            
            if (logs.length === 0) {
                 container.innerHTML = '<span style="color:#94a3b8">No logs found.</span>';
                 return;
            }
            
            container.innerHTML = logs.map(line => {
                let color = '#cbd5e1';
                if (line.includes('[ERROR]')) color = '#ef4444';
                if (line.includes('[WARNING]')) color = '#f59e0b';
                if (line.includes('[INFO]')) color = '#3b82f6';
                if (line.includes('[DEBUG]')) color = '#9ca3af';
                
                return `<div style="color:${color}; border-bottom:1px solid #334155; padding:2px 0;">${this.escapeHtml(line)}</div>`;
            }).join('');
        },
        
        escapeHtml: function(text) {
             const map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.replace(/[&<>"']/g, function(m) { return map[m]; });
        }
    };
    
    // Auto-init
    App.system.logs.init();
</script>
