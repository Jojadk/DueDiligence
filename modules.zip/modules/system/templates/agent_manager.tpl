<div class="dd-page-header">
    <div style="display: flex; justify-content: space-between; align-items: center; width: 100%;">
        <div>
            <h1>AI Agenter</h1>
            <p>Konfigurer systemets AI-vurderingsagenter</p>
        </div>
        <button class="dd-btn-primary" onclick="App.system.openAgentModal()">
            <span class="material-icons">add</span>
            Ny Agent
        </button>
    </div>
</div>

<div id="agent-manager-container" class="dd-content-card" style="margin-top: 1.5rem;">
    <div id="agents-list-container" style="display: grid; gap: 1rem; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));">
        <div class="dd-loading">Henter agenter...</div>
    </div>
</div>

<style>
    .agent-card {
        padding: 1.5rem;
        border: 1px solid var(--gray-200);
        border-radius: var(--radius-md);
        background: white;
        transition: all 0.2s;
        display: flex;
        flex-direction: column;
    }
    .agent-card:hover {
        border-color: var(--primary-500);
        box-shadow: var(--shadow-md);
    }
    .agent-card-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 0.5rem;
    }
    .agent-card-title {
        font-weight: 600;
        font-size: 1.125rem;
        color: var(--gray-900);
    }
    .agent-card-model {
        font-size: 0.75rem;
        color: var(--gray-400);
        margin-bottom: 1rem;
    }
    .agent-card-desc {
        color: var(--gray-500);
        font-size: 0.875rem;
        line-height: 1.4;
        margin-bottom: 1.5rem;
        flex-grow: 1;
    }
    .agent-card-actions {
        display: flex;
        gap: 0.5rem;
        border-top: 1px solid var(--gray-100);
        padding-top: 1rem;
    }
</style>

<script>
    App.system = App.system || {};

    App.system.initAgentManager = async function() {
        try {
            const res = await App.core.ajax('api.php?module=ai&action=list_agents');
            this.renderAgents(res.data || []);
        } catch (e) {
            console.error(e);
            App.core.toast('error', 'Kunne ikke hente agenter');
        }
    };

    App.system.renderAgents = function(agents) {
        const container = document.getElementById('agents-list-container');
        if (!container) return;

        if (agents.length === 0) {
            container.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 3rem; color: var(--gray-400);">Ingen agenter fundet. Opret en ny for at komme i gang.</div>';
            return;
        }

        container.innerHTML = agents.map(a => `
            <div class="agent-card">
                <div class="agent-card-header">
                    <div class="agent-card-title">${a.name}</div>
                    <div class="dd-badge dd-badge-info">${a.model.split('/').pop()}</div>
                </div>
                <div class="agent-card-model">Google Gemini</div>
                <div class="agent-card-desc">${a.description || 'Ingen beskrivelse'}</div>
                <div class="agent-card-actions">
                    <button class="dd-btn-secondary dd-btn-sm" onclick="App.system.openAgentModal(${a.id})">
                        <span class="material-icons" style="font-size: 16px; margin-right: 4px;">edit</span>
                        Rediger
                    </button>
                    <button class="dd-btn-secondary dd-btn-sm" style="color: var(--red-600);" onclick="App.system.deleteAgent(${a.id})">
                        <span class="material-icons" style="font-size: 16px;">delete</span>
                    </button>
                </div>
            </div>
        `).join('');
    };

    App.system.openAgentModal = async function(id = null) {
        let agent = { name: '', description: '', system_prompt: '', model: 'models/gemini-1.5-pro', api_key: '' };
        let models = [];

        try {
            // Fetch both agent data (if id) and models list
            const [modelRes, agentRes] = await Promise.all([
                App.core.ajax('api.php?module=ai&action=list_models'),
                id ? App.core.ajax('api.php?module=ai&action=get_agent&id=' + id) : Promise.resolve({ data: agent })
            ]);
            
            models = modelRes.data || [];
            agent = agentRes.data;
        } catch (e) {
            App.core.toast('error', 'Kunne ikke hente nødvendige data');
            return;
        }

        const body = `
            <div class="dd-form-row">
                <label class="dd-label">Navn</label>
                <input type="text" id="agent-name" class="dd-input" value="${agent.name}" placeholder="F.eks. Teknisk Audit Expert">
            </div>
            <div class="dd-form-row">
                <label class="dd-label">Beskrivelse</label>
                <input type="text" id="agent-desc" class="dd-input" value="${agent.description}" placeholder="Kort beskrivelse af agentens rolle">
            </div>
            <div class="dd-form-row">
                <label class="dd-label">Model</label>
                <select id="agent-model" class="dd-input">
                    ${models.map(m => `
                        <option value="${m.name}" ${agent.model === m.name ? 'selected' : ''}>${m.displayName}</option>
                    `).join('')}
                </select>
            </div>
            <div class="dd-form-row">
                <label class="dd-label">API Token (Valgfri)</label>
                <input type="password" id="agent-api-key" class="dd-input" value="${agent.api_key || ''}" placeholder="Efterlad tom for at bruge systemets standard">
            </div>
            <div class="dd-form-row">
                <label class="dd-label">System Prompt</label>
                <textarea id="agent-prompt" class="dd-input" rows="12" style="font-family: monospace; font-size: 12px;">${agent.system_prompt}</textarea>
                <p style="font-size: 11px; color: var(--gray-400); mt-1">Definer agentens personlighed, viden og output format.</p>
            </div>
        `;

        const buttons = [
            { label: 'Annuller', class: 'dd-btn-secondary', onclick: 'App.modal.close()' },
            { label: id ? 'Gem Ændringer' : 'Opret Agent', class: 'dd-btn-primary', onclick: `App.system.handleSaveAgent(${id})` }
        ];

        App.modal.show(App.utils.renderModal(body, buttons), id ? 'Rediger Agent' : 'Ny AI Agent', 'medium');
    };

    App.system.handleSaveAgent = async function(id) {
        const data = {
            id,
            name: document.getElementById('agent-name').value,
            description: document.getElementById('agent-desc').value,
            model: document.getElementById('agent-model').value,
            api_key: document.getElementById('agent-api-key').value,
            system_prompt: document.getElementById('agent-prompt').value
        };

        if (!data.name || !data.system_prompt) {
            App.core.toast('warning', 'Navn og Prompt er påkrævet');
            return;
        }

        try {
            await App.core.ajax('api.php?module=ai&action=save_agent', {
                method: 'POST',
                body: data
            });
            App.modal.close();
            App.core.toast('success', 'Agent gemt');
            App.system.initAgentManager();
        } catch (e) {
            App.core.toast('error', e.message);
        }
    };

    App.system.deleteAgent = function(id) {
        App.modal.confirm('Er du sikker på, at du vil slette denne agent?', async () => {
            try {
                await App.core.ajax('api.php?module=ai&action=delete_agent&id=' + id);
                App.system.initAgentManager();
                App.core.toast('success', 'Agent slettet');
            } catch (e) {
                App.core.toast('error', e.message);
            }
        }, 'Slet Agent');
    };

    // Auto-init
    App.system.initAgentManager();
</script>
