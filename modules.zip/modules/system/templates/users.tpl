<div class="dd-card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
        <div>
            <h2 style="margin: 0;">User Management</h2>
            <p style="margin: 0.25rem 0 0 0; color: var(--gray-500); font-size: 0.875rem;"><span id="user-count">0</span> registered users</p>
        </div>
        <button id="btn-add-user" name="btn_add_user" class="dd-btn dd-btn-primary" onclick="App.users.showAddModal()">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
            Add User
        </button>
    </div>

    <input type="text" id="users-search" name="users_search" class="dd-input" placeholder="Search users by name, email or group..." style="margin-bottom: 1rem; max-width: 400px;" onkeyup="App.users.filter(this.value)">
    
    <div id="user-table-wrapper" class="dd-table-wrapper">
        <table id="users-table" name="users_table" class="dd-table">
            <thead>
                <tr>
                    <th onclick="App.users.sort('name')" style="cursor: pointer;" data-sort="name">Name <span class="sort-icon">⇅</span></th>
                    <th onclick="App.users.sort('email')" style="cursor: pointer;" data-sort="email">Email <span class="sort-icon">⇅</span></th>
                    <th onclick="App.users.sort('group_name')" style="cursor: pointer;" data-sort="group_name">Group <span class="sort-icon">⇅</span></th>
                    <th onclick="App.users.sort('active')" style="cursor: pointer;" data-sort="active">Status <span class="sort-icon">⇅</span></th>
                    <th style="text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody id="user-table-body">
                <tr><td colspan="5" style="text-align: center; padding: 2rem; color: var(--gray-500);">Loading users...</td></tr>
            </tbody>
        </table>
    </div>
</div>

<script>
    window.App = window.App || {};
    window.App.users = window.App.users || { 
        init: function() { this._pendingInit = true; },
        showAddModal: function() { console.warn('Module loading...'); },
        loadList: function() {} 
    };

    if (typeof App.users.loadList === 'undefined' || App.users._pendingInit) {
        // admin-users.js is now loaded globally in main.tpl, 
        // but we keep this check for safety or direct module loading.
        if (typeof App.users.init === 'function' && !App.users._pendingInit) {
             App.users.init();
        } else {
             // Fallback if global load failed or pending
             const script = document.createElement('script');
             script.src = 'public/js/admin-users.js?v=' + Date.now();
             script.onload = () => {
                 if(App.users.init) App.users.init();
             };
             document.head.appendChild(script);
        }
    } else {
        App.users.init();
    }
</script>
