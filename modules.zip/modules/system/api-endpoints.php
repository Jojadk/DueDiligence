<?php
// modules/system/api-endpoints.php

function handle_api($action, $db)
{
    // Permission Checks
    switch ($action) {
        case 'get_menu':
        case 'get_extra_fields':
        case 'get_comments':
        case 'get_2fa_status':
        case 'search_users':
        case 'get_users':
        case 'list_users_simple':
        case 'get_user':
        case 'temp_install_templates': // TEMP FIX
            require_permission('allow_view_all');
            break;

        case 'update_permissions':
        case 'add_menu_item':
        case 'update_menu_item':
        case 'delete_menu_item':
        case 'create_user_group':
        case 'get_logs':
        case 'get_user_groups':
        case 'create_user':
        case 'update_user':
        case 'delete_user':
            require_permission('allow_manage_configuration');
            break;
    }

    switch ($action) {
        case 'log_error':
            return log_error($db);
        case 'get_menu':
            return get_menu($db);
        case 'get_extra_fields':
            return get_extra_fields($db);
        case 'save_extra_values':
            return handle_save_extra_values($db);
        case 'get_comments':
            return handle_get_comments($db);
        case 'add_comment':
            return add_comment($db);
        case 'update_permissions':
            return update_permissions($db);
        case 'add_menu_item':
            return add_menu_item($db);
        case 'update_menu_item':
            return update_menu_item($db);
        case 'delete_menu_item':
            return delete_menu_item($db);
        case 'create_user_group':
            return create_user_group($db);
        case 'get_logs':
            return get_logs($db);
        case 'get_user_groups':
            return get_user_groups($db);
        // 2FA Management
        case 'enable_2fa':
            return enable_2fa($db);
        case 'verify_2fa_setup':
            return verify_2fa_setup($db);
        case 'disable_2fa':
            return disable_2fa($db);
        case 'get_2fa_status':
            return get_2fa_status($db);
        case 'search_users':
            return search_users($db);
        case 'get_users':
            return get_users($db);
        case 'list_users_simple':
            return list_users_simple($db);
        case 'get_user':
            return get_user($db);
        case 'create_user':
            return create_user($db);
        case 'update_user':
            return update_user($db);
        case 'delete_user':
            return delete_user($db);
        case 'delete_user_group':
            return delete_user_group($db);
        case 'get_constants':
            return get_constants($db);
        case 'save_constant':
            return save_constant($db);
        case 'update_menu_auto':
            return update_menu_auto($db);
        case 'setup_meta_table':
            return setup_meta_table($db);
        case 'update_menu_structure':
            return update_menu_structure($db);
        default:
            throw new Exception("Unknown system action: " . $action);
    }
}


function update_menu_structure($db)
{
    require_permission('allow_manage_configuration');
    $data = json_decode(file_get_contents('php://input'), true);
    if (!is_array($data)) {
        throw new Exception("Invalid structure data");
    }

    $stmt = $db->prepare("UPDATE dd_system_Menu SET parent_id = ?, sort_order = ? WHERE id = ?");

    $db->beginTransaction();
    try {
        foreach ($data as $item) {
            $stmt->execute([
                (int) $item['parent_id'],
                (int) $item['sort_order'],
                (int) $item['id']
            ]);
        }
        $db->commit();
        return ['message' => 'Menu structure updated'];
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

function setup_meta_table($db)
{
    $sql = "CREATE TABLE IF NOT EXISTS dd_project_meta (
        id INT AUTO_INCREMENT PRIMARY KEY,
        project_id INT NOT NULL,
        meta_key VARCHAR(50) NOT NULL,
        meta_value TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY unique_project_key (project_id, meta_key),
        FOREIGN KEY (project_id) REFERENCES dd_projects(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

    $db->exec($sql);
    return ['status' => 'meta_table_ready'];
}

function update_menu_auto($db)
{
    // 1. Add 'Tasks'
    $stmt = $db->prepare("SELECT id FROM dd_system_Menu WHERE module = 'tasks'");
    $stmt->execute();
    if (!$stmt->fetch()) {
        $stmt = $db->prepare("INSERT INTO dd_system_Menu (name, module, template, parent_id, sort_order, icon, active) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute(['Tasks', 'tasks', 'list', 0, 3, 'check', 1]);
    }

    // 2. Add 'Elements'
    $stmt = $db->prepare("SELECT id FROM dd_system_Menu WHERE module = 'elements'");
    $stmt->execute();
    if (!$stmt->fetch()) {
        $stmt = $db->prepare("INSERT INTO dd_system_Menu (name, module, template, parent_id, sort_order, icon, active) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute(['Elements', 'elements', 'main', 0, 4, 'components', 1]);
    }

    // 3. Add 'AI Agenter'
    $stmt = $db->prepare("SELECT id FROM dd_system_Menu WHERE module = 'system' AND template = 'agent_manager'");
    $stmt->execute();
    if (!$stmt->fetch()) {
        $stmt = $db->prepare("INSERT INTO dd_system_Menu (name, module, template, parent_id, sort_order, icon, active) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute(['AI Agenter', 'system', 'agent_manager', 0, 9, 'psychology', 1]);
    }

    return ['status' => 'menu_updated'];
}

function search_users($db)
{
    $q = $_GET['q'] ?? ($_GET['search'] ?? '');
    if (strlen($q) < 1)
        return [];

    $term = "%$q%";
    $stmt = $db->prepare("SELECT id, name, email FROM dd_users WHERE name LIKE ? OR email LIKE ? LIMIT 20");
    $stmt->execute([$term, $term]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Normalize result structure if needed, but array is fine for lightweight search
    return $results;
}

function log_error($db)
{
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if ($data) {
        Logger::error($data['message'] ?? 'Unknown JS Error', $data);
        return ['status' => 'logged'];
    }
    return ['status' => 'no_data'];
}

function get_menu($db)
{
    $stmt = $db->query("SELECT * FROM dd_system_Menu ORDER BY parent_id ASC, sort_order ASC");
    return $stmt->fetchAll();
}

function add_menu_item($db)
{
    require_permission('allow_manage_configuration');

    $data = json_decode(file_get_contents('php://input'), true);
    $name = $data['name'] ?? '';
    $module = $data['module'] ?? '';
    $template = $data['template'] ?? 'main';
    $parent_id = $data['parent_id'] ?? 0;

    if (!$name || !$module)
        throw new Exception("Name and Module are required");

    $stmt = $db->prepare("INSERT INTO dd_system_Menu (name, module, template, parent_id, sort_order) VALUES (?, ?, ?, ?, 99)");
    $stmt->execute([$name, $module, $template, $parent_id]);

    $id = $db->lastInsertId();
    Logger::log("Menu item added: $name ($module)", 'INFO', ['user_id' => $_SESSION['user_id'] ?? 0, 'menu_id' => $id]);
    return ['message' => 'Menu item added', 'id' => $id];
}

function update_menu_item($db)
{
    require_permission('allow_manage_configuration');

    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['id'] ?? 0;
    $name = $data['name'] ?? '';
    $module = $data['module'] ?? '';
    $template = $data['template'] ?? '';
    $parentId = isset($data['parent_id']) ? (int) $data['parent_id'] : null;

    if (!$id || !$name || !$module)
        throw new Exception("ID, Name and Module are required");

    // If parent_id is not null (i.e. strictly passed), update it
    if ($parentId !== null) {
        $stmt = $db->prepare("UPDATE dd_system_Menu SET name = ?, module = ?, template = ?, parent_id = ? WHERE id = ?");
        $stmt->execute([$name, $module, $template, $parentId, $id]);
    } else {
        $stmt = $db->prepare("UPDATE dd_system_Menu SET name = ?, module = ?, template = ? WHERE id = ?");
        $stmt->execute([$name, $module, $template, $id]);
    }

    Logger::log("Menu item updated: $name", 'INFO', ['user_id' => $_SESSION['user_id'] ?? 0, 'menu_id' => $id]);
    return ['message' => 'Menu item updated'];
}

function delete_menu_item($db)
{
    require_permission('allow_manage_configuration');

    $id = (int) ($_GET['id'] ?? 0);
    if (!$id)
        throw new Exception("ID required");

    $stmt = $db->prepare("DELETE FROM dd_system_Menu WHERE id = ?");
    $stmt->execute([$id]);

    Logger::log("Menu item deleted: ID $id", 'INFO', ['user_id' => $_SESSION['user_id'] ?? 0, 'menu_id' => $id]);
    return ['message' => 'Menu item deleted'];
}

function create_user_group($db)
{
    require_permission('allow_manage_users');

    $data = json_decode(file_get_contents('php://input'), true);
    $name = $data['name'] ?? '';

    if (!$name)
        throw new Exception("Group name is required");

    $stmt = $db->prepare("INSERT INTO dd_user_Groups (name, allow_view_all) VALUES (?, 0)");
    $stmt->execute([$name]);

    $id = $db->lastInsertId();
    Logger::log("User group created: $name", 'INFO', ['user_id' => $_SESSION['user_id'] ?? 0, 'group_id' => $id]);
    return ['message' => 'Group created', 'id' => $id];
}

function get_logs($db)
{
    // Permission check removed to allow all authenticated users to view logs.

    $logFile = __DIR__ . '/../../logs/system.log';
    if (!file_exists($logFile)) {
        return ['logs' => []];
    }

    $lines = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!$lines)
        return ['logs' => []];

    $lastLines = array_slice($lines, -100);
    return ['logs' => array_reverse($lastLines)];
}

function get_extra_fields($db)
{
    $type = $_GET['type'] ?? '';
    $id = (int) ($_GET['id'] ?? 0);
    $groupId = $_SESSION['user_group_id'] ?? null;

    if (!$type)
        throw new Exception("Bind type required");

    $definitions = get_extra_field_definitions($type, $groupId);
    $values = get_extra_field_values($type, $id);

    return [
        'definitions' => $definitions,
        'values' => $values
    ];
}

function handle_save_extra_values($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $bindId = $data['bind_id'] ?? 0;
    $values = $data['values'] ?? [];

    if (!$bindId)
        throw new Exception("Bind ID required");

    save_extra_field_values($bindId, $values);
    return ['message' => 'Fields saved'];
}

function handle_get_comments($db)
{
    $type = $_GET['type'] ?? '';
    $id = (int) ($_GET['id'] ?? 0);
    if (!$type || !$id)
        throw new Exception("Type and ID required");
    return get_comments($type, $id);
}

function add_comment($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $type = $data['bind_type'] ?? '';
    $id = (int) ($data['bind_id'] ?? 0);
    $content = $data['content'] ?? '';
    $userId = $_SESSION['user_id'] ?? null;

    if (!$type || !$id || !$content)
        throw new Exception("Invalid comment data");

    $stmt = $db->prepare("INSERT INTO dd_system_Comments (bind_type, bind_id, user_id, content) VALUES (?, ?, ?, ?)");
    $stmt->execute([$type, $id, $userId, $content]);

    return ['message' => 'Comment added', 'id' => $db->lastInsertId()];
}

function update_permissions($db)
{
    require_permission('allow_manage_users');

    $data = json_decode(file_get_contents('php://input'), true);
    $groupId = (int) ($data['group_id'] ?? 0);
    $permissions = $data['permissions'] ?? [];
    $groupName = $data['group_name'] ?? '';

    if (!$groupId)
        throw new Exception("Group ID required");

    if ($groupName) {
        $stmt = $db->prepare("UPDATE dd_user_Groups SET name = ? WHERE id = ?");
        $stmt->execute([$groupName, $groupId]);
    }

    $updates = [];
    $params = [];
    $allowedCols = ['allow_view_all', 'allow_manage_projects', 'allow_manage_users', 'allow_manage_configuration', 'allow_manage_tasks', 'allow_manage_tickets'];

    foreach ($permissions as $key => $val) {
        if (in_array($key, $allowedCols)) {
            $updates[] = "$key = ?";
            $params[] = $val ? 1 : 0;
        }
    }

    if (!empty($updates)) {
        $params[] = $groupId;
        $sql = "UPDATE dd_user_Groups SET " . implode(', ', $updates) . " WHERE id = ?";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
    }

    Logger::log("Permissions updated for group $groupId", 'INFO', ['user_id' => $_SESSION['user_id'] ?? 0, 'group_id' => $groupId, 'updates' => $permissions]);
    return ['message' => 'Permissions updated'];
}

function get_user_groups($db)
{
    require_permission('allow_manage_users');
    $stmt = $db->query("SELECT * FROM dd_user_Groups ORDER BY id ASC");
    return $stmt->fetchAll();
}

function delete_user_group($db)
{
    require_permission('allow_manage_users');
    $id = (int) ($_GET['id'] ?? 0);
    if (!$id)
        throw new Exception("Group ID required");

    $stmt = $db->prepare("SELECT COUNT(*) FROM dd_users WHERE group_id = ?");
    $stmt->execute([$id]);
    if ($stmt->fetchColumn() > 0) {
        throw new Exception("Cannot delete group: It has assigned users.");
    }

    $stmt = $db->prepare("DELETE FROM dd_user_Groups WHERE id = ?");
    $stmt->execute([$id]);
    return ['message' => 'Group deleted'];
}

function get_users($db)
{
    require_permission('allow_manage_users');
    $stmt = $db->query("SELECT u.id, u.name, u.email, u.active, u.group_id, g.name as group_name 
                        FROM dd_users u 
                        LEFT JOIN dd_user_Groups g ON u.group_id = g.id 
                        ORDER BY u.name ASC");
    return $stmt->fetchAll();
}

function list_users_simple($db)
{
    // Lighter permission check
    if (!isset($_SESSION['user_id']))
        throw new Exception("Not authenticated");

    $stmt = $db->query("SELECT id, name FROM dd_users WHERE active = 1 ORDER BY name ASC");
    return ['data' => $stmt->fetchAll(PDO::FETCH_ASSOC)];
}

function get_user($db)
{
    require_permission('allow_manage_users');
    $id = (int) ($_GET['id'] ?? 0);
    if (!$id)
        throw new Exception("User ID required");

    $stmt = $db->prepare("SELECT id, name, email, active, group_id FROM dd_users WHERE id = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch();
    if (!$user)
        throw new Exception("User not found");
    return $user;
}

function create_user($db)
{
    require_permission('allow_manage_users');
    $data = json_decode(file_get_contents('php://input'), true);

    $name = $data['name'] ?? '';
    $email = $data['email'] ?? '';
    $password = $data['password'] ?? '';
    $group_id = (int) ($data['group_id'] ?? 0);
    $active = isset($data['active']) ? (int) $data['active'] : 1;

    if (!$name || !$email || !$password) {
        throw new Exception("Name, Email and Password are required");
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $db->prepare("INSERT INTO dd_users (name, email, password, group_id, active) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$name, $email, $hashedPassword, $group_id, $active]);

    return ['message' => 'User created', 'id' => $db->lastInsertId()];
}

function update_user($db)
{
    require_permission('allow_manage_users');
    $data = json_decode(file_get_contents('php://input'), true);

    $id = (int) ($data['id'] ?? 0);
    $name = $data['name'] ?? '';
    $email = $data['email'] ?? '';
    $group_id = (int) ($data['group_id'] ?? 0);
    $active = isset($data['active']) ? (int) $data['active'] : 1;
    $password = $data['password'] ?? '';

    if (!$id || !$name || !$email) {
        throw new Exception("ID, Name and Email are required");
    }

    if ($password) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $db->prepare("UPDATE dd_users SET name = ?, email = ?, group_id = ?, active = ?, password = ? WHERE id = ?");
        $stmt->execute([$name, $email, $group_id, $active, $hashedPassword, $id]);
    } else {
        $stmt = $db->prepare("UPDATE dd_users SET name = ?, email = ?, group_id = ?, active = ? WHERE id = ?");
        $stmt->execute([$name, $email, $group_id, $active, $id]);
    }

    return ['message' => 'User updated'];
}

function delete_user($db)
{
    require_permission('allow_manage_users');
    $id = (int) ($_GET['id'] ?? 0);
    if (!$id)
        throw new Exception("User ID required");

    if ($id === (int) ($_SESSION['user_id'] ?? 0)) {
        throw new Exception("Cannot delete your own account");
    }

    $stmt = $db->prepare("DELETE FROM dd_users WHERE id = ?");
    $stmt->execute([$id]);
    return ['message' => 'User deleted'];
}

function enable_2fa($db)
{
    require_permission('allow_view_all');
    require_once __DIR__ . '/../../core/totp.php';

    $userId = $_SESSION['user_id'] ?? null;
    if (!$userId)
        throw new Exception("Not authenticated");

    $secret = TOTP::generateSecret();
    $stmt = $db->prepare("UPDATE dd_users SET totp_secret = ? WHERE id = ?");
    $stmt->execute([$secret, $userId]);

    $stmt = $db->prepare("SELECT email FROM dd_users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    $qrCodeURL = TOTP::getQRCodeURL($secret, $user['email']);
    $provisioningURI = TOTP::getProvisioningUri($secret, $user['email']);

    return [
        'secret' => $secret,
        'qr_code_url' => $qrCodeURL,
        'provisioning_uri' => $provisioningURI,
        'message' => 'Scan QR code'
    ];
}

function verify_2fa_setup($db)
{
    require_permission('allow_view_all');
    require_once __DIR__ . '/../../core/totp.php';

    $userId = $_SESSION['user_id'] ?? null;
    $code = $_POST['code'] ?? '';

    if (!$userId || !$code)
        throw new Exception("Invalid request");

    $stmt = $db->prepare("SELECT totp_secret FROM dd_users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    if (!$user || !TOTP::verify($user['totp_secret'], $code)) {
        throw new Exception("Invalid code");
    }

    $stmt = $db->prepare("UPDATE dd_users SET totp_enabled = 1 WHERE id = ?");
    $stmt->execute([$userId]);

    return ['message' => '2FA enabled'];
}

function disable_2fa($db)
{
    require_permission('allow_view_all');
    $userId = $_SESSION['user_id'] ?? null;
    $password = $_POST['password'] ?? '';

    if (!$userId || !$password)
        throw new Exception("Invalid request");

    $stmt = $db->prepare("SELECT password FROM dd_users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        throw new Exception("Invalid password");
    }

    $stmt = $db->prepare("UPDATE dd_users SET totp_enabled = 0, totp_secret = NULL WHERE id = ?");
    $stmt->execute([$userId]);

    return ['message' => '2FA disabled'];
}

function get_2fa_status($db)
{
    require_permission('allow_view_all');
    $userId = $_SESSION['user_id'] ?? null;
    $stmt = $db->prepare("SELECT totp_enabled FROM dd_users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    return ['enabled' => (bool) ($user['totp_enabled'] ?? false)];
}

function get_constants($db)
{
    require_permission('allow_manage_configuration');
    $projectId = isset($_GET['project_id']) ? (int) $_GET['project_id'] : null;
    $sql = "SELECT * FROM dd_system_constants WHERE project_id IS NULL";
    $params = [];
    if ($projectId) {
        $sql .= " OR project_id = ?";
        $params[] = $projectId;
    }
    $sql .= " ORDER BY key_name ASC";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function save_constant($db)
{
    require_permission('allow_manage_configuration');
    $input = json_decode(file_get_contents('php://input'), true);
    $key = $input['key_name'] ?? '';
    $value = $input['value'] ?? '';
    $projectId = isset($input['project_id']) ? (int) $input['project_id'] : null;
    $id = isset($input['id']) ? (int) $input['id'] : 0;

    if (!$key)
        throw new Exception("Key name required");

    if ($id) {
        $stmt = $db->prepare("UPDATE dd_system_constants SET key_name=?, value=?, description=?, project_id=? WHERE id=?");
        $stmt->execute([$key, $value, $input['description'] ?? '', $projectId, $id]);
    } else {
        $stmt = $db->prepare("INSERT INTO dd_system_constants (key_name, value, description, project_id) VALUES (?, ?, ?, ?)");
        $stmt->execute([$key, $value, $input['description'] ?? '', $projectId]);
    }
    return ['success' => true];
}
