<?php
// modules/auth/api-endpoints.php

function handle_api($action, $db)
{
    switch ($action) {
        case 'login':
            return handle_login($db);
        case 'verify_otp':
            return handle_verify_otp($db);
        default:
            throw new Exception("Unknown auth action: " . $action);
    }
}

function handle_login($db)
{
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    $email = $data['email'] ?? '';
    $password = $data['password'] ?? '';

    if (!$email || !$password) {
        json_response(['success' => false, 'error' => 'Email and password required'], 400);
    }

    // Check rate limit manually first to give better feedback
    require_once __DIR__ . '/../../core/rate_limiter.php';
    $clientIP = get_client_ip();
    $rateLimit = RateLimiter::checkLimit($clientIP, 'login', 5, 300);

    if (!$rateLimit['allowed']) {
        json_response(['success' => false, 'error' => $rateLimit['message']], 429);
    }

    if (login_user($email, $password)) {
        return ['message' => 'Login successful', 'redirect' => 'index.php'];
    }

    // Check if 2FA pending (this is set inside login_user if creds were correct but code missing/wrong)
    if (isset($_SESSION['2fa_pending'])) {
        return ['status' => '2fa_required', 'user_id' => $_SESSION['2fa_pending']];
    }

    // If we reached here, login_user returned false but wasn't rate limited (initially)
    // or it's a genuine invalid credential.
    json_response(['success' => false, 'error' => 'Invalid credentials'], 401);
}

function handle_verify_otp($db)
{
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    $code = $data['code'] ?? '';
    // We need to re-login with code, or verify against pending?
    // security.php login_user accepts code as 3rd arg.
    // Ideally we re-submit credentials + code, OR we have a specialized verify function.
    // login_user() does everything.
    // If we are in '2fa_pending' state, we need to know WHO is trying to login.
    // We should probably rely on having the email/password again OR storing partial auth.
    // But sending password again is risky/annoying for UI.
    // Let's see how security.php handles it.
    // It takes ($email, $password, $totpCode).

    // If we only have code, we can't use login_user easily unless we cached creds (bad) or rely on pending session.
    // Let's look at security.php again. 
    // It doesn't seem to have a separate "verify_otp_for_pending_login" function.
    // I will implement a helper here if needed, or assume the UI sends everything back.
    // For now, I'll assume the UI sends the password again or I'll add a helper to security.php?
    // No, I can't edit core easily without breaking things.
    // Actually, I can edit core/security.php if needed.
    // OR: I store email in session during step 1?

    // Better: Step 1 verifies password. If 2FA needed, store '2fa_pending_user_id' in session.
    // Step 2: verify_otp calls a new function or manual check.

    if (!isset($_SESSION['2fa_pending'])) {
        throw new Exception("No pending login found");
    }

    $userId = $_SESSION['2fa_pending'];
    // Verify code manually against user
    require_once __DIR__ . '/../../core/totp.php';

    $stmt = $db->prepare("SELECT totp_secret FROM dd_users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    if ($user && TOTP::verify($user['totp_secret'], $code)) {
        // Log them in manually
        // Check core/security.php logic for session setup
        // We can't easily call "login_user" without password.
        // I will duplicate the session setup logic here or make a helper in security.php.
        // Let's duplicate carefully for now.

        $stmt = $db->prepare("SELECT * FROM dd_users WHERE id = ?");
        $stmt->execute([$userId]);
        $fullUser = $stmt->fetch();

        $_SESSION['user_id'] = $fullUser['id'];
        $_SESSION['user_name'] = $fullUser['name'];
        $_SESSION['user_role'] = 'user';

        if ($fullUser['group_id']) {
            $gStmt = $db->prepare("SELECT name FROM dd_user_Groups WHERE id = ?");
            $gStmt->execute([$fullUser['group_id']]);
            $group = $gStmt->fetch();
            if ($group && strtolower($group['name']) === 'admin') {
                $_SESSION['user_role'] = 'admin';
            }
        }

        initialize_session_fingerprint();
        unset($_SESSION['2fa_pending']);
        Logger::log("Successful 2FA login", 'INFO', ['user_id' => $userId]);

        return ['message' => 'Login successful', 'redirect' => 'index.php'];
    }

    throw new Exception("Invalid OTP code");
}
?>