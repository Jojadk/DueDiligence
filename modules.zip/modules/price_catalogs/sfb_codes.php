<?php
// modules/price_catalogs/sfb_codes.php

function get_sfb_mapping()
{
    return [
        // Hovedgruppe 0: (Sjældent brugt, men for fuldstændighed)

        // Hovedgruppe 1: Terræn
        '10' => 'Terræn, generelt',
        '11' => 'Terrænbearbejdning',
        '12' => 'Belægninger',
        '13' => 'Beplantning',
        '14' => 'Terræninventar',
        '15' => 'Ledninger i terræn',

        // Hovedgruppe 2: Primære bygningsdele
        '20' => 'Primære bygningsdele, generelt',
        '21' => 'Ydervægge',
        '22' => 'Indervægge',
        '23' => 'Dæk og trapper',
        '24' => 'Tage',
        '25' => 'Altaner og kviste',
        '26' => 'Trapper og ramper',
        '27' => 'Fundamenter og kældervægge',
        '28' => 'Søjler og bjælker',
        '29' => 'Primære bygningsdele, diverse',

        // Hovedgruppe 3: Komplettering
        '30' => 'Komplettering, generelt',
        '31' => 'Ydervægsbeklædninger',
        '32' => 'Indervægsbeklædninger',
        '33' => 'Gulvbelægninger',
        '34' => 'Loftsbeklædninger',
        '35' => 'Værn og gelændere',
        '36' => 'Vinduer og døre',
        '37' => 'Faste indretninger',
        '38' => 'Løst inventar',
        '39' => 'Komplettering, diverse',

        // Hovedgruppe 4: Overflader
        '40' => 'Overflader, generelt',
        '41' => 'Malerbehandling udvendig',
        '42' => 'Malerbehandling indvendig',
        '43' => 'Gulvbehandling',
        '44' => 'Vægge - overflader',
        '45' => 'Lofter - overflader',
        '46' => 'Installationsoverflader',
        '47' => 'Overflader, diverse',

        // Hovedgruppe 5: VVS
        '50' => 'VVS-anlæg, generelt',
        '51' => 'Afløb',
        '52' => 'Vand',
        '53' => 'Sanitet',
        '54' => 'Varme',
        '55' => 'Gas og trykluft',
        '56' => 'Køling',
        '57' => 'Ventilation',
        '58' => 'Isolering af installationer',
        '59' => 'VVS, diverse',

        // Hovedgruppe 6: El
        '60' => 'El-anlæg, generelt',
        '61' => 'El-forsyning',
        '62' => 'Kraftinstallationer',
        '63' => 'Belysning',
        '64' => 'Kommunikation/Svagstrøm',
        '65' => 'Sikringsanlæg',
        '66' => 'Elevatorer',
        '67' => 'Lynafleder',
        '68' => 'El-anlæg, diverse',
        '69' => 'El-anlæg, andet',

        // Hovedgruppe 7: Inventar
        '70' => 'Inventar, generelt',
        '71' => 'Køkkeninventar',
        '72' => 'Bad- og toiletinventar',
        '73' => 'Hvidevarer',
        '74' => 'Skabe og reoler',
        '75' => 'Specialinventar',
        '76' => 'Inventar, diverse',

        // Hovedgruppe 8: Diverse
        '80' => 'Diverse',

        // Hovedgruppe 9: Byggeplads
        '90' => 'Byggeplads, generelt',
        '91' => 'Midlertidige konstruktioner',
        '92' => 'Byggepladsindretning',
        '99' => 'Byggeplads, diverse'
    ];
}
