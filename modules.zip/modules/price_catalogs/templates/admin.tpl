<div class="pc-layout">
    <div class="pc-sidebar">
        <div class="pc-sidebar-header">
            Kategorier
        </div>
        <div id="pc-category-tree" class="pc-cat-tree">
            <!-- Rendered by JS -->
            <div class="loading-spinner" style="margin:20px"></div>
        </div>
    </div>
    
    <div class="pc-content">
        <div class="module-header">
            <h1 style="font-size:1.2rem; margin:0"><i class="fas fa-tags"></i> Priskatalog</h1>
            <div class="controls" style="display:flex; align-items:center;">
                <div class="search-box">
                     <i class="fas fa-search"></i>
                    <input type="text" id="pc-search" placeholder="Søg..." onkeyup="App.priceCatalogAdmin.search(this.value)">
                </div>
                <label class="toggle-switch">
                    <input type="checkbox" id="pc-favorites-only" onchange="App.priceCatalogAdmin.toggleFavorites(this.checked)">
                    <span class="slider round"></span>
                    <span class="label-text">Favoritter</span>
                </label>
            </div>
            <a href="index.php?module=bundles" class="dd-btn dd-btn-secondary" style="margin-left: 10px; text-decoration: none; display: flex; align-items: center; gap: 6px;">
                 <i class="fas fa-boxes"></i> Prispakker
            </a>
        </div>

        <div class="pc-table-container">
            <div id="pc-table-wrapper" style="flex:1; overflow-y:auto">
                <!-- Table rendered here -->
            </div>
            <div id="pc-pagination" class="pc-pagination">
                <!-- Pagination controls -->
            </div>
        </div>
    </div>
</div>

<link rel="stylesheet" href="public/css/price_catalog_admin.css?v=<?php echo time(); ?>">
<script src="public/js/price_catalog_admin.js?v=<?php echo time(); ?>"></script>
<script>
    (function() {
        var retries = 0;
        var initInterval = setInterval(function() {
            if (window.App && window.App.priceCatalogAdmin) {
                clearInterval(initInterval);
                console.log("PriceCatalogAdmin initialized via poller");
                window.App.priceCatalogAdmin.init('pc-table-wrapper', 'pc-category-tree', 'pc-pagination');
            }
            retries++;
            if (retries > 50) clearInterval(initInterval); // 5s max
        }, 100);
    })();
</script>
