<?php
// modules/price_catalogs/api-endpoints.php

require_once __DIR__ . '/sfb_codes.php';

function handle_api($action, $db)
{
    // require_permission('allow_manage_configuration');
    // file_put_contents(__DIR__ . '/../../debug_permission.log', date('Y-m-d H:i:s') . " Action: $action\n", FILE_APPEND);

    switch ($action) {
        case 'toggle_favorite':
            return toggle_favorite($db);
        case 'update_tags':
            return update_tags($db);
        case 'list_usage':
            return list_usage($db);
        case 'update_item':
            return update_item($db);
        case 'get_category_tree':
            return get_category_tree($db);
        default:
            throw new Exception("Unknown price_catalogs action: " . $action);
    }
}

function toggle_favorite($db)
{
    $id = $_POST['id'] ?? null;
    $state = $_POST['state'] ?? null;
    if (!$id)
        throw new Exception("ID required");
    $stmt = $db->prepare("UPDATE dd_price_catalogs SET is_favorite = ? WHERE id = ?");
    $stmt->execute([$state ? 1 : 0, $id]);
    return ['success' => true, 'id' => $id, 'is_favorite' => (bool) $state];
}

function update_item($db)
{
    $id = $_POST['id'] ?? null;
    $description = $_POST['description'] ?? null;
    $unit_price = $_POST['unit_price'] ?? null;
    $unit = $_POST['unit'] ?? null;
    $tags = $_POST['tags'] ?? '';
    $is_favorite = isset($_POST['is_favorite']) ? ($_POST['is_favorite'] ? 1 : 0) : null;

    if (!$id)
        throw new Exception("ID required");

    $updates = [];
    $params = [];

    if ($description !== null) {
        $updates[] = "description = ?";
        $params[] = $description;
    }
    if ($unit_price !== null) {
        $updates[] = "unit_price = ?";
        $params[] = $unit_price;
    }
    if ($unit !== null) {
        $updates[] = "unit = ?";
        $params[] = $unit;
    }
    if ($tags !== null) {
        $updates[] = "tags = ?";
        $params[] = $tags;
    }
    if ($is_favorite !== null) {
        $updates[] = "is_favorite = ?";
        $params[] = $is_favorite;
    }

    if (empty($updates))
        return ['success' => true, 'message' => 'No changes'];

    $params[] = $id;
    $sql = "UPDATE dd_price_catalogs SET " . implode(', ', $updates) . " WHERE id = ?";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);

    return ['success' => true];
}

function update_tags($db)
{
    $id = $_POST['id'] ?? null;
    $tags = $_POST['tags'] ?? '';
    if (!$id)
        throw new Exception("ID required");
    $stmt = $db->prepare("UPDATE dd_price_catalogs SET tags = ? WHERE id = ?");
    $stmt->execute([$tags, $id]);
    return ['success' => true, 'tags' => $tags];
}

function get_category_tree($db)
{
    $sfbMap = get_sfb_mapping();

    // Get distinct groups (item grouped by prefix e.g. (10), (63))
    // We also want counts.
    // Query: SELECT SUBSTRING_INDEX(item_code, ')', 1) as g, COUNT(*) as cnt FROM dd_price_catalogs WHERE item_code LIKE '%)%' GROUP BY g ORDER BY g

    $groups = $db->query("SELECT SUBSTRING_INDEX(item_code, ')', 1) as g, COUNT(*) as cnt FROM dd_price_catalogs WHERE item_code LIKE '%)%' GROUP BY g ORDER BY LENGTH(g), g")->fetchAll(PDO::FETCH_ASSOC);

    $tree = [];
    foreach ($groups as $row) {
        $g = $row['g']; // "(10" or "(63"
        $count = $row['cnt'];
        $gFull = $g . ')'; // "(10)"

        // Clean code: "10" or "63"
        $gCode = trim($g, '()');

        // Determine label
        // Try exact match, 'X0' match (e.g. 63 -> 60 logic? No, 63 is distinct). 
        // Just use exact or fall back to code.
        $gLabel = $sfbMap[$gCode] ?? $sfbMap[$gCode . '0'] ?? '';
        if (!$gLabel && strlen($gCode) == 2) {
            // If 63 not found, maybe try 60?
            $mainGroup = substr($gCode, 0, 1) . '0';
            $gLabel = $sfbMap[$mainGroup] ?? '';
        }

        $displayName = $gFull . ($gLabel ? " $gLabel" : "") . " <small>($count)</small>";

        // Sub-items (Chapters)
        // We look for chapters inside this group.
        // item_code structure: (10)21.20
        // We want '21'
        $sqlSub = "SELECT 
                    SUBSTRING_INDEX(SUBSTRING_INDEX(item_code, '.', 1), ')', -1) as chap, 
                    COUNT(*) as cnt
                   FROM dd_price_catalogs 
                   WHERE item_code LIKE ?
                   GROUP BY chap
                   ORDER BY LENGTH(chap), chap";
        $stmtSub = $db->prepare($sqlSub);
        $stmtSub->execute([$gFull . '%']);
        $subs = $stmtSub->fetchAll(PDO::FETCH_ASSOC);

        $children = [];
        foreach ($subs as $sRow) {
            $s = $sRow['chap'];
            $sCount = $sRow['cnt'];
            if (!$s)
                continue;

            // Map chapter name
            $sLabel = $sfbMap[$s] ?? $s; // 21 -> Ydervægge

            // If just number, try to append label
            $sDisplay = "$s $sLabel";
            if ($s === $sLabel)
                $sDisplay = $s; // No mapping, just code
            else
                $sDisplay = "$sLabel"; // Or "21 Ydervægge"

            // Actually user wants "CategoryName (count)"
            // Let's do "Code Name (count)"
            if (isset($sfbMap[$s])) {
                $sDisplay = "$s " . $sfbMap[$s];
            }

            $sDisplay .= " <small>($sCount)</small>";

            $children[] = [
                'id' => $gFull . $s,
                'name' => $sDisplay,
                'type' => 'chapter'
            ];
        }

        $tree[] = [
            'id' => $gFull,
            'name' => $displayName,
            'children' => $children,
            'type' => 'group'
        ];
    }

    return $tree;
}

function list_usage($db)
{
    $onlyFavorites = filter_var($_GET['favorites_only'] ?? false, FILTER_VALIDATE_BOOLEAN);
    $search = $_GET['search'] ?? '';
    $categoryPrefix = $_GET['category_prefix'] ?? '';

    $sortBy = $_GET['sort'] ?? 'usage_count';
    $order = strtoupper($_GET['order'] ?? 'DESC');

    $page = max(1, (int) ($_GET['page'] ?? 1));
    $limit = max(1, min(200, (int) ($_GET['limit'] ?? 50)));
    $offset = ($page - 1) * $limit;

    $params = [];
    $whereClauses = ["1=1"];

    if ($onlyFavorites) {
        $whereClauses[] = "is_favorite = 1";
    }

    if ($search) {
        $whereClauses[] = "(name LIKE ? OR description LIKE ? OR item_code LIKE ? OR tags LIKE ?)";
        $term = "%$search%";
        $params[] = $term;
        $params[] = $term;
        $params[] = $term;
        $params[] = $term;
    }

    if ($categoryPrefix) {
        if (substr($categoryPrefix, -1) === ')') {
            // (10) matches (10)21...
            $whereClauses[] = "item_code LIKE ?";
            $params[] = $categoryPrefix . '%';
        } else {
            // (10)21 matches (10)21.xx
            $whereClauses[] = "(item_code = ? OR item_code LIKE ?)";
            $params[] = $categoryPrefix;
            $params[] = $categoryPrefix . '.%';
        }
    }

    $whereSql = implode(' AND ', $whereClauses);

    $allowedSort = ['name', 'unit_price', 'usage_count', 'is_favorite', 'item_code'];
    if (!in_array($sortBy, $allowedSort))
        $sortBy = 'usage_count';
    if ($order !== 'ASC')
        $order = 'DESC';

    // Base query wrapper
    // We union the view with bundles
    // Bundles don't have usage_count or is_favorite tracked in the same way, forcing 0 for now.
    // Bundle Item Code is 'PAKKE-' + id

    $commonColumns = "id, item_code, name, unit, unit_price, tags, is_favorite, usage_count, description, type";

    $sql = "
        SELECT $commonColumns FROM (
            SELECT 
                id, 
                CAST(item_code AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_general_ci as item_code, 
                CAST(name AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_general_ci as name, 
                CAST(unit AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_general_ci as unit, 
                unit_price, 
                CAST(tags AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_general_ci as tags, 
                is_favorite, 
                usage_count, 
                CAST(description AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_general_ci as description,
                'catalog' as type
            FROM v_price_catalog_usage

            UNION ALL

            SELECT 
                id, 
                CAST(CONCAT('PAKKE-', id) AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_general_ci as item_code, 
                CAST(name AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_general_ci as name, 
                CAST('pakke' AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_general_ci as unit, 
                (SELECT COALESCE(SUM(quantity * unit_price), 0) FROM dd_price_catalog_bundle_items WHERE bundle_id = b.id) as unit_price, 
                CAST(tags AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_general_ci as tags, 
                is_favorite, 
                0 as usage_count, 
                CAST(description AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_general_ci as description,
                'bundle' as type
            FROM dd_price_catalog_bundles b
        ) as combined
        WHERE $whereSql
        ORDER BY $sortBy $order
        LIMIT $limit OFFSET $offset
    ";

    // Count query
    $countSql = "
        SELECT COUNT(*) FROM (
            SELECT 
                id, 
                CAST(item_code AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_general_ci as item_code, 
                CAST(name AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_general_ci as name, 
                CAST(description AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_general_ci as description, 
                CAST(tags AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_general_ci as tags, 
                is_favorite 
            FROM v_price_catalog_usage
            
            UNION ALL
            
            SELECT 
                id, 
                CAST(CONCAT('PAKKE-', id) AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_general_ci as item_code, 
                CAST(name AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_general_ci as name, 
                CAST(description AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_general_ci as description, 
                CAST(tags AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_general_ci as tags, 
                is_favorite 
            FROM dd_price_catalog_bundles
        ) as combined
        WHERE $whereSql
    ";

    $stmtCount = $db->prepare($countSql);
    $stmtCount->execute($params);
    $total = $stmtCount->fetchColumn();

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return [
        'data' => $items,
        'total' => (int) $total,
        'page' => $page,
        'limit' => $limit,
        'pages' => ceil($total / $limit)
    ];
}
