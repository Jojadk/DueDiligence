<?php
// modules/custom_fields/api.php

function handle_api($action, $db)
{
    switch ($action) {
        case 'cf_get_definitions':
            return cf_get_definitions($db);
        case 'cf_save_definition':
            return cf_save_definition($db);
        case 'cf_get_values':
            return cf_get_values($db);
        case 'cf_save_values':
            return cf_save_values($db);
        case 'cf_delete_definition':
            return cf_delete_definition($db);
        default:
            throw new Exception("Unknown custom_fields action: " . $action);
    }
}

function cf_get_definitions($db)
{
    $projectId = isset($_GET['project_id']) ? (int) $_GET['project_id'] : null;
    $entityType = $_GET['entity_type'] ?? 'building_element';

    // Get Global + Project specific
    $sql = "SELECT * FROM dd_custom_field_definitions WHERE entity_type = ? AND (scope = 'global'";
    $params = [$entityType];

    if ($projectId) {
        $sql .= " OR (scope = 'project' AND project_id = ?)";
        $params[] = $projectId;
    }
    $sql .= ") ORDER BY sort_order ASC";

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function cf_save_definition($db)
{
    // Admin only usually
    require_permission('allow_manage_configuration');

    $input = json_decode(file_get_contents('php://input'), true);
    $id = (int) ($input['id'] ?? 0);
    $label = $input['label'] ?? '';
    $type = $input['field_type'] ?? 'text';

    if (!$label)
        throw new Exception("Label required");

    if ($id) {
        $stmt = $db->prepare("UPDATE dd_custom_field_definitions SET label=?, field_type=?, options=?, sort_order=? WHERE id=?");
        $stmt->execute([
            $label,
            $type,
            $input['options'] ?? null,
            $input['sort_order'] ?? 0,
            $id
        ]);
        return ['success' => true];
    } else {
        $stmt = $db->prepare("INSERT INTO dd_custom_field_definitions (label, field_type, entity_type, scope, project_id, options, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $label,
            $type,
            $input['entity_type'] ?? 'building_element',
            $input['scope'] ?? 'global',
            $input['project_id'] ?? null,
            $input['options'] ?? null,
            $input['sort_order'] ?? 0
        ]);
        return ['success' => true, 'id' => $db->lastInsertId()];
    }
}

function cf_get_values($db)
{
    $bindId = (int) ($_GET['bind_id'] ?? 0);
    // Maybe filter by entity type? For now just fetch by bind_id (assuming element_id unique enough or matched by caller context)
    // Actually bind_id is tied to entity. Values table just holds definition_id and bind_id.

    if (!$bindId)
        return [];

    $stmt = $db->prepare("SELECT v.*, d.label, d.field_type FROM dd_custom_field_values v JOIN dd_custom_field_definitions d ON v.definition_id = d.id WHERE v.bind_id = ?");
    $stmt->execute([$bindId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function cf_save_values($db)
{
    $input = json_decode(file_get_contents('php://input'), true);
    $bindId = (int) ($input['bind_id'] ?? 0);
    $values = $input['values'] ?? []; // Array of [definition_id => value]

    if (!$bindId)
        throw new Exception("Bind ID required");

    $db->beginTransaction();
    try {
        // Naive upsert or delete-insert? 
        // Let's do Insert on Duplicate Key Update or check existence.
        // Or just loop and update/insert.

        $stmtCheck = $db->prepare("SELECT id FROM dd_custom_field_values WHERE definition_id = ? AND bind_id = ?");
        $stmtUpd = $db->prepare("UPDATE dd_custom_field_values SET value = ? WHERE id = ?");
        $stmtIns = $db->prepare("INSERT INTO dd_custom_field_values (definition_id, bind_id, value) VALUES (?, ?, ?)");

        foreach ($values as $defId => $val) {
            $stmtCheck->execute([$defId, $bindId]);
            $existing = $stmtCheck->fetch();

            if ($existing) {
                $stmtUpd->execute([$val, $existing['id']]);
            } else {
                $stmtIns->execute([$defId, $bindId, $val]);
            }
        }
        $db->commit();
        return ['success' => true];
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

function cf_delete_definition($db)
{
    require_permission('allow_manage_configuration');
    $id = (int) ($_GET['id'] ?? 0);
    if (!$id)
        throw new Exception("ID required");

    $db->prepare("DELETE FROM dd_custom_field_definitions WHERE id = ?")->execute([$id]);
    return ['success' => true];
}
?>