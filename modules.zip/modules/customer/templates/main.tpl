<div class="dd-card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
        <div>
            <h2 style="margin: 0;">Customers</h2>
            <p style="margin: 0.25rem 0 0 0; color: var(--gray-500); font-size: 0.875rem;"><span id="customer-count">0</span> customers</p>
        </div>
        <button id="btn-add-customer" name="btn_add_customer" class="dd-btn dd-btn-primary" onclick="App.customer.showAddModal()">
            <span class="nav-icon" data-icon="add"></span>
            New Customer
        </button>
    </div>

    <input type="text" id="customer-search" name="customer_search" class="dd-input" placeholder="Search customers by name or email..." style="margin-bottom: 1rem;" onkeyup="App.customer.handleSearch(this.value)">

    <div class="dd-table-wrapper">
        <table id="customer-table" name="customer_table" class="dd-table">
            <thead>
                <tr>
                    <th onclick="App.customer.sort('id')" style="cursor:pointer;" data-sort="id">ID <span class="sort-icon">⇅</span></th>
                    <th onclick="App.customer.sort('name')" style="cursor:pointer;" data-sort="name">Name <span class="sort-icon">⇅</span></th>
                    <th onclick="App.customer.sort('category_name')" style="cursor:pointer;" data-sort="category_name">Category <span class="sort-icon">⇅</span></th>
                    <th onclick="App.customer.sort('email')" style="cursor:pointer;" data-sort="email">Email <span class="sort-icon">⇅</span></th>
                    <th onclick="App.customer.sort('created_at')" style="cursor:pointer;" data-sort="created_at">Created <span class="sort-icon">⇅</span></th>
                    <th style="text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody id="customer-table-body">
                <tr><td colspan="6" style="text-align: center; padding: 2rem; color: var(--gray-500);">Loading...</td></tr>
            </tbody>
        </table>
    </div>
    <div id="customer-pagination"></div>
</div>

<div id="customer-details-section" style="display: none;">
    <!-- Details (Projects/Buildings/Comments) will be loaded here -->
</div>

<script>
    // SPA-compatible: Run immediately since DOMContentLoaded has already fired
    (function() {
        const checkAndInit = () => {
            if (App.customer && typeof App.customer.init === 'function') {
                App.customer.init();
                console.log("Init main.tpl customer");
            } else {
                setTimeout(checkAndInit, 50);
                console.log("Init main.tpl customer Timer");
            }
        };
        checkAndInit();
    })();
</script>
