<div class="module-header">
    <h1>All Projects</h1>
        <button id="btn-add-project" name="btn_add_project" class="dd-btn dd-btn-primary" onclick="App.customer.showAddProjectModal()">
            <span class="nav-icon" data-icon="add"></span>
            New Project
        </button>
</div>

<div id="projects-list-container" class="dd-content-panel">
    <div class="dd-table-wrapper">
        <div style="margin-bottom: 1rem; display: flex; gap: 1rem;">
            <input type="text" id="projects-search" name="projects_search" class="dd-input" placeholder="Search projects..." onkeyup="App.customer.filterProjects(this.value)" style="max-width: 300px;">
        </div>
        <table id="projects-table" name="projects_table" class="dd-table">
            <thead>
                <tr>
                    <th onclick="App.customer.sortProjects('id')" style="cursor:pointer;">ID <span class="sort-icon">⇅</span></th>
                    <th onclick="App.customer.sortProjects('name')" style="cursor:pointer;">Project Name <span class="sort-icon">⇅</span></th>
                    <th onclick="App.customer.sortProjects('customer_name')" style="cursor:pointer;">Customer <span class="sort-icon">⇅</span></th>
                    <th onclick="App.customer.sortProjects('status')" style="cursor:pointer;">Status <span class="sort-icon">⇅</span></th>
                    <th onclick="App.customer.sortProjects('created_at')" style="cursor:pointer;">Created <span class="sort-icon">⇅</span></th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="projects-table-body">
                <tr><td colspan="6" style="text-align:center;">Loading projects...</td></tr>
            </tbody>
        </table>
    </div>
</div>

<div id="customer-details-section" style="display: none; margin-top: 2rem; border-top: 1px solid var(--border); padding-top: 2rem;">
    <!-- Details loaded here -->
</div>

<script>
    // SPA-compatible: Run immediately since DOMContentLoaded has already fired
    (function() {
        // Wait for App to be fully initialized if needed
        const checkAndInit = () => {
            if (App.customer && App.customer.loadAllProjects) {
                App.customer.loadAllProjects();
            } else {
                setTimeout(checkAndInit, 50);
            }
        };
        checkAndInit();
    })();
</script>


