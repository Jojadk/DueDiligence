<?php
// modules/customer/api-endpoints.php

function handle_api($action, $db)
{
    // Permission Checks
    switch ($action) {
        case 'list':
        case 'get':
        case 'get_customer':
        case 'get_customer_details':
        case 'list_projects':
        case 'get_project':
        case 'list_all_projects':
        case 'list_buildings':
        case 'list_elements':
        case 'get_condition_distribution':
        case 'list_tasks':
        case 'get_intervals':
            require_permission('allow_view_all');
            break;
        case 'create':
        case 'update':
        case 'delete':
        case 'create_project':
        case 'update_project':
        case 'delete_project':
            require_permission('allow_manage_projects');
            break;
    }

    switch ($action) {
        case 'list':
            return list_customers($db);
        case 'create':
            return create_customer($db);
        case 'update':
            return update_customer($db);
        case 'get':
        case 'get_customer': // restored for compatibility
        case 'get_customer_details':
            return get_customer($db);
        case 'delete':
            return delete_customer($db);
        case 'list_projects':
            return list_projects($db);
        case 'get_project':
            return get_project($db);
        case 'list_all_projects':
            return list_all_projects($db);
        case 'create_project':
            return create_project($db);
        case 'update_project':
            return update_project($db);
        case 'delete_project':
            return delete_project($db);
        case 'list_buildings':
            return list_buildings($db);
        case 'list_elements':
            return list_elements($db);
        case 'get_condition_distribution':
            return get_condition_distribution($db);
        case 'list_tasks':
            return list_tasks($db);
        case 'get_intervals':
            return get_project_intervals((int) ($_GET['project_id'] ?? 0));
        case 'get_capex_summary':
            return get_capex_summary($db);
        case 'get_categories':
            return get_customer_categories($db);
        case 'search':
            return search_customers($db);
        case 'search_projects':
            return search_projects($db);
        case 'upload_logo':
            return upload_logo($db);
        default:
            throw new Exception("Unknown action: " . $action);
    }
}

function upload_logo($db)
{
    // Permission check removed to allow any authenticated user.

    $customerId = $_POST['customer_id'] ?? null;
    if (!$customerId) {
        throw new Exception("Customer ID required");
    }

    if (empty($_FILES['logo']) || $_FILES['logo']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception("File upload failed");
    }

    $file = $_FILES['logo'];
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!in_array($file['type'], $allowedTypes)) {
        throw new Exception("Invalid file type. Only JPG, PNG, GIF, WEBP allowed.");
    }

    $uploadDir = __DIR__ . '/../../uploads/customers/' . $customerId . '/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'logo_' . time() . '.' . $ext;
    $destPath = $uploadDir . $filename;

    if (move_uploaded_file($file['tmp_name'], $destPath)) {
        // Update DB
        // Use relative path for URL
        $dbPath = 'uploads/customers/' . $customerId . '/' . $filename;
        $stmt = $db->prepare("UPDATE dd_customers SET logo_url = ? WHERE id = ?");
        $stmt->execute([$dbPath, $customerId]);

        return ['message' => 'Logo uploaded successfully', 'url' => $dbPath];
    } else {
        throw new Exception("Failed to move uploaded file");
    }
}


function get_customer_categories($db)
{
    $q = $_GET['q'] ?? '';

    if (!empty($q)) {
        $stmt = $db->prepare("SELECT * FROM dd_customer_categories WHERE is_active = 1 AND name LIKE ? ORDER BY sort_order ASC");
        $stmt->execute(["%$q%"]);
    } else {
        $stmt = $db->query("SELECT * FROM dd_customer_categories WHERE is_active = 1 ORDER BY sort_order ASC");
    }

    return $stmt->fetchAll();
}

function search_customers($db)
{
    $q = $_GET['search'] ?? $_GET['q'] ?? '';
    if (strlen($q) < 1)
        return [];

    // Simple robust search including category
    $term = "%$q%";
    $stmt = $db->prepare("
        SELECT c.id, c.name, c.email, c.title, cat.name as category_name 
        FROM dd_customers c 
        LEFT JOIN dd_customer_categories cat ON c.category_id = cat.id 
        WHERE c.name LIKE ? OR c.email LIKE ? OR cat.name LIKE ? 
        LIMIT 20
    ");
    $stmt->execute([$term, $term, $term]);
    return $stmt->fetchAll();
}

function list_customers($db)
{
    $page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int) $_GET['limit'] : 20;
    $sort = isset($_GET['sort']) ? $_GET['sort'] : 'created_at';
    $order = isset($_GET['order']) && strtoupper($_GET['order']) === 'ASC' ? 'ASC' : 'DESC';
    $search = isset($_GET['search']) ? $_GET['search'] : '';

    $offset = ($page - 1) * $limit;

    // Allowed sort columns safely
    $allowedSorts = ['id', 'name', 'email', 'created_at', 'category_name'];
    if (!in_array($sort, $allowedSorts)) {
        $sort = 'created_at';
    }
    // Handle category_name sort via alias in main query
    $orderBy = ($sort === 'category_name') ? 'cat.name' : "c.$sort";

    $whereClause = "WHERE 1=1";
    $params = [];

    if (!empty($search)) {
        $whereClause .= " AND (c.name LIKE ? OR c.email LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }

    // Count Total (using view)
    $countStmt = $db->prepare("SELECT COUNT(*) FROM v_dd_customers c $whereClause");
    $countStmt->execute($params);
    $total = $countStmt->fetchColumn();

    // Fetch Data
    $query = "
        SELECT c.*, cat.name as category_name, cat.color as category_color 
        FROM v_dd_customers c 
        LEFT JOIN dd_customer_categories cat ON c.category_id = cat.id 
        $whereClause 
        ORDER BY $orderBy $order 
        LIMIT $limit OFFSET $offset
    ";

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $data = $stmt->fetchAll();

    return [
        'data' => $data,
        'pagination' => [
            'total' => (int) $total,
            'page' => $page,
            'limit' => $limit,
            'last_page' => ceil($total / $limit)
        ]
    ];
}

function create_customer($db)
{
    // Permission check removed.

    $rawInput = file_get_contents('php://input');
    Logger::error("Debug Create Customer Input: " . $rawInput);
    $data = json_decode($rawInput, true);
    $name = $data['name'] ?? '';
    $email = $data['email'] ?? '';
    $phone = $data['phone'] ?? null;
    $address = $data['address'] ?? null;
    $cvr = $data['cvr'] ?? null;
    $category_id = !empty($data['category_id']) ? $data['category_id'] : null;
    $codename = $data['codename'] ?? null;
    // Fix: Convert empty string to null/0 for decimal/int columns to avoid strict SQL errors
    $capex_threshold = isset($data['capex_threshold']) && $data['capex_threshold'] !== '' ? $data['capex_threshold'] : 0;
    $asset_number_prefix = $data['asset_number_prefix'] ?? null;
    $nda_signed = $data['nda_signed'] ?? 0;
    $notes = $data['notes'] ?? null;

    $title = $data['title'] ?? null;

    if (empty($name)) {
        throw new Exception("Name is required");
    }

    $stmt = $db->prepare("INSERT INTO dd_customers (name, title, email, phone, address, cvr, category_id, codename, capex_threshold, asset_number_prefix, nda_signed, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$name, $title, $email, $phone, $address, $cvr, $category_id, $codename, $capex_threshold, $asset_number_prefix, $nda_signed, $notes]);

    return ['id' => $db->lastInsertId(), 'message' => 'Customer created successfully'];
}

function get_condition_distribution($db)
{
    $type = $_GET['bind_type'] ?? '';
    $id = (int) ($_GET['bind_id'] ?? 0);

    $query = "SELECT condition_rating, COUNT(*) as count FROM dd_building_Elements WHERE ";
    if ($type === 'projects') {
        $query .= "building_id IN (SELECT id FROM dd_buildings WHERE project_id = ?) ";
    } else if ($type === 'buildings') {
        $query .= "building_id = ? ";
    } else {
        throw new Exception("Invalid type for distribution");
    }

    $query .= "GROUP BY condition_rating";
    $stmt = $db->prepare($query);
    $stmt->execute([$id]);

    $rowCounts = $stmt->fetchAll();
    $dist = ["1" => 0, "2" => 0, "3" => 0, "4" => 0, "5" => 0];
    foreach ($rowCounts as $row) {
        if ($row['condition_rating'])
            $dist[$row['condition_rating']] = (int) $row['count'];
    }
    return $dist;
}

function update_customer($db)
{
    // Permission check removed.

    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['id'] ?? null;
    $name = $data['name'] ?? '';
    $title = $data['title'] ?? null;
    $email = $data['email'] ?? '';
    $phone = $data['phone'] ?? null;
    $address = $data['address'] ?? null;
    $cvr = $data['cvr'] ?? null;
    $category_id = !empty($data['category_id']) ? $data['category_id'] : null;
    $codename = $data['codename'] ?? null;
    // Fix: Convert empty string to null/0 for numeric columns
    $capex_threshold = isset($data['capex_threshold']) && $data['capex_threshold'] !== '' ? $data['capex_threshold'] : 0;
    $asset_number_prefix = $data['asset_number_prefix'] ?? null;
    $nda_signed = $data['nda_signed'] ?? 0;
    $notes = $data['notes'] ?? null;

    if (!$id || empty($name)) {
        throw new Exception("ID and name are required");
    }

    $stmt = $db->prepare("UPDATE dd_customers SET name = ?, title = ?, email = ?, phone = ?, address = ?, cvr = ?, category_id = ?, codename = ?, capex_threshold = ?, asset_number_prefix = ?, nda_signed = ?, notes = ? WHERE id = ?");
    $stmt->execute([
        $name,
        $title,
        $email,
        $phone,
        $address,
        $cvr,
        $category_id,
        $codename,
        $capex_threshold,
        $asset_number_prefix,
        $nda_signed,
        $notes,
        $id
    ]);

    return ['message' => 'Customer updated successfully'];
}

function get_customer($db)
{
    // Permission check removed.
    $id = $_GET['id'] ?? null;
    if (!$id) {
        throw new Exception("ID required");
    }
    $stmt = $db->prepare("
        SELECT c.*, cat.name as category_name 
        FROM dd_customers c 
        LEFT JOIN dd_customer_categories cat ON c.category_id = cat.id 
        WHERE c.id = ?
    ");
    $stmt->execute([$id]);
    $res = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$res) {
        throw new Exception("Customer not found");
    }
    return $res;
}

function delete_customer($db)
{
    // Permission check removed.

    $id = $_GET['id'] ?? null;

    if (!$id) {
        throw new Exception("ID is required");
    }

    $stmt = $db->prepare("CALL sp_SoftDelete('customer', ?)");
    $stmt->execute([$id]);

    return ['message' => 'Customer soft-deleted successfully'];
}

function list_projects($db)
{
    $customerId = $_GET['customer_id'] ?? null;
    if (!$customerId)
        throw new Exception("Customer ID required");
    $stmt = $db->prepare("SELECT * FROM v_dd_projects WHERE customer_id = ?");
    $stmt->execute([$customerId]);
    return $stmt->fetchAll();
}

// ...
function search_projects($db)
{
    $q = $_GET['search'] ?? $_GET['q'] ?? '';
    if (strlen($q) < 1)
        return [];

    $term = "%$q%";
    $stmt = $db->prepare("SELECT id, name, customer_id FROM v_dd_projects WHERE name LIKE ? LIMIT 20");
    $stmt->execute([$term]);
    return $stmt->fetchAll();
}

function list_buildings($db)
{
    $projectId = $_GET['project_id'] ?? null;
    $q = $_GET['search'] ?? $_GET['q'] ?? '';

    if (!$projectId) {
        if (!empty($q)) {
            // Allow global search if project_id is missing but q is present 
            // (though usually we want context, let's support it)
            $term = "%$q%";
            $stmt = $db->prepare("SELECT * FROM dd_buildings WHERE name LIKE ? LIMIT 20");
            $stmt->execute([$term]);
            return $stmt->fetchAll();
        }
        throw new Exception("Project ID required");
    }

    $query = "SELECT * FROM dd_buildings WHERE project_id = ?";
    $params = [$projectId];

    if (!empty($q)) {
        $query .= " AND name LIKE ?";
        $params[] = "%$q%";
    }

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function list_elements($db)
{
    $buildingId = $_GET['building_id'] ?? null;
    $q = $_GET['q'] ?? '';

    if (!$buildingId) {
        if (!empty($q)) {
            $term = "%$q%";
            $stmt = $db->prepare("SELECT * FROM dd_building_Elements WHERE name LIKE ? LIMIT 20");
            $stmt->execute([$term]);
            return $stmt->fetchAll();
        }
        throw new Exception("Building ID required");
    }

    $query = "SELECT * FROM dd_building_Elements WHERE building_id = ?";
    $params = [$buildingId];

    if (!empty($q)) {
        $query .= " AND name LIKE ?";
        $params[] = "%$q%";
    }

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function list_tasks($db)
{
    $projectId = $_GET['project_id'] ?? null;
    $buildingId = $_GET['building_id'] ?? null;
    $elementId = $_GET['element_id'] ?? null;

    $query = "SELECT * FROM dd_tasks WHERE 1=1";
    $params = [];

    if ($projectId) {
        $query .= " AND project_id = ?";
        $params[] = $projectId;
    }
    if ($buildingId) {
        $query .= " AND building_id = ?";
        $params[] = $buildingId;
    }
    if ($elementId) {
        $query .= " AND element_id = ?";
        $params[] = $elementId;
    }

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function get_capex_summary($db)
{
    $projectId = (int) ($_GET['project_id'] ?? 0);
    if (!$projectId)
        throw new Exception("Project ID required");
    $stmt = $db->prepare("SELECT * FROM view_ProjectCapexSummary WHERE project_id = ?");
    $stmt->execute([$projectId]);
    return $stmt->fetchAll();
}

function get_project($db)
{
    $id = $_GET['id'] ?? null;
    if (!$id)
        throw new Exception("Project ID required");

    $stmt = $db->prepare("SELECT p.*, c.name as customer_name FROM dd_projects p JOIN dd_customers c ON p.customer_id = c.id WHERE p.id = ?");
    $stmt->execute([$id]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$project)
        throw new Exception("Project not found");
    return $project;
}

function list_all_projects($db)
{
    $stmt = $db->query("
        SELECT p.*, c.name as customer_name 
        FROM v_dd_projects p 
        JOIN v_dd_customers c ON p.customer_id = c.id 
        ORDER BY p.created_at DESC
    ");
    return $stmt->fetchAll();
}

function create_project($db)
{
    // Permission check removed.

    $data = json_decode(file_get_contents('php://input'), true);
    $customer_id = $data['customer_id'] ?? null;
    $name = $data['name'] ?? '';
    $description = $data['description'] ?? '';
    $start_date = !empty($data['start_date']) ? $data['start_date'] : null;
    $status = $data['status'] ?? 'open';
    $nda_required = $data['nda_required'] ?? 0;
    $project_manager_id = !empty($data['project_manager_id']) ? $data['project_manager_id'] : null;
    $qa_id = !empty($data['qa_id']) ? $data['qa_id'] : null;

    if (empty($customer_id) || empty($name)) {
        throw new Exception("Customer ID and Name are required");
    }

    $stmt = $db->prepare("INSERT INTO dd_projects (customer_id, name, description, created_by, start_date, status, nda_required, project_manager_id, qa_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $customer_id,
        $name,
        $description,
        $_SESSION['user_id'] ?? null,
        $start_date,
        $status === 'active' ? 'open' : $status, // Map 'active' to 'open' DB enum if needed, or just store string if enum allows
        $nda_required,
        $project_manager_id,
        $qa_id
    ]);

    $project_id = $db->lastInsertId();

    // Insert default building for the new project
    $stmt_building = $db->prepare("INSERT INTO dd_buildings (project_id, name, description, created_by) VALUES (?, ?, ?, ?)");
    $stmt_building->execute([$project_id, 'Default Building', 'Automatically created default building', $_SESSION['user_id'] ?? null]);

    // Insert default element for the new building
    $building_id = $db->lastInsertId();
    $stmt_element = $db->prepare("INSERT INTO dd_building_Elements (project_id, building_id, name, description, condition_rating) VALUES (?, ?, ?, ?, ?)");
    $stmt_element->execute([$project_id, $building_id, 'Default Element', 'Automatically created default element', 3]);

    // Handle file uploads (attachments) if any
    if (!empty($_FILES['attachments'])) {
        $uploadDir = __DIR__ . "/../../uploads/projects/{$project_id}/images/";
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        foreach ($_FILES['attachments']['tmp_name'] as $idx => $tmpPath) {
            $originalName = basename($_FILES['attachments']['name'][$idx]);
            $destPath = $uploadDir . $originalName;
            move_uploaded_file($tmpPath, $destPath);
        }
    }
    // Handle snapshot JSON if provided in request body (as 'snapshot')
    $rawInput = file_get_contents('php://input');
    $dataAll = json_decode($rawInput, true);
    if (!empty($dataAll['snapshot'])) {
        $snapshotDir = __DIR__ . "/../../uploads/projects/{$project_id}";
        if (!is_dir($snapshotDir)) {
            mkdir($snapshotDir, 0755, true);
        }
        file_put_contents($snapshotDir . '/snapshot.json', json_encode($dataAll['snapshot']));
    }

    return ['id' => $project_id, 'message' => 'Project created successfully with default building, element, and attachments'];
}

function update_project($db)
{
    // Permission check removed.

    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['id'] ?? null;
    $name = $data['name'] ?? '';
    $description = $data['description'] ?? '';
    $status = $data['status'] ?? 'open';
    // Map status if needed, but keeping it simple for now as frontend sends valid enums usually
    if ($status === 'active')
        $status = 'open';

    $start_date = !empty($data['start_date']) ? $data['start_date'] : null;
    $nda_required = $data['nda_required'] ?? 0;
    $project_manager_id = !empty($data['project_manager_id']) ? $data['project_manager_id'] : null;
    $qa_id = !empty($data['qa_id']) ? $data['qa_id'] : null;

    if (!$id || empty($name)) {
        throw new Exception("ID and name are required");
    }

    $stmt = $db->prepare("UPDATE dd_projects SET name = ?, description = ?, status = ?, start_date = ?, nda_required = ?, project_manager_id = ?, qa_id = ? WHERE id = ?");
    $stmt->execute([
        $name,
        $description,
        $status,
        $start_date,
        $nda_required,
        $project_manager_id,
        $qa_id,
        $id
    ]);

    return ['message' => 'Project updated successfully'];
}

function delete_project($db)
{
    // Permission check removed.

    $id = $_GET['id'] ?? null;

    if (!$id) {
        throw new Exception("ID is required");
    }

    $stmt = $db->prepare("CALL sp_SoftDelete('project', ?)");
    $stmt->execute([$id]);

    return ['message' => 'Project soft-deleted successfully'];
}