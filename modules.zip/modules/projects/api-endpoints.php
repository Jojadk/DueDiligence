<?php
// modules/projects/api-endpoints.php - Optimized

/**
 * Main API handler with better error handling
 */
function handle_api($action, $db)
{
    try {
        switch ($action) {
            case 'list':
            case 'list_projects':
            case 'get':
            case 'get_condition_distribution':
            case 'get_dashboard_stats':
                require_permission('allow_view_all');
                break;
            case 'create':
            case 'update':
            case 'delete':
                require_permission('allow_manage_projects');
                break;
        }

        switch ($action) {
            case 'list':
            case 'list_projects':
                return list_projects_paged($db);
            case 'get':
                return get_project($db);
            case 'create':
                return create_project_module($db);
            case 'update':
                return update_project_module($db);
            case 'delete':
                return delete_project_module($db);
            case 'get_condition_distribution':
                return get_condition_distribution($db);
            case 'get_dashboard_stats':
            case 'get_project_stats':
                return get_project_stats($db);
            default:
                throw new Exception("Unknown projects action: " . htmlspecialchars($action));
        }
    } catch (Exception $e) {
        error_log("Projects API Error [{$action}]: " . $e->getMessage());
        throw $e;
    }
}

/**
 * List projects with pagination - OPTIMIZED
 */
function list_projects_paged($db)
{
    // Input validation
    $page = max(1, (int) ($_GET['page'] ?? 1));
    $limit = min(100, max(1, (int) ($_GET['limit'] ?? 20)));
    $sort = $_GET['sort'] ?? 'created_at';
    $order = (isset($_GET['order']) && strtoupper($_GET['order']) === 'ASC') ? 'ASC' : 'DESC';
    $search = trim($_GET['search'] ?? '');

    $offset = ($page - 1) * $limit;

    // Whitelist for sort columns
    $allowedSorts = [
        'id' => 'p.id',
        'name' => 'p.name',
        'status' => 'p.status',
        'start_date' => 'p.start_date',
        'created_at' => 'p.created_at',
        'customer_name' => 'c.name'
    ];

    $orderBy = $allowedSorts[$sort] ?? 'p.created_at';

    // Build WHERE clause
    $whereConditions = ['1=1'];
    $params = [];

    if (!empty($search)) {
        $whereConditions[] = "(p.name LIKE ? OR c.name LIKE ?)";
        $searchParam = "%{$search}%";
        $params[] = $searchParam;
        $params[] = $searchParam;
    }

    if (!empty($_GET['customer_id'])) {
        $whereConditions[] = "p.customer_id = ?";
        $params[] = (int) $_GET['customer_id'];
    }

    if (!empty($_GET['status'])) {
        $whereConditions[] = "p.status = ?";
        $params[] = $_GET['status'];
    }

    $whereClause = 'WHERE ' . implode(' AND ', $whereConditions);

    // Count total (using view)
    $countStmt = $db->prepare("
        SELECT COUNT(*) 
        FROM v_dd_projects p 
        LEFT JOIN v_dd_customers c ON p.customer_id = c.id 
        {$whereClause}
    ");
    $countStmt->execute($params);
    $total = (int) $countStmt->fetchColumn();

    // Fetch data with proper indexing
    $query = "
        SELECT 
            p.id,
            p.customer_id,
            p.name,
            p.description,
            p.status,
            p.start_date,
            p.created_at,
            p.nda_required,
            c.name as customer_name
        FROM v_dd_projects p 
        LEFT JOIN v_dd_customers c ON p.customer_id = c.id 
        {$whereClause} 
        ORDER BY {$orderBy} {$order} 
        LIMIT {$limit} OFFSET {$offset}
    ";

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return [
        'data' => $data,
        'pagination' => [
            'total' => $total,
            'page' => $page,
            'limit' => $limit,
            'last_page' => ceil($total / $limit)
        ]
    ];
}

// Metadata functions moved to core.php

/**
 * Get single project - OPTIMIZED
 */
function get_project($db)
{
    $id = (int) ($_GET['id'] ?? 0);
    if (!$id) {
        throw new Exception("Project ID required");
    }

    // Main project query
    $stmt = $db->prepare("
        SELECT 
            p.*,
            c.name as customer_name,
            pm.name as project_manager_name,
            qa.name as qa_name
        FROM v_dd_projects p 
        LEFT JOIN v_dd_customers c ON p.customer_id = c.id 
        LEFT JOIN dd_users pm ON p.project_manager_id = pm.id
        LEFT JOIN dd_users qa ON p.qa_id = qa.id
        WHERE p.id = ?
    ");
    $stmt->execute([$id]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$project) {
        throw new Exception("Project not found");
    }

    // Fetch custom fields
    $stmtFields = $db->prepare("
        SELECT * 
        FROM dd_project_custom_fields 
        WHERE project_id = ? 
        ORDER BY sort_order ASC, id ASC
    ");
    $stmtFields->execute([$id]);
    $project['custom_fields'] = $stmtFields->fetchAll(PDO::FETCH_ASSOC);

    // Fetch metadata
    $meta = get_project_meta($db, $id);

    // Merge standard meta keys with defaults
    $standardMeta = [
        'report_config' => [],
        'constants' => [],
        'capex_opex' => [],
        'dashboard_config' => []
    ];

    foreach ($standardMeta as $key => $default) {
        $project[$key] = $meta[$key] ?? $default;
    }

    return $project;
}

/**
 * Create project - TRANSACTIONAL
 */
function create_project_module($db)
{
    require_permission('allow_manage_projects');

    $data = json_decode(file_get_contents('php://input'), true);

    // Validation
    if (empty($data['name'])) {
        throw new Exception("Project name is required");
    }
    if (empty($data['customer_id'])) {
        throw new Exception("Customer ID is required");
    }

    // Begin transaction
    $db->beginTransaction();

    try {
        // Insert main project
        $stmt = $db->prepare("
            INSERT INTO dd_projects (
                customer_id, 
                name, 
                description, 
                status, 
                start_date, 
                end_date,
                created_by, 
                nda_required, 
                project_manager_id, 
                qa_id,
                rounding_level
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $pmId = !empty($data['project_manager_id']) ? (int) $data['project_manager_id'] : null;
        $qaId = !empty($data['qa_id']) ? (int) $data['qa_id'] : null;
        $roundingLevel = isset($data['rounding_level']) && $data['rounding_level'] !== '' ? (float) $data['rounding_level'] : 0;

        $stmt->execute([
            $data['customer_id'],
            $data['name'],
            $data['description'] ?? '',
            $data['status'] ?? 'open',
            $data['start_date'] ?? null,
            $data['end_date'] ?? null,
            $_SESSION['user_id'] ?? 0,
            (int) ($data['nda_required'] ?? 0),
            $pmId,
            $qaId,
            $roundingLevel
        ]);

        $projectId = (int) $db->lastInsertId();

        // Save metadata
        $metaKeys = ['report_config', 'constants', 'capex_opex', 'dashboard_config'];
        foreach ($metaKeys as $key) {
            if (isset($data[$key])) {
                save_project_meta($db, $projectId, $key, $data[$key]);
            }
        }

        // Save custom fields
        if (!empty($data['custom_fields']) && is_array($data['custom_fields'])) {
            $stmtField = $db->prepare("
                INSERT INTO dd_project_custom_fields 
                (project_id, label, type, options, sort_order) 
                VALUES (?, ?, ?, ?, ?)
            ");

            foreach ($data['custom_fields'] as $i => $field) {
                if (empty($field['label']))
                    continue;

                $stmtField->execute([
                    $projectId,
                    $field['label'],
                    $field['type'] ?? 'text',
                    $field['options'] ?? null,
                    $i
                ]);
            }
        }

        $db->commit();

        return [
            'id' => $projectId,
            'message' => 'Project created successfully'
        ];

    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

/**
 * Update project - TRANSACTIONAL
 */
function update_project_module($db)
{
    require_permission('allow_manage_projects');

    $data = json_decode(file_get_contents('php://input'), true);
    $id = (int) ($data['id'] ?? 0);

    if (!$id) {
        throw new Exception("Project ID required");
    }

    // Begin transaction
    $db->beginTransaction();

    try {
        // Update main project
        $stmt = $db->prepare("
            UPDATE dd_projects SET 
                name = ?, 
                description = ?, 
                status = ?, 
                start_date = ?,
                end_date = ?,
                nda_required = ?, 
                project_manager_id = ?, 
                qa_id = ?,
                rounding_level = ?
            WHERE id = ?
        ");

        $pmId = (isset($data['project_manager_id']) && $data['project_manager_id'] !== '') ? (int) $data['project_manager_id'] : null;
        $qaId = (isset($data['qa_id']) && $data['qa_id'] !== '') ? (int) $data['qa_id'] : null;
        $roundingLevel = (isset($data['rounding_level']) && $data['rounding_level'] !== '') ? (float) $data['rounding_level'] : 0;

        $stmt->execute([
            $data['name'],
            $data['description'] ?? '',
            $data['status'] ?? 'open',
            $data['start_date'] ?? null,
            $data['end_date'] ?? null,
            (int) ($data['nda_required'] ?? 0),
            $pmId,
            $qaId,
            $roundingLevel,
            $id
        ]);

        // Update metadata
        $metaKeys = ['report_config', 'constants', 'capex_opex', 'dashboard_config'];
        foreach ($metaKeys as $key) {
            if (isset($data[$key])) {
                save_project_meta($db, $id, $key, $data[$key]);
            }
        }

        // Sync custom fields (delete + recreate)
        $db->prepare("DELETE FROM dd_project_custom_fields WHERE project_id = ?")->execute([$id]);

        if (!empty($data['custom_fields']) && is_array($data['custom_fields'])) {
            $stmtField = $db->prepare("
                INSERT INTO dd_project_custom_fields 
                (project_id, label, type, options, sort_order) 
                VALUES (?, ?, ?, ?, ?)
            ");

            foreach ($data['custom_fields'] as $i => $field) {
                if (empty($field['label']))
                    continue;

                $stmtField->execute([
                    $id,
                    $field['label'],
                    $field['type'] ?? 'text',
                    $field['options'] ?? null,
                    $i
                ]);
            }
        }

        $db->commit();

        return ['message' => 'Project updated successfully'];

    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

/**
 * Delete project
 */
function delete_project_module($db)
{
    require_permission('allow_manage_projects');

    $id = (int) ($_GET['id'] ?? 0);
    if (!$id) {
        throw new Exception("Project ID required");
    }

    $stmt = $db->prepare("CALL sp_SoftDelete('project', ?)");
    $stmt->execute([$id]);

    return ['message' => 'Project and all associated data soft-deleted successfully'];
}

/**
 * Get project statistics - OPTIMIZED
 */
function get_project_stats($db)
{
    $id = (int) ($_GET['id'] ?? 0);
    if (!$id) {
        return ['buildings' => 0, 'elements' => 0, 'progress' => 0, 'total_capex' => 0];
    }

    // Use centralized batch fetching to ensure correct rounding (roundup)
    $buildings = get_project_data_batch($db, $id);

    $totalElements = 0;
    $completedElements = 0;
    $totalCapex = 0;
    $buildingCount = count($buildings);

    foreach ($buildings as $b) {
        // Recursive helper to count elements and sum CAPEX
        $processTree = function ($elements) use (&$processTree, &$totalElements, &$completedElements, &$totalCapex) {
            foreach ($elements as $el) {
                $totalElements++;
                if (isset($el['condition_rating']) && (int) $el['condition_rating'] > 0) {
                    $completedElements++;
                }
                $totalCapex += (float) ($el['total_budget'] ?? 0);

                if (!empty($el['children'])) {
                    $processTree($el['children']);
                }
            }
        };

        if (!empty($b['tree'])) {
            $processTree($b['tree']);
        }
    }

    $progress = $totalElements > 0
        ? round(($completedElements / $totalElements) * 100)
        : 0;

    return [
        'buildings' => $buildingCount,
        'elements' => $totalElements,
        'progress' => (int) $progress,
        'total_capex' => $totalCapex,
        'formatted_capex' => number_format($totalCapex, 2, ',', '.') . ' DKK'
    ];
}

/**
 * Get condition rating distribution - OPTIMIZED
 */
function get_condition_distribution($db)
{
    $projectId = (int) ($_GET['bind_id'] ?? $_GET['id'] ?? 0);

    if (!$projectId) {
        return ["1" => 0, "2" => 0, "3" => 0, "4" => 0, "5" => 0];
    }

    $stmt = $db->prepare("
        SELECT 
            e.condition_rating, 
            COUNT(*) as count 
        FROM v_dd_building_elements e 
        INNER JOIN v_dd_buildings b ON e.building_id = b.id 
        WHERE b.project_id = ? 
            AND e.condition_rating IS NOT NULL
        GROUP BY e.condition_rating
    ");

    $stmt->execute([$projectId]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $distribution = ["1" => 0, "2" => 0, "3" => 0, "4" => 0, "5" => 0];

    foreach ($rows as $row) {
        $rating = (string) $row['condition_rating'];
        if (isset($distribution[$rating])) {
            $distribution[$rating] = (int) $row['count'];
        }
    }

    return $distribution;
}
