<?php
// Report/views/excel_report.php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Helper translation
$translations = [
    'std.1' => 'Udendørsarealer',
    'std.1.1' => 'Belægninger',
    'std.1.2' => 'Grønne områder',
    'std.1.3' => 'Hegn, porte og støttemure',
    'std.1.4' => 'Udvendig belysning',
    'std.1.5' => 'Afvanding af terræn',
    'std.1.6' => 'Skilte og inventar',
    'std.2' => 'Bygningsskal',
    'std.2.1' => 'Fundamenter og terrændæk',
    'std.2.2' => 'Facader',
    'std.2.3' => 'Vinduer og yderdøre',
    'std.2.4' => 'Tage',
    'std.2.5' => 'Altaner og udvendige trapper',
    'std.2.6' => 'Porte og ramper',
    'std.3' => 'Indvendige bygningsdele',
    'std.3.1' => 'Indvendige vægge',
    'std.3.2' => 'Indvendige døre',
    'std.3.3' => 'Gulve',
    'std.3.4' => 'Lofter',
    'std.3.5' => 'Indvendige trapper',
    'std.3.6' => 'Inventar',
    'std.4' => 'Tekniske installationer',
    'std.4.1' => 'Vand',
    'std.4.2' => 'Afløb',
    'std.4.3' => 'Varme',
    'std.4.4' => 'Køling',
    'std.4.5' => 'Ventilation',
    'std.4.6' => 'El-grundinstallationer',
    'std.4.7' => 'Belysning',
    'std.4.8' => 'Elevatorer',
    'std.4.9' => 'Brandsikring',
    'std.4.10' => 'CTS'
];

if (!function_exists('t')) {
    function t($key, $map)
    {
        return $map[$key] ?? $key;
    }
}

// Logic to distribute CAPEX removed (handled in get_project_data_batch)
?>
<!DOCTYPE html>
<html lang="da">
<head>
    <meta charset="UTF-8">
    <title>Light Report - <?= htmlspecialchars($project['name']) ?></title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 10pt; color: #333; margin: 0; background: #eee; padding: 20px; }
        .page { background: white; margin: 0 auto 30px auto; padding: 15mm; width: 297mm; min-height: 210mm; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); }
        .landscape { width: 297mm; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 9pt; }
        th, td { border: 1px solid #ccc; padding: 6px 8px; vertical-align: top; }
        th { background: #e0e0e0; font-weight: 600; text-align: center; }
        .header-title { font-size: 16pt; font-weight: bold; margin-bottom: 20px; border-bottom: 2px solid #333; padding-bottom: 10px; }
        .group-row { background: #f0f0f0; font-weight: bold; }
        .num-cell { text-align: right; white-space: nowrap; }
        @media print {
            body { background: white; padding: 0; }
            .page { margin: 0; box-shadow: none; page-break-after: always; width: 100%; height: auto; }
            .no-print { display: none; }
        }
        .detail-img { width: 120px; height: 90px; object-fit: cover; border: 1px solid #ddd; background: #f9f9f9; display: block; margin-bottom: 5px; }
    </style>
</head>
<body>
    <div class="no-print" style="position:fixed; top:10px; right:10px; background:white; padding:10px; border:1px solid #ccc; z-index:999;">
        <button onclick="window.print()">Print / PDF</button>
    </div>

<?php foreach ($buildings as $building): 
    $tree = $building['tree'];
    
    // Check if tree is empty
    if (empty($tree)) continue;

    // Prepare Summary Data for this building
    $summaryData = [];
    $totalBuckets = ['<1' => 0, '1-2' => 0, '3-5' => 0, '6-10' => 0, 'total' => 0];

    foreach ($tree as $group) {
        $groupRow = [
            'name' => t($group['name'], $translations),
            'buckets' => ['<1' => 0, '1-2' => 0, '3-5' => 0, '6-10' => 0],
            'children' => []
        ];

        foreach ($group['children'] as $child) {
            $buckets = [
                '<1' => $child['cost_buckets']['0_1'] ?? 0,
                '1-2' => $child['cost_buckets']['1_2'] ?? 0,
                '3-5' => $child['cost_buckets']['3_5'] ?? 0,
                '6-10' => $child['cost_buckets']['5_10'] ?? 0
            ];

            $childRow = [
                'name' => t($child['name'], $translations),
                'buckets' => $buckets
            ];

            foreach ($buckets as $k => $v) {
                $groupRow['buckets'][$k] += $v;
                // Add to BUILDING total
                $totalBuckets[$k] += $v;
                $totalBuckets['total'] += $v;
            }
            $groupRow['children'][] = $childRow;
        }
        $summaryData[] = $groupRow;
    }
?>

    <!-- PAGE 1: SUMMARY (Per Building) -->
    <div class="page landscape">
        <div class="header-title">3. Building elements across the portfolio - <?= htmlspecialchars($building['name']) ?></div>
        <div style="margin-bottom: 10px; font-size: 0.9em;">All rates are trade prices excluding VAT in DKK.</div>

        <table>
            <thead>
                <tr style="background:#ddd;">
                    <th rowspan="2" style="text-align:left; width:25%;">Building parts</th>
                    <th colspan="4" style="background:#e0e0e0; border-bottom:1px solid #999;">Expected timeframe for execution</th>
                    <th colspan="5" style="background:#d0d0d0; border-bottom:1px solid #999;">Estimates*</th>
                </tr>
                <tr style="font-size:8pt;">
                    <th style="width:10%;">&lt; 1 year</th>
                    <th style="width:10%;">1-2 years</th>
                    <th style="width:10%;">3-5 years</th>
                    <th style="width:10%;">6-10 years</th>
                    <th style="width:10%; background:#f0f0f0;">Contractor</th>
                    <th style="width:5%;">Unforeseen / risks (0%)</th>
                    <th style="width:5%;">Support (0%)</th>
                    <th style="width:5%;">Mgmt (0%)</th>
                    <th style="width:5%;">Consultancy (0%)</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $grandTotalContractor = 0;
                $idx = 1;
                foreach ($summaryData as $grp):
                    $grpContractor = array_sum($grp['buckets']);
                    $grandTotalContractor += $grpContractor;
                    ?>
                    <tr class="group-row">
                        <td style="text-align:left;"><?= $idx ?> - <?= htmlspecialchars($grp['name']) ?></td>
                        <td class="num-cell"><?= number_format($grp['buckets']['<1'], 0, ',', '.') ?> kr.</td>
                        <td class="num-cell"><?= number_format($grp['buckets']['1-2'], 0, ',', '.') ?> kr.</td>
                        <td class="num-cell"><?= number_format($grp['buckets']['3-5'], 0, ',', '.') ?> kr.</td>
                        <td class="num-cell"><?= number_format($grp['buckets']['6-10'], 0, ',', '.') ?> kr.</td>
                        <td class="num-cell" style="background:#fafafa;"><?= number_format($grpContractor, 0, ',', '.') ?> kr.</td>
                        <td class="num-cell">-</td>
                        <td class="num-cell">-</td>
                        <td class="num-cell">-</td>
                        <td class="num-cell">-</td>
                    </tr>
                    <?php $subIdx = 1;
                    foreach ($grp['children'] as $child):
                        $childContractor = array_sum($child['buckets']);
                        ?>
                        <tr>
                            <td style="padding-left: 20px;"><?= $idx ?>.<?= $subIdx ?> <?= htmlspecialchars($child['name']) ?></td>
                            <td class="num-cell"><?= $child['buckets']['<1'] > 0 ? number_format($child['buckets']['<1'], 0, ',', '.') . ' kr.' : '-' ?></td>
                            <td class="num-cell"><?= $child['buckets']['1-2'] > 0 ? number_format($child['buckets']['1-2'], 0, ',', '.') . ' kr.' : '-' ?></td>
                            <td class="num-cell"><?= $child['buckets']['3-5'] > 0 ? number_format($child['buckets']['3-5'], 0, ',', '.') . ' kr.' : '-' ?></td>
                            <td class="num-cell"><?= $child['buckets']['6-10'] > 0 ? number_format($child['buckets']['6-10'], 0, ',', '.') . ' kr.' : '-' ?></td>
                            <td class="num-cell" style="background:#fafafa;"><?= $childContractor > 0 ? number_format($childContractor, 0, ',', '.') . ' kr.' : '-' ?></td>
                            <td class="num-cell">0%</td>
                            <td class="num-cell">0%</td>
                            <td class="num-cell">0%</td>
                            <td class="num-cell">0%</td>
                        </tr>
                        <?php $subIdx++; endforeach; ?>
                    <?php $idx++; endforeach; ?>
                <tr style="background:#333; color:white; font-weight:bold; border-top:2px solid black;">
                    <td>TOTAL</td>
                    <td class="num-cell"><?= number_format($totalBuckets['<1'], 0, ',', '.') ?> kr.</td>
                    <td class="num-cell"><?= number_format($totalBuckets['1-2'], 0, ',', '.') ?> kr.</td>
                    <td class="num-cell"><?= number_format($totalBuckets['3-5'], 0, ',', '.') ?> kr.</td>
                    <td class="num-cell"><?= number_format($totalBuckets['6-10'], 0, ',', '.') ?> kr.</td>
                    <td class="num-cell"><?= number_format($grandTotalContractor, 0, ',', '.') ?> kr.</td>
                    <td class="num-cell" colspan="4"></td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- PAGE 2+: DETAILS (Per Building) -->
    <div class="page landscape">
        <div class="header-title">Detailed Building Elements - <?= htmlspecialchars($building['name']) ?></div>
        <table>
            <thead>
                <tr style="background:#e0e0e0;">
                    <th rowspan="2" style="width: 15%;">Category</th>
                    <th rowspan="2" style="width: 25%;">Description of error, deficiency, or damage</th>
                    <th rowspan="2" style="width: 15%;">Attachment</th>
                    <th rowspan="2" style="width: 18%;">Remarks / Recommendation</th>
                    <th rowspan="2" style="width: 5%;">Tilst.</th>
                    <th rowspan="2" style="width: 5%;">Kval.</th>
                    <th rowspan="2" style="width: 8%;">Quantification</th>
                    <th colspan="5" style="width: 10%;">Risk assessment</th>
                    <th colspan="4" style="width: 10%;">Expected timeframe</th>
                </tr>
                <tr style="font-size:7pt;">
                    <th title="Red">🔴</th>
                    <th title="Yellow">🟡</th>
                    <th title="Black/Green">⚫️</th>
                    <th title="Green">🟢</th>
                    <th title="Blue">🔵</th>
                    <th>&lt;1</th>
                    <th>1-2</th>
                    <th>3-5</th>
                    <th>6-10</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $gCounter = 1;
                foreach ($tree as $group):
                    ?>
                    <tr class="group-row">
                        <td colspan="14"><?= $gCounter ?> - <?= t($group['name'], $translations) ?></td>
                    </tr>
                    <?php
                    $cCounter = 1;
                    foreach ($group['children'] as $child):
                        $images = $child['media'] ?? [];
                        $imgHtml = '';
                        if (!empty($images)) {
                            foreach ($images as $img) {
                                $src = get_image_url($img['file_path']) . '?t=' . time();
                                $imgHtml .= "<img src='{$src}' class='detail-img'>";
                            }
                        }

                        $risk = $child['risk_level'] ?? '';
                        $r = strpos($risk, 'Rød') !== false ? '☒' : '☐';
                        $y = strpos($risk, 'Gul') !== false ? '☒' : '☐';
                        $blk = strpos($risk, 'Sort') !== false ? '☒' : '☐';
                        $g = strpos($risk, 'Grøn') !== false ? '☒' : '☐';
                        $b = strpos($risk, 'Blå') !== false ? '☒' : '☐';

                        $marker = (!empty($child['is_bcl']) && $child['is_bcl'] == 1) ? 'BCL' : 'X';
                        $cb = $child['cost_buckets'] ?? ['0_1' => 0, '1_2' => 0, '3_5' => 0, '5_10' => 0];
                        $t1 = ($cb['0_1'] > 0) ? $marker : '';
                        $t2 = ($cb['1_2'] > 0) ? $marker : '';
                        $t3 = ($cb['3_5'] > 0) ? $marker : '';
                        $t4 = ($cb['5_10'] > 0) ? $marker : '';
                        ?>
                        <tr>
                            <td><b><?= $gCounter ?>.<?= $cCounter ?> <?= htmlspecialchars(t($child['name'], $translations)) ?></b></td>
                            <td style="font-size:0.9em;"><?= nl2br(htmlspecialchars($child['description'] ?? '')) ?></td>
                            <td style="text-align:center;"><?= $imgHtml ?></td>
                            <td style="font-size:0.9em;"><?= nl2br(htmlspecialchars($child['recommendation'] ?? '')) ?></td>
                            <td style="text-align:center; font-size:0.85em; font-weight:bold;"><?= htmlspecialchars($child['condition_rating'] ?? '-') ?></td>
                            <td style="text-align:center; font-size:0.85em; font-weight:bold;"><?= htmlspecialchars($child['quality_rating'] ?? '-') ?></td>
                            
                            <!-- QUANTIFICATION (BUDGET ITEMS) -->
                            <td class="num-cell" style="text-align:left; font-size:0.9em;">
                                <?php 
                                // Show detailed budget items if they exist (FEATURE REQUEST)
                                if (!empty($child['budget_items'])) {
                                    foreach ($child['budget_items'] as $bi) {
                                        $bQty = (float)($bi['quantity'] ?? 0);
                                        if ($bQty > 0) {
                                            echo '<div>';
                                            if (!empty($bi['description'])) {
                                                echo '<span style="color:#555;">' . htmlspecialchars($bi['description']) . '</span> ';
                                            }
                                            echo '<b>' . number_format($bQty, 2, ',', '.') . ' ' . htmlspecialchars($bi['unit'] ?? 'stk') . '</b>';
                                            echo '</div>';
                                        }
                                    }
                                } 
                                // Fallback
                                elseif (!empty($child['quantity']) && $child['quantity'] > 0) {
                                    echo '<div>' . number_format((float)$child['quantity'], 2, ',', '.') . ' ' . htmlspecialchars($child['unit'] ?? '') . '</div>';
                                }
                                ?>
                            </td>

                            <td style="text-align:center; color:red;"><?= $r ?></td>
                            <td style="text-align:center; color:#d4ac0d;"><?= $y ?></td>
                            <td style="text-align:center;"><?= $blk ?></td>
                            <td style="text-align:center; color:green;"><?= $g ?></td>
                            <td style="text-align:center; color:blue;"><?= $b ?></td>

                            <td style="text-align:center; font-size:0.8em;"><?= $t1 ?></td>
                            <td style="text-align:center; font-size:0.8em;"><?= $t2 ?></td>
                            <td style="text-align:center; font-size:0.8em;"><?= $t3 ?></td>
                            <td style="text-align:center; font-size:0.8em;"><?= $t4 ?></td>
                        </tr>
                        <?php
                        $cCounter++;
                    endforeach;
                    $gCounter++;
                endforeach;
                ?>
            </tbody>
        </table>
    </div>

<?php endforeach; ?>
</body>
</html>
