<?php
// Disable Caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Translation Map (Should match i18n.js)
$translations = [
    'std.1' => 'Udendørsarealer (Terræn)',
    'std.1.1' => 'Belægninger (Vej, sti, fortov, pladser)',
    'std.1.2' => 'Grønne områder (Beplantning, græsarealer)',
    'std.1.3' => 'Hegn, porte og støttemure',
    'std.1.4' => 'Udvendig belysning',
    'std.1.5' => 'Afvanding af terræn (Brønde, render)',
    'std.1.6' => 'Skilte og inventar (Bænke, cykelstativer)',

    'std.2' => 'Bygningsskal (Klimaskærm)',
    'std.2.1' => 'Fundamenter og terrændæk',
    'std.2.2' => 'Facader (Murværk, beton, lette facader)',
    'std.2.3' => 'Vinduer og yderdøre',
    'std.2.4' => 'Tage (Tagdækning, ovenlys, tagbrønde)',
    'std.2.5' => 'Altaner og udvendige trapper',
    'std.2.6' => 'Porte og ramper (f.eks. til vareindlevering)',

    'std.3' => 'Indvendige bygningsdele',
    'std.3.1' => 'Indvendige vægge og skillevægge',
    'std.3.2' => 'Indvendige døre og partier',
    'std.3.3' => 'Gulve og gulvbelægninger',
    'std.3.4' => 'Lofter (Systemlofter, faste lofter)',
    'std.3.5' => 'Indvendige trapper',
    'std.3.6' => 'Inventar (Køkkener, toiletter, faste skabe)',

    'std.4' => 'Tekniske installationer',
    'std.4.1' => 'Vand (Brugsvand, sanitet)',
    'std.4.2' => 'Afløb (Spildevand, regnvand indvendigt)',
    'std.4.3' => 'Varme (Radiatorer, gulvvarme, fjernvarmeunits)',
    'std.4.4' => 'Køling (Køleflader, serverrumskøling)',
    'std.4.5' => 'Ventilation (Aggregater, kanaler, styring)',
    'std.4.6' => 'El-grundinstallationer (Tavler, føringsveje)',
    'std.4.7' => 'Belysning (Indvendig)',
    'std.4.8' => 'Elevatorer og løfteplatforme',
    'std.4.9' => 'Brandsikring (ABA, varsling, sprinkler, røgudluftning)',
    'std.4.10' => 'CTS / Bygningsautomation'
];

if (!function_exists('translate')) {
    function translate($key, $map)
    {
        if (isset($map[$key])) {
            return $map[$key];
        }
        return $key;
    }
}
?>
<!DOCTYPE html>
<html lang="da">

<head>
    <meta charset="UTF-8">
    <title>Tilstandsrapport - <?= htmlspecialchars($project['name']) ?></title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary: #2563eb;
            --primary-hover: #1d4ed8;
            --bg-body: #f1f5f9;
            --bg-backdrop: #475569;
            --sidebar-width: 260px;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
            --radius-md: 4px;
            --radius-lg: 8px;
            --glass-bg: rgba(255, 255, 255, 0.8);
            --glass-border: rgba(255, 255, 255, 0.2);
            --text-main: #1e293b;
            --text-muted: #64748b;
        }

        /* BASE & RESET */
        * {
            box-sizing: border-box;
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            color: var(--text-main);
            margin: 0;
            padding: 20px 0 20px var(--sidebar-width);
            background: var(--bg-backdrop);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            transition: padding 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        body.sidebar-collapsed {
            padding-left: 40px;
        }


        /* A4 PAGE CONTAINER */
        .page {
            width: 210mm;
            min-height: 297mm;
            padding: 15mm 20mm;
            margin: 30px auto;
            background: white;
            box-shadow: var(--shadow-lg), 0 0 40px rgba(0,0,0,0.1);
            position: relative;
            overflow: hidden;
            flex-shrink: 0;
            display: flex;
            flex-direction: column;
            border-radius: 2px;
            animation: fadeInPage 0.5s ease-out backwards;
        }

        @keyframes fadeInPage {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .page-content {
            flex: 1;
            position: relative;
        }

        /* SIDEBAR NAVIGATION */
        #nav-sidebar {
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            width: var(--sidebar-width);
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            border-right: 1px solid rgba(226, 232, 240, 0.8);
            overflow-y: auto;
            padding: 20px 15px;
            z-index: 999;
            transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 10px 0 30px rgba(0,0,0,0.03);
        }

        #nav-sidebar.collapsed {
            transform: translateX(-100%);
        }

        .sidebar-toggle {
            position: fixed;
            top: 50%;
            left: var(--sidebar-width);
            transform: translateY(-50%);
            width: 32px;
            height: 60px;
            background: #fff;
            border: 1px solid #e2e8f0;
            border-left: none;
            border-radius: 0 8px 8px 0;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            z-index: 1000;
            transition: left 0.4s cubic-bezier(0.4, 0, 0.2, 1), background 0.2s;
            box-shadow: 4px 0 10px rgba(0,0,0,0.05);
            font-weight: 800;
            color: var(--text-muted);
        }

        .sidebar-toggle:hover {
            background: #f8fafc;
            color: var(--primary);
        }

        .sidebar-collapsed .sidebar-toggle {
            left: 0;
        }

        #nav-sidebar h3 {
            font-size: 1.1rem;
            margin-top: 0;
            color: var(--text-main);
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
            font-weight: 700;
        }

        .search-container {
            margin-bottom: 20px;
        }

        .search-input {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #e2e8f0;
            border-radius: var(--radius-md);
            font-size: 0.85rem;
            background: #f8fafc;
            transition: all 0.2s;
        }

        .nav-group {
            margin-top: 15px;
        }

        .nav-group-title {
            font-weight: 600;
            color: var(--text-main);
            display: block;
            margin-bottom: 6px;
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.2s;
        }

        .nav-links {
            list-style: none;
            padding-left: 12px;
            margin: 0;
            border-left: 1px solid #f1f5f9;
        }

        .nav-links li {
            margin-bottom: 4px;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--text-muted);
            font-size: 0.8rem;
            display: block;
            transition: all 0.2s;
            padding: 1px 0;
        }

        .nav-links a:hover, .nav-links a.active {
            color: var(--primary);
            padding-left: 5px;
        }

        /* PRINT STYLES */
        @media print {
            body {
                background: white !important;
                margin: 0 !important;
                padding: 0 !important;
                display: block !important;
            }
            #nav-sidebar, #controls, .no-print, .sidebar-toggle {
                display: none !important;
            }
            .page {
                margin: 0 !important;
                border: none !important;
                box-shadow: none !important;
                width: 210mm !important;
                height: auto !important;
                min-height: 297mm !important;
                page-break-after: always !important;
                overflow: visible !important;
            }
            @page {
                size: A4 portrait;
                margin: 0;
            }
            .report-element {
                break-inside: avoid;
            }
            details:not([open]) {
                display: none !important;
            }
        }

        /* TYPOGRAPHY */
        h1 { color: var(--text-main); font-size: 24pt; margin-bottom: 25px; font-weight: 800; letter-spacing: -0.025em; }
        h2 { color: var(--text-main); font-size: 16pt; margin-top: 25px; border-bottom: 2px solid #f1f5f9; padding-bottom: 8px; font-weight: 700; }
        h3 { color: #334155; font-size: 13pt; margin-top: 20px; font-weight: 700; }
        h4 { color: var(--text-muted); font-size: 9pt; margin-top: 12px; text-transform: uppercase; letter-spacing: 0.1em; font-weight: 800; }

        p, li, td { font-size: 10pt; line-height: 1.6; color: #475569; }

        .page-header {
            position: absolute;
            top: 10mm;
            left: 20mm;
            right: 20mm;
            border-bottom: 1px solid #f1f5f9;
            padding-bottom: 8px;
            font-size: 9pt;
            color: var(--text-muted);
            display: flex;
            justify-content: space-between;
            font-weight: 500;
        }

        .page-footer {
            height: 12mm;
            margin-top: auto;
            border-top: 1px solid #f1f5f9;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 9pt;
            color: var(--text-muted);
            font-weight: 500;
        }

        /* TOC */
        .toc-list { list-style: none; padding: 0; }
        .toc-row { display: flex; justify-content: space-between; gap: 10px; margin-bottom: 10px; align-items: baseline; }
        .toc-link { text-decoration: none; color: inherit; flex: 1; display: flex; align-items: baseline; transition: color 0.2s; }
        .toc-link:hover { color: var(--primary); }
        .toc-name { font-weight: 500; }
        .toc-indent { margin-left: 24px; color: var(--text-muted); font-size: 0.9em; }
        .toc-fill { flex: 1; border-bottom: 1.5px dotted #e2e8f0; margin: 0 8px; position: relative; top: -3px; }
        .toc-page { font-weight: 600; color: var(--text-main); min-width: 60px; text-align: right; }

        /* DASHBOARD */
        .dashboard-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 30px; }
        .dashboard-card {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: var(--radius-lg);
            padding: 20px;
            text-align: center;
            transition: transform 0.2s;
            box-shadow: var(--shadow-sm);
        }
        .dashboard-card:hover { transform: translateY(-2px); box-shadow: var(--shadow-md); }
        .card-val { font-size: 16pt; font-weight: 800; color: var(--text-main); margin-bottom: 4px; }
        .card-label { font-size: 8pt; color: var(--text-muted); text-transform: uppercase; font-weight: 700; letter-spacing: 0.05em; }
        
        .period-0_1 { border-top: 5px solid #ef4444; }
        .period-1_2 { border-top: 5px solid #f59e0b; }
        .period-3_5 { border-top: 5px solid #3b82f6; }
        .period-5_10 { border-top: 5px solid #10b981; }

        /* IMAGES */
        .image-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 20px; }
        .report-img-container {
            border-radius: var(--radius-lg);
            overflow: hidden;
            border: 1px solid #e2e8f0;
            box-shadow: var(--shadow-sm);
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .report-img-container:hover { transform: scale(1.02); box-shadow: var(--shadow-md); }
        .report-img { width: 100%; height: 160px; object-fit: cover; background: #f8fafc; display: block; }
        .img-caption { font-size: 8.5pt; color: var(--text-muted); padding: 8px 12px; background: #fff; border-top: 1px solid #f1f5f9; font-style: italic; }

        /* TABLES */
        table { width: 100%; border-collapse: separate; border-spacing: 0; margin-top: 10px; }
        th { text-align: left; background: #f8fafc; padding: 10px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; font-size: 7.5pt; letter-spacing: 0.05em; border-bottom: 2px solid #e2e8f0; }
        td { border-bottom: 1px solid #f1f5f9; padding: 10px; color: var(--text-main); font-size: 9pt; }
        tr:last-child td { border-bottom: none; }

        /* RISK BADGES */
        .risk-badge { padding: 6px 12px; border-radius: 99px; color: white; font-size: 8.5pt; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .risk-Rød { background: linear-gradient(135deg, #ef4444, #dc2626); }
        .risk-Gul { background: linear-gradient(135deg, #f59e0b, #d97706); }
        .risk-Grøn { background: linear-gradient(135deg, #10b981, #059669); }
        .risk-Ikke { background: #94a3b8; }

        /* CONTROLS */
        #controls {
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--glass-bg);
            backdrop-filter: blur(12px);
            padding: 20px;
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-lg);
            z-index: 9999;
            width: 300px;
            border: 1px solid var(--glass-border);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        #controls.collapsed { transform: translateX(240px); opacity: 0.6; }
        #controls.collapsed:hover { transform: translateX(0); opacity: 1; }

        .btn-print {
            width: 100%;
            padding: 12px;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: var(--radius-md);
            cursor: pointer;
            font-weight: 700;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: all 0.2s;
            box-shadow: 0 4px 6px -1px rgba(37, 99, 235, 0.2);
        }

        .btn-print:hover { background: var(--primary-hover); transform: translateY(-1px); box-shadow: 0 10px 15px -3px rgba(37, 99, 235, 0.3); }

        /* LIGHTBOX */
        #report-lightbox {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(15, 23, 42, 0.95);
            z-index: 100000;
            display: none;
            align-items: center;
            justify-content: center;
            backdrop-filter: blur(8px);
            cursor: zoom-out;
        }
        #report-lightbox img {
            max-width: 90%;
            max-height: 90%;
            border-radius: 8px;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5);
            animation: zoomIn 0.3s ease-out;
        }
        @keyframes zoomIn { from { transform: scale(0.9); opacity: 0; } to { transform: scale(1); opacity: 1; } }

        /* UTILS */
        .hidden-source { display: none; }
        .text-right { text-align: right; }
    </style>
</head>

<body>

    <!-- SIDEBAR TOGGLE -->
    <div class="sidebar-toggle no-print" onclick="toggleSidebar()" id="sidebar-toggle-btn">
        <span id="toggle-icon">«</span>
    </div>


    <!-- NAVIGATION SIDEBAR -->
    <div id="nav-sidebar" class="no-print">
        <h3>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1-2.5-2.5Z"></path><path d="M8 7h6"></path><path d="M8 11h8"></path></svg>
            Indhold
        </h3>
        
        <div class="search-container">
            <input type="text" class="search-input" id="sidebar-search" placeholder="Søg i rapporten..." onkeyup="filterSidebar()">
        </div>
        <?php foreach ($buildings as $building): $tree = $building['tree']; ?>
            <h4 style="color:#2980b9; border-bottom:1px solid #ddd; margin-top:20px;"><?= htmlspecialchars($building['name']) ?></h4>
            <?php
            $gCounter = 1;
            foreach ($tree as $group):
                $groupName = translate($group['name'], $translations);
                ?>
                <div class="nav-group">
                    <a href="#elem-group-<?= $building['id'] ?>-<?= $gCounter ?>" class="nav-group-title"><?= $gCounter ?>.
                        <?= htmlspecialchars($groupName) ?></a>
                    <?php if (!empty($group['children'])): ?>
                        <ul class="nav-links">
                            <?php
                            $cCounter = 1;
                            foreach ($group['children'] as $child):
                                $childName = translate($child['name'], $translations);
                                $childNum = "$gCounter.$cCounter";
                                ?>
                                <li><a href="#elem-<?= $child['id'] ?>"><?= $childNum ?> <?= htmlspecialchars($childName) ?></a></li>
                                <?php
                                $cCounter++;
                            endforeach;
                            ?>
                        </ul>
                    <?php endif; ?>
                </div>
                <?php
                $gCounter++;
            endforeach;
            ?>
        <?php endforeach; ?>
        <div class="nav-group" style="margin-top:20px; border-top:1px solid #ddd; padding-top:10px;">
            <a href="#budget-section" class="nav-group-title">Budgetsoversigt</a>
        </div>
    </div>

    <div id="controls" class="no-print">
        <div class="controls-header" onclick="document.getElementById('controls').classList.toggle('collapsed')">
            <h3 style="margin:0; font-size:1rem;">Rapportværktøj</h3>
             <span>▼</span>
        </div>
        <div style="margin-top:15px;">
            <button onclick="window.print()" class="btn-print">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
                Udskriv / PDF
            </button>
            <div class="filter-toggle">
                <input type="checkbox" id="filter-irrelevant" onchange="paginateReport()">
                <label for="filter-irrelevant" style="cursor:pointer; margin:0;">Skjul "Ikke relevant"</label>
            </div>
            <div id="status-msg" style="margin-top:10px; font-size:0.8rem; color:#27ae60;"></div>
        </div>
    </div>

    <!-- PREVIEW CONTAINER -->
    <div id="report-preview"></div>

    <!-- HIDDEN SOURCE (Raw Content) -->
    <div id="source-content" class="hidden-source">

        <!-- COVER CONTENT -->
        <div id="source-cover">
            <div style="height:100%; display:flex; flex-direction:column;">
                <div style="text-align:right; font-weight:800; font-size:18pt; color:#1e293b;">
                    TDD<span style="color:#2980b9;">BJERG</span>
                </div>

                <div style="margin-top:60px;">
                    <h1 style="font-size:36pt; margin-bottom:10px; color:#1e293b;"><?= htmlspecialchars($project['name']) ?></h1>
                    <div style="font-size:18pt; color:#64748b;">Tilstandsrapport</div>
                </div>

                <?php
                $coverImage = !empty($project['cover_image']) ? get_image_url($project['cover_image']) : null;
                ?>
                <div
                    style="margin-top:50px; flex-grow:1; max-height:450px; overflow:hidden; border:1px solid #e2e8f0; background:#f8fafc; border-radius:12px; display:flex; align-items:center; justify-content:center;">
                    <?php if ($coverImage): ?>
                        <img src="<?= $coverImage ?>?t=<?= time() ?>" style="width:100%; height:100%; object-fit:cover;">
                    <?php else: ?>
                        <div style="text-align:center; color:#94a3b8;">
                            <div style="font-size:48pt; margin-bottom:15px;">🏢</div>
                            <div style="font-weight:600;">Ingen coverbillede</div>
                        </div>
                    <?php endif; ?>
                </div>

                <div
                    style="margin-top:auto; margin-bottom:40px; background:#f8fafc; border-radius:12px; border:1px solid #e2e8f0; padding:25px; display:grid; grid-template-columns: 1fr 1fr; gap:20px;">
                    <div>
                        <span style="font-size:8pt; text-transform:uppercase; font-weight:800; color:#64748b; letter-spacing:0.5px;">Kunde</span>
                        <div style="font-weight:600; font-size:11pt; color:#1e293b; margin-top:5px;"><?= htmlspecialchars($client['name'] ?? 'Ukendt') ?></div>
                    </div>
                    <div>
                         <span style="font-size:8pt; text-transform:uppercase; font-weight:800; color:#64748b; letter-spacing:0.5px;">Dato</span>
                         <div style="font-weight:600; font-size:11pt; color:#1e293b; margin-top:5px;"><?= date('d.m.Y') ?></div>
                    </div>
                     <div style="grid-column: span 2;">
                        <span style="font-size:8pt; text-transform:uppercase; font-weight:800; color:#64748b; letter-spacing:0.5px;">Adresse</span>
                        <div style="font-weight:600; font-size:11pt; color:#1e293b; margin-top:5px;"><?= htmlspecialchars($project['address'] ?? '') ?></div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- DASHBOARD CONTENT -->
        <div id="source-summary">
            <?php
            $globalSum = ['0_1' => 0, '1_2' => 0, '3_5' => 0, '5_10' => 0, 'total' => 0];
            $globalRisks = ['Rød' => 0, 'Gul' => 0, 'Grøn' => 0, 'Sort' => 0];
            foreach ($buildings as $b) {
                foreach ($b['tree'] as $g) {
                    foreach ($g['children'] as $c) {
                        $globalSum['0_1'] += ($c['cost_buckets']['0_1'] ?? 0);
                        $globalSum['1_2'] += ($c['cost_buckets']['1_2'] ?? 0);
                        $globalSum['3_5'] += ($c['cost_buckets']['3_5'] ?? 0);
                        $globalSum['5_10'] += ($c['cost_buckets']['5_10'] ?? 0);
                        $globalSum['total'] += ($c['total_budget'] ?? 0);
                        
                        $rTag = explode(' ', $c['risk_level'] ?? '')[0];
                        if (isset($globalRisks[$rTag])) $globalRisks[$rTag]++;
                    }
                }
            }
            ?>
            <div class="report-element">
                <h1>Executive Summary</h1>
                
                <div class="dashboard-grid">
                    <div class="dashboard-card period-0_1">
                        <div class="card-val"><?= number_format($globalSum['0_1'], 0, ',', '.') ?> kr.</div>
                        <div class="card-label">&lt; 1 år</div>
                    </div>
                    <div class="dashboard-card period-1_2">
                        <div class="card-val"><?= number_format($globalSum['1_2'], 0, ',', '.') ?> kr.</div>
                        <div class="card-label">1-2 år</div>
                    </div>
                    <div class="dashboard-card period-3_5">
                        <div class="card-val"><?= number_format($globalSum['3_5'], 0, ',', '.') ?> kr.</div>
                        <div class="card-label">3-5 år</div>
                    </div>
                    <div class="dashboard-card period-5_10">
                        <div class="card-val"><?= number_format($globalSum['5_10'], 0, ',', '.') ?> kr.</div>
                        <div class="card-label">6-10 år</div>
                    </div>
                </div>

                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:12px; padding:25px; margin-bottom:30px; display:grid; grid-template-columns: 1fr 1fr; gap:40px;">
                    <div>
                        <h4 style="margin-top:0;">Total CAPEX (10 år)</h4>
                        <div style="font-size:24pt; font-weight:800; color:#1e40af;"><?= number_format($globalSum['total'], 0, ',', '.') ?> kr.</div>
                        <p style="margin-top:10px; color:#64748b;">Samlet overslag for alle bygningsdele ekskl. moms.</p>
                    </div>
                    <div>
                        <h4 style="margin-top:0;">Risikofordeling</h4>
                        <div style="display:flex; gap:30px; align-items:center; margin-top:20px;">
                            <?php
                            $totalRisks = $globalRisks['Rød'] + $globalRisks['Gul'] + $globalRisks['Grøn'];
                            $redP = $totalRisks > 0 ? ($globalRisks['Rød'] / $totalRisks) * 100 : 0;
                            $yellowP = $totalRisks > 0 ? ($globalRisks['Gul'] / $totalRisks) * 100 : 0;
                            $greenP = $totalRisks > 0 ? ($globalRisks['Grøn'] / $totalRisks) * 100 : 0;
                            ?>
                            <div style="width:100px; height:100px; border-radius:50%; background: conic-gradient(#ef4444 0% <?= $redP ?>%, #f59e0b <?= $redP ?>% <?= $redP + $yellowP ?>%, #10b981 <?= $redP + $yellowP ?>% 100%); position:relative; display:flex; align-items:center; justify-content:center; box-shadow: var(--shadow-md);">
                                <div style="width:60px; height:60px; background:white; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:800; font-size:12pt; color:var(--text-main);">
                                    <?= $totalRisks ?>
                                </div>
                            </div>
                            <div style="flex:1;">
                                <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
                                    <span style="font-size:8pt; font-weight:700; color:#ef4444;">RØD (<?= $globalRisks['Rød'] ?>)</span>
                                    <span style="font-size:8pt; color:var(--text-muted);"><?= round($redP) ?>%</span>
                                </div>
                                <div style="width:100%; height:8px; background:#f1f5f9; border-radius:4px; margin-bottom:12px; overflow:hidden;">
                                    <div style="width:<?= $redP ?>%; height:100%; background:#ef4444;"></div>
                                </div>
                                <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
                                    <span style="font-size:8pt; font-weight:700; color:#f59e0b;">GUL (<?= $globalRisks['Gul'] ?>)</span>
                                    <span style="font-size:8pt; color:var(--text-muted);"><?= round($yellowP) ?>%</span>
                                </div>
                                <div style="width:100%; height:8px; background:#f1f5f9; border-radius:4px; margin-bottom:12px; overflow:hidden;">
                                    <div style="width:<?= $yellowP ?>%; height:100%; background:#f59e0b;"></div>
                                </div>
                                <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
                                    <span style="font-size:8pt; font-weight:700; color:#10b981;">GRØN (<?= $globalRisks['Grøn'] ?>)</span>
                                    <span style="font-size:8pt; color:var(--text-muted);"><?= round($greenP) ?>%</span>
                                </div>
                                <div style="width:100%; height:8px; background:#f1f5f9; border-radius:4px; overflow:hidden;">
                                    <div style="width:<?= $greenP ?>%; height:100%; background:#10b981;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- INTRO & DEFINITIONS -->
        <div id="source-intro">
            <?php if (!empty($project['report_intro'])): ?>
            <div style="margin-bottom:40px;">
                <h1>Introduktion</h1>
                <div style="white-space:pre-wrap;"><?= htmlspecialchars($project['report_intro']) ?></div>
            </div>
            <?php endif; ?>

            <?php if (!empty($project['report_disclaimer'])): ?>
            <div style="margin-bottom:40px;">
                <h1>Definitioner & Metodik</h1>
                <div style="white-space:pre-wrap;"><?= htmlspecialchars($project['report_disclaimer']) ?></div>
            </div>
            <?php endif; ?>
        </div>

        <!-- TOC CONTENT -->
        <div id="source-toc">
            <h1>Indholdsfortegnelse</h1>
            <ul class="toc-list">
                <?php foreach ($buildings as $building): $tree = $building['tree']; ?>
                <li class="toc-row" style="margin-top: 15px; font-weight:700; color:#1e293b;">
                    <span><?= htmlspecialchars($building['name']) ?></span>
                </li>
                <?php
                $gCounter = 1;
                foreach ($tree as $group):
                    $groupName = translate($group['name'], $translations);
                    ?>
                    <li class="toc-row">
                        <a href="#elem-group-<?= $building['id'] ?>-<?= $gCounter ?>" class="toc-link">
                            <span class="toc-name"><?= $gCounter ?>. <?= htmlspecialchars($groupName) ?></span>
                            <span class="toc-fill"></span>
                            <span class="toc-page" data-target="elem-group-<?= $building['id'] ?>-<?= $gCounter ?>">...</span>
                        </a>
                    </li>
                    <?php if (!empty($group['children'])):
                        $cCounter = 1;
                        foreach ($group['children'] as $child):
                            $childName = translate($child['name'], $translations);
                            $childNum = "$gCounter.$cCounter";
                            $isIrrelevant = (strpos($child['risk_level'] ?? '', 'Ikke relevant') !== false);
                            ?>
                            <li class="toc-row <?= $isIrrelevant ? 'toc-irrelevant' : '' ?>">
                                <a href="#elem-<?= $child['id'] ?>" class="toc-link">
                                    <span class="toc-name toc-indent"><?= $childNum ?> <?= htmlspecialchars($childName) ?></span>
                                    <span class="toc-fill"></span>
                                    <span class="toc-page" data-target="elem-<?= $child['id'] ?>">...</span>
                                </a>
                            </li>
                            <?php
                            $cCounter++;
                        endforeach;
                    endif;
                    $gCounter++;
                endforeach;
                endforeach; ?>
                <li class="toc-row" style="margin-top:20px; border-top:1px solid #f1f5f9; padding-top:15px;">
                    <a href="#budget-section" class="toc-link" style="font-weight:700;">
                        <span class="toc-name">Budgetsoversigt (CAPEX)</span>
                        <span class="toc-fill"></span>
                        <span class="toc-page" data-target="budget-section">...</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- REPORT ELEMENTS -->
        <div id="source-elements">
            <?php foreach ($buildings as $building): ?>
            <div class="report-element" id="building-<?= $building['id'] ?>">
                <h1 style="color:#2980b9; border-bottom:3px solid #2980b9; padding-bottom:10px;"><?= htmlspecialchars($building['name']) ?></h1>
            </div>

            <?php
            $gCounter = 1;
            foreach ($building['tree'] as $group):
                $groupName = translate($group['name'], $translations);
                ?>
                <div class="report-element" id="elem-group-<?= $building['id'] ?>-<?= $gCounter ?>">
                    <div class="report-group-header">
                        <h2><?= $gCounter ?>. <?= htmlspecialchars($groupName) ?></h2>
                        <?php if (!empty($group['location'])): ?>
                            <p><i>Lokation: <?= htmlspecialchars($group['location']) ?></i></p>
                        <?php endif; ?>
                        <?php if (!empty($group['observation'])): ?>
                            <div style="background:#f8fafc; padding:15px; border-radius:8px; border:1px solid #e2e8f0; margin-top:10px;">
                                <strong>Generelle observationer:</strong><br>
                                <?= nl2br(htmlspecialchars($group['observation'])) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if (!empty($group['children'])):
                    $cCounter = 1;
                    foreach ($group['children'] as $child):
                        $childName = translate($child['name'], $translations);
                        $childNum = "$gCounter.$cCounter";
                        ?>
                        <div class="report-element" id="elem-<?= $child['id'] ?>">
                            <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:2px solid #1e293b; padding-bottom:8px; margin-bottom:20px;">
                                <h3 style="margin:0;"><?= $childNum ?> <?= htmlspecialchars($childName) ?></h3>
                                <?php if (!empty($child['risk_level'])): ?>
                                    <span class="risk-badge risk-<?= explode(' ', $child['risk_level'])[0] ?>">
                                        <?= htmlspecialchars($child['risk_level']) ?>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="meta-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                <?php if (!empty($child['description'])): ?>
                                    <div style="background:#fdfdfd; border-radius:var(--radius-md); padding:10px 12px; border:1px solid #f1f5f9;">
                                        <h4 style="color:#d97706; margin-top:0;">Observation</h4>
                                        <p style="margin-bottom:0;"><?= nl2br(htmlspecialchars($child['description'])) ?></p>
                                    </div>
                                <?php endif; ?>
                                <?php if (!empty($child['recommendation'])): ?>
                                    <div style="background:#fdfdfd; border-radius:var(--radius-md); padding:10px 12px; border:1px solid #f1f5f9;">
                                        <h4 style="color:#059669; margin-top:0;">Anbefaling</h4>
                                        <p style="margin-bottom:0;"><?= nl2br(htmlspecialchars($child['recommendation'])) ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <?php if (($child['total_budget'] ?? 0) > 0): ?>
                                <div style="margin-top:20px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:15px;">
                                    <div style="display:flex; justify-content:space-between; align-items:center;">
                                        <h4 style="margin:0; color:#1e40af;">Økonomisk Overslag</h4>
                                        <div style="font-weight:700; color:#1e40af; font-size:10pt;">
                                            <?= number_format($child['total_budget'], 0, ',', '.') ?> DKK
                                        </div>
                                    </div>
                                    
                                    <details style="margin-top:10px;">
                                        <summary style="cursor:pointer; font-size:8.5pt; color:var(--text-muted); font-weight:600; outline:none;">
                                            Se detaljeret overslag
                                        </summary>
                                        <table style="margin-top:10px; background:white; border-radius:4px; border:1px solid #f1f5f9;">
                                            <thead>
                                                <tr>
                                                    <th style="width:40%;">Post</th>
                                                    <th class="text-right" style="width:15%;">&lt;1 år</th>
                                                    <th class="text-right" style="width:15%;">1-2 år</th>
                                                    <th class="text-right" style="width:15%;">3-5 år</th>
                                                    <th class="text-right" style="width:15%;">6-10 år</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($child['budget_items'] as $bItem): ?>
                                                    <tr>
                                                        <td><?= htmlspecialchars($bItem['description'] ?: $childName) ?></td>
                                                        <td class="text-right"><?= $bItem['amount_0_1'] > 0 ? number_format($bItem['amount_0_1'], 0, ',', '.') : '-' ?></td>
                                                        <td class="text-right"><?= $bItem['amount_1_2'] > 0 ? number_format($bItem['amount_1_2'], 0, ',', '.') : '-' ?></td>
                                                        <td class="text-right"><?= $bItem['amount_3_5'] > 0 ? number_format($bItem['amount_3_5'], 0, ',', '.') : '-' ?></td>
                                                        <td class="text-right"><?= $bItem['amount_5_10'] > 0 ? number_format($bItem['amount_5_10'], 0, ',', '.') : '-' ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </details>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($child['media'])): ?>
                                <div class="image-grid">
                                    <?php $fIdx = 1; foreach ($child['media'] as $media): ?>
                                        <div class="report-img-container" onclick="openLightbox('<?= get_image_url($media['file_path']) ?>')">
                                            <img src="<?= get_image_url($media['file_path']) ?>?t=<?= time() ?>" class="report-img">
                                            <div class="img-caption">
                                                <strong>Fig. <?= $childNum ?>.<?= $fIdx++ ?></strong>: <?= htmlspecialchars($media['caption'] ?: $childName) ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php
                        $cCounter++;
                    endforeach;
                endif;
                $gCounter++;
            endforeach;
            ?>
            <?php endforeach; ?>

            <!-- BUDGET TOTAL -->
            <div class="report-element" id="budget-section">
                <h1>Samlet CAPEX Budgetsoversigt</h1>
                <p>Overslag over samlede CAPEX omkostninger for hele ejendommen fordelt på tidsperioder.</p>
                <table style="margin-top:30px;">
                    <thead>
                        <tr style="background:#1e293b; color:white;">
                            <th style="color:white; padding:12px;">Bygningsdel / Emne</th>
                            <th class="text-right" style="color:white; padding:12px;">Total Estimat (DKK)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($buildings as $building): ?>
                            <tr style="background:#f1f5f9; font-weight:700;">
                                <td colspan="2" style="padding:12px;"><?= htmlspecialchars($building['name']) ?></td>
                            </tr>
                            <?php foreach ($building['tree'] as $group): ?>
                                <?php 
                                $gSum = 0;
                                foreach($group['children'] as $c) $gSum += $c['total_budget'];
                                if($gSum > 0): 
                                ?>
                                    <tr style="background:#fff; font-weight:600;">
                                        <td style="padding-left:20px;"><?= htmlspecialchars(translate($group['name'], $translations)) ?></td>
                                        <td class="text-right"><?= number_format($gSum, 0, ',', '.') ?></td>
                                    </tr>
                                    <?php foreach ($group['children'] as $child): ?>
                                        <?php if ($child['total_budget'] > 0): ?>
                                            <tr>
                                                <td style="padding-left:40px; color:#64748b; font-size:8.5pt;">
                                                    <?= htmlspecialchars(translate($child['name'], $translations)) ?>
                                                </td>
                                                <td class="text-right" style="color:#64748b; font-size:8.5pt;"><?= number_format($child['total_budget'], 0, ',', '.') ?></td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr style="font-size:12pt; font-weight:800; background:#2980b9; color:white;">
                            <td style="padding:15px; color:white;">SAMLET TOTAL (EKSKL. MOMS)</td>
                            <td class="text-right" style="padding:15px; color:white;">
                                <?= number_format($globalSum['total'], 0, ',', '.') ?> DKK
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

    <div id="report-lightbox" onclick="this.style.display='none'">
        <img src="" id="lightbox-img">
    </div>

    <!-- PAGINATION SCRIPT -->
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('nav-sidebar');
            const body = document.body;
            const icon = document.getElementById('toggle-icon');
            
            sidebar.classList.toggle('collapsed');
            body.classList.toggle('sidebar-collapsed');
            
            if (sidebar.classList.contains('collapsed')) {
                icon.textContent = '»';
            } else {
                icon.textContent = '«';
            }
        }

        function openLightbox(url) {
            const lb = document.getElementById('report-lightbox');
            const img = document.getElementById('lightbox-img');
            img.src = url;
            lb.style.display = 'flex';
        }

        function filterSidebar() {
            const query = document.getElementById('sidebar-search').value.toLowerCase();
            const items = document.querySelectorAll('#nav-sidebar .nav-group, #nav-sidebar .nav-links li');
            
            items.forEach(item => {
                const text = item.textContent.toLowerCase();
                if (text.includes(query)) {
                    item.style.display = '';
                    // If it's a child, ensure parent is visible
                    if (item.tagName === 'LI') {
                        item.closest('.nav-group').style.display = '';
                    }
                } else {
                    item.style.display = 'none';
                }
            });
        }

        function updateScrollSpy() {
            const sections = document.querySelectorAll('.page-content [id^="elem-"], .page-content [id^="building-"]');
            const navLinks = document.querySelectorAll('#nav-sidebar a');
            
            let current = "";
            sections.forEach(section => {
                const sectionTop = section.getBoundingClientRect().top;
                if (sectionTop < 200) {
                    current = section.getAttribute('id');
                }
            });

            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === `#${current}`) {
                    link.classList.add('active');
                }
            });
        }

        function paginateReport() {
            const preview = document.getElementById('report-preview');
            const sourceElements = document.getElementById('source-elements');
            const sourceCover = document.getElementById('source-cover');
            const sourceSummary = document.getElementById('source-summary');
            const sourceIntro = document.getElementById('source-intro');
            const sourceToc = document.getElementById('source-toc');
            const isFilterActive = document.getElementById('filter-irrelevant').checked;

            preview.innerHTML = '';
            
            // Paginated Mode: Advanced logic
            document.querySelectorAll('.toc-page').forEach(s => s.style.display = '');
            let pageCounter = 1;
            let pageMap = {};

            function createPage() {
                const page = document.createElement('div');
                page.className = 'page';
                
                const header = document.createElement('div');
                header.className = 'page-header';
                header.innerHTML = `<span><?= htmlspecialchars($project['name']) ?></span><span>Side ${pageCounter}</span>`;
                page.appendChild(header);

                const content = document.createElement('div');
                content.className = 'page-content';
                page.appendChild(content);
                
                const footer = document.createElement('div');
                footer.className = 'page-footer';
                footer.textContent = 'Tilstandsrapport - TDD Bjerg';
                page.appendChild(footer);
                
                preview.appendChild(page);
                return { page, content };
            }

            // 1. Cover
            let p = createPage();
            p.page.querySelector('.page-header').style.display = 'none';
            p.page.querySelector('.page-footer').style.display = 'none';
            p.content.innerHTML = sourceCover.innerHTML;
            pageCounter++;

            // 2. Summary & Dashboard
            p = createPage();
            p.content.innerHTML = sourceSummary.innerHTML;
            pageCounter++;

            // 3. Intro
            p = createPage();
            Array.from(sourceIntro.children).forEach(child => {
                const node = child.cloneNode(true);
                p.content.appendChild(node);
                if (p.content.scrollHeight > p.content.clientHeight) {
                    p.content.removeChild(node);
                    p = createPage();
                    p.content.appendChild(node);
                    pageCounter++;
                }
            });
            pageCounter++;

            // 4. TOC
            p = createPage();
            const tocContent = sourceToc.cloneNode(true);
            const tocTitle = tocContent.querySelector('h1');
            const tocItems = Array.from(tocContent.querySelectorAll('.toc-row'));
            
            p.content.appendChild(tocTitle);
            let tocList = document.createElement('ul');
            tocList.className = 'toc-list';
            p.content.appendChild(tocList);

            tocItems.forEach(item => {
                if (isFilterActive && item.classList.contains('toc-irrelevant')) return;
                tocList.appendChild(item);
                if (p.content.scrollHeight > p.content.clientHeight) {
                    tocList.removeChild(item);
                    p = createPage();
                    tocList = document.createElement('ul');
                    tocList.className = 'toc-list';
                    p.content.appendChild(tocList);
                    tocList.appendChild(item);
                    pageCounter++;
                }
            });
            pageCounter++;

            // 5. Elements - Intelligent Splitting
            p = createPage();
            const elements = Array.from(sourceElements.children);
            
            elements.forEach(el => {
                if (isFilterActive && el.querySelector('.risk-Ikke')) return;

                // Force break before new buildings or if group header is too low
                const isGroup = el.id && el.id.startsWith('elem-group-');
                const isBuilding = el.id && el.id.startsWith('building-');
                const currentHeight = p.content.scrollHeight;
                const maxHeight = p.content.clientHeight;

                if ((isBuilding || (isGroup && currentHeight > maxHeight * 0.7)) && p.content.children.length > 0) {
                    p = createPage();
                    pageCounter++;
                }

                if (el.id) pageMap[el.id] = pageCounter;
                const node = el.cloneNode(true);
                p.content.appendChild(node);

                // Check if element is too big or breaks badly
                if (p.content.scrollHeight > p.content.clientHeight) {
                    p.content.removeChild(node);
                    
                    // If it's a building element card, we definitely want to keep it together
                    // unless it's literally larger than a page (rare)
                    p = createPage();
                    p.content.appendChild(node);
                    pageCounter++;
                    if (el.id) pageMap[el.id] = pageCounter;
                }
            });
            
            // 6. Budget Section
            const budgetSec = document.getElementById('budget-section').cloneNode(true);
            if (p.content.scrollHeight + 300 > p.content.clientHeight) { // Heuristic: budget needs ~300px
                p = createPage();
                pageCounter++;
            }
            p.content.appendChild(budgetSec);
            pageMap['budget-section'] = pageCounter;

            // 7. Update TOC Mapping
            const allTocPages = preview.querySelectorAll('.toc-page');
            allTocPages.forEach(span => {
                const targetId = span.getAttribute('data-target');
                if (pageMap[targetId]) {
                    span.textContent = `Side ${pageMap[targetId]}`;
                }
            });

            document.getElementById('status-msg').innerText = `Klar! ${pageCounter - 1} sider genereret.`;
        }

        window.addEventListener('scroll', updateScrollSpy);
        document.addEventListener('DOMContentLoaded', paginateReport);
    </script>
</body>
</html>
