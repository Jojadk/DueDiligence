<?php
// modules/elements/templates/report_summary_landscape.tpl

// Helper translation
$translations = [
    'std.1' => 'Udendørsarealer',
    'std.1.1' => 'Belægninger',
    'std.1.2' => 'Grønne områder',
    'std.1.3' => 'Hegn, porte og støttemure',
    'std.1.4' => 'Udvendig belysning',
    'std.1.5' => 'Afvanding af terræn',
    'std.1.6' => 'Skilte og inventar',
    'std.2' => 'Bygningsskal',
    'std.2.1' => 'Fundamenter og terrændæk',
    'std.2.2' => 'Facader',
    'std.2.3' => 'Vinduer og yderdøre',
    'std.2.4' => 'Tage',
    'std.2.5' => 'Altaner og udvendige trapper',
    'std.2.6' => 'Porte og ramper',
    'std.3' => 'Indvendige bygningsdele',
    'std.3.1' => 'Indvendige vægge',
    'std.3.2' => 'Indvendige døre',
    'std.3.3' => 'Gulve',
    'std.3.4' => 'Lofter',
    'std.3.5' => 'Indvendige trapper',
    'std.3.6' => 'Inventar',
    'std.4' => 'Tekniske installationer',
    'std.4.1' => 'Vand',
    'std.4.2' => 'Afløb',
    'std.4.3' => 'Varme',
    'std.4.4' => 'Køling',
    'std.4.5' => 'Ventilation',
    'std.4.6' => 'El-grundinstallationer',
    'std.4.7' => 'Belysning',
    'std.4.8' => 'Elevatorer',
    'std.4.9' => 'Brandsikring',
    'std.4.10' => 'CTS'
];

function t($key, $map) {
    return $map[$key] ?? $key;
}

// Prepare Summary Data
$summaryData = []; // Now it will be [ ['name' => 'Bldg 1', 'groups' => [...] ], ... ]
$totalBuckets = ['<1' => 0, '1-2' => 0, '3-5' => 0, '6-10' => 0, 'total' => 0];

$unforeseenPct = (float)($constants['unforeseen'] ?? 0);
$designPct = (float)($constants['design'] ?? 0);
$managementPct = (float)($constants['management'] ?? 0);
$consultancyPct = (float)($constants['consultancy'] ?? 0);

$totalOthers = [
    'unforeseen' => 0,
    'design' => 0,
    'management' => 0,
    'consultancy' => 0
];

foreach ($buildings as $building) {
    $buildingSummary = [
        'name' => $building['name'],
        'groups' => []
    ];

    foreach ($building['tree'] as $group) {
        $groupRow = [
            'name' => t($group['name'], $translations),
            'buckets' => ['<1' => 0, '1-2' => 0, '3-5' => 0, '6-10' => 0],
            'children' => []
        ];

        foreach ($group['children'] as $child) {
            // Use pre-calculated buckets from get_project_data_batch
            $cb = $child['cost_buckets'] ?? ['0_1' => 0, '1_2' => 0, '3_5' => 0, '5_10' => 0];
            $buckets = [
                '<1'   => (float)$cb['0_1'],
                '1-2'  => (float)$cb['1_2'],
                '3-5'  => (float)$cb['3_5'],
                '6-10' => (float)$cb['5_10']
            ];

            $childRow = [
                'name' => t($child['name'], $translations),
                'buckets' => $buckets,
                'risk' => $child['risk_level'] ?? '',
                'description' => $child['description'] ?? '',
                'recommendation' => $child['recommendation'] ?? '',
                'media' => $child['media'] ?? [],
                'is_bcl' => $child['is_bcl'] ?? 0,
                'quantity' => $child['quantity'] ?? '',
                'unit' => $child['unit'] ?? 'stk',
                'id' => $child['id'],
                'budget_items' => $child['budget_items'] ?? []
            ];

            foreach ($buckets as $k => $v) {
                $groupRow['buckets'][$k] += $v;
                $totalBuckets[$k] += $v;
                $totalBuckets['total'] += $v;
            }
            $groupRow['children'][] = $childRow;
        }
        $buildingSummary['groups'][] = $groupRow;
    }
    $summaryData[] = $buildingSummary;
}
?>
<!DOCTYPE html>
<html lang="da">
<head>
    <meta charset="UTF-8">
    <title>Tilstandsoversigt - <?= htmlspecialchars($project['name']) ?></title>
    <style>
        :root {
            --primary: #3b82f6;
            --primary-dark: #1e40af;
            --gray-50: #f8fafc;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-600: #475569;
            --gray-800: #1e293b;
            --gray-900: #0f172a;
        }

        @page {
            size: A4 landscape;
            margin: 1.5cm;
        }

        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            font-size: 9pt;
            line-height: 1.4;
            color: var(--gray-800);
            margin: 0;
            background: #cbd5e1;
            padding: 20px;
        }

        .page {
            background: white;
            margin: 0 auto 30px auto;
            padding: 1.5cm;
            width: 26.7cm; /* A4 Landscape (297) - margins */
            min-height: 18cm;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            border-radius: 4px;
            position: relative;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            border-bottom: 2px solid var(--primary);
            padding-bottom: 1rem;
            margin-bottom: 1.5rem;
        }

        .header-title h1 {
            font-size: 18pt;
            margin: 0;
            color: var(--gray-900);
            font-weight: 800;
        }

        .header-title p {
            font-size: 10pt;
            color: var(--gray-600);
            margin: 0.25rem 0 0 0;
        }

        .header-meta {
            text-align: right;
            font-size: 8pt;
            color: var(--gray-500);
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 8pt;
        }

        th {
            background: var(--gray-100);
            color: var(--gray-900);
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.025em;
            padding: 6px 8px;
            border: 1px solid var(--gray-200);
        }

        td {
            padding: 6px 8px;
            border: 1px solid var(--gray-200);
            vertical-align: top;
        }

        .group-row {
            background: var(--gray-50);
            font-weight: 700;
            color: var(--primary-dark);
        }

        .num-cell {
            text-align: right;
            font-family: 'JetBrains Mono', 'Monaco', monospace;
            font-variant-numeric: tabular-nums;
        }

        .checkbox-cell {
            text-align: center;
            font-size: 10pt;
            line-height: 1;
        }

        .marker-text {
            font-weight: 800;
            color: var(--primary);
            text-align: center;
        }

        .detail-img {
            width: 80px;
            height: 60px;
            object-fit: cover;
            border-radius: 4px;
            border: 1px solid var(--gray-200);
            margin: 2px;
        }

        .footer {
            margin-top: 20px;
            text-align: center;
            font-size: 7pt;
            color: var(--gray-400);
        }

        @media print {
            body { background: white; padding: 0; }
            .page { margin: 0; box-shadow: none; border-radius: 0; width: 100%; page-break-after: always; }
            .no-print { display: none; }
        }

        .btn-print {
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--primary);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            z-index: 1000;
        }
    </style>
</head>
<body>

    <button class="btn-print no-print" onclick="window.print()">Print / PDF</button>

    <!-- PAGE 1: SUMMARY -->
    <div class="page">
        <div class="header-section">
            <div class="header-title">
                <h1>3. Building elements overview</h1>
                <p>Project: <?= htmlspecialchars($project['name']) ?></p>
            </div>
            <div class="header-meta">
                Generated: <?= date('d.m.Y H:i') ?><br>
                Summary View (A4 Landscape)
            </div>
        </div>

        <?php if (!empty($report_config['introduction'])): ?>
        <div style="margin-bottom: 1.5rem; padding: 1rem; background: var(--gray-50); border-radius: 4px; font-size: 10pt;">
            <h3 style="margin-top: 0; font-size: 11pt; color: var(--primary-dark);">Indledning</h3>
            <?= nl2br(htmlspecialchars($report_config['introduction'])) ?>
        </div>
        <?php endif; ?>

        <?php if (!empty($report_config['weather']) || !empty($report_config['disclaimers']) || !empty($report_config['photo_info'])): ?>
        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem; margin-bottom: 1.5rem; font-size: 8pt;">
            <?php if (!empty($report_config['weather'])): ?>
            <div style="padding: 0.75rem; border: 1px solid var(--gray-200); border-radius: 4px;">
                <strong style="display: block; margin-bottom: 4px; color: var(--gray-600);">VEJRFORHOLD</strong>
                <?= nl2br(htmlspecialchars($report_config['weather'])) ?>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($report_config['disclaimers'])): ?>
            <div style="padding: 0.75rem; border: 1px solid var(--gray-200); border-radius: 4px;">
                <strong style="display: block; margin-bottom: 4px; color: var(--gray-600);">GENERELLE FORBEHOLD</strong>
                <?= nl2br(htmlspecialchars($report_config['disclaimers'])) ?>
            </div>
            <?php endif; ?>

            <?php if (!empty($report_config['photo_info'])): ?>
            <div style="padding: 0.75rem; border: 1px solid var(--gray-200); border-radius: 4px;">
                <strong style="display: block; margin-bottom: 4px; color: var(--gray-600);">FOTODOKUMENTATION</strong>
                <?= nl2br(htmlspecialchars($report_config['photo_info'])) ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th rowspan="2" style="text-align:left; width:22%;">Bygningsdele</th>
                    <th colspan="4">Tidsmæssig fordeling</th>
                    <th colspan="5">Overslag (DKK ekskl. moms)</th>
                </tr>
                <tr style="font-size:7pt;">
                    <th style="width:9%;">Enhed < 1 år</th>
                    <th style="width:9%;">1-2 år</th>
                    <th style="width:9%;">3-5 år</th>
                    <th style="width:9%;">6-10 år</th>
                    <th style="width:10%;">Entreprenør</th>
                    <th style="width:8%;">Uforudset (<?= $unforeseenPct ?>%)</th>
                    <th style="width:8%;">Projektering (<?= $designPct ?>%)</th>
                    <th style="width:8%;">Ledelse (<?= $managementPct ?>%)</th>
                    <th style="width:8%;">Rådgivning (<?= $consultancyPct ?>%)</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $grandTotalContractor = 0;
                $bIdx = 1;
                foreach ($summaryData as $bSummary):
                    ?>
                    <tr style="background:var(--gray-800); color:white; font-weight:800;">
                        <td colspan="10" style="text-align:left; font-size:10pt;">Bygning: <?= htmlspecialchars($bSummary['name']) ?></td>
                    </tr>
                    <?php
                    $gIdx = 1;
                    foreach ($bSummary['groups'] as $grp):
                        $grpContractor = array_sum($grp['buckets']);
                        $grandTotalContractor += $grpContractor;
                        ?>
                        <tr class="group-row">
                            <td style="text-align:left;"><?= $gIdx ?>. <?= htmlspecialchars($grp['name']) ?></td>
                            <td class="num-cell"><?= $grp['buckets']['<1'] > 0 ? number_format($grp['buckets']['<1'], 0, ',', '.') . ' kr.' : '-' ?></td>
                            <td class="num-cell"><?= $grp['buckets']['1-2'] > 0 ? number_format($grp['buckets']['1-2'], 0, ',', '.') . ' kr.' : '-' ?></td>
                            <td class="num-cell"><?= $grp['buckets']['3-5'] > 0 ? number_format($grp['buckets']['3-5'], 0, ',', '.') . ' kr.' : '-' ?></td>
                            <td class="num-cell"><?= $grp['buckets']['6-10'] > 0 ? number_format($grp['buckets']['6-10'], 0, ',', '.') . ' kr.' : '-' ?></td>
                            <td class="num-cell" style="background:rgba(59, 130, 246, 0.05);"><?= $grpContractor > 0 ? number_format($grpContractor, 0, ',', '.') . ' kr.' : '-' ?></td>
                            <td class="num-cell"><?= $unforeseenPct > 0 ? number_format($grpContractor * ($unforeseenPct/100), 0, ',', '.') . ' kr.' : '-' ?></td>
                            <td class="num-cell"><?= $designPct > 0 ? number_format($grpContractor * ($designPct/100), 0, ',', '.') . ' kr.' : '-' ?></td>
                            <td class="num-cell"><?= $managementPct > 0 ? number_format($grpContractor * ($managementPct/100), 0, ',', '.') . ' kr.' : '-' ?></td>
                            <td class="num-cell"><?= $consultancyPct > 0 ? number_format($grpContractor * ($consultancyPct/100), 0, ',', '.') . ' kr.' : '-' ?></td>
                        </tr>
                        <?php $subIdx = 1;
                        foreach ($grp['children'] as $child):
                            $childContractor = array_sum($child['buckets']);
                            ?>
                            <tr>
                                <td style="padding-left: 20px; color: var(--gray-600);"><?= $gIdx ?>.<?= $subIdx ?> <?= htmlspecialchars($child['name']) ?></td>
                                <td class="num-cell"><?= $child['buckets']['<1'] > 0 ? number_format($child['buckets']['<1'], 0, ',', '.') . ' kr.' : '-' ?></td>
                                <td class="num-cell"><?= $child['buckets']['1-2'] > 0 ? number_format($child['buckets']['1-2'], 0, ',', '.') . ' kr.' : '-' ?></td>
                                <td class="num-cell"><?= $child['buckets']['3-5'] > 0 ? number_format($child['buckets']['3-5'], 0, ',', '.') . ' kr.' : '-' ?></td>
                                <td class="num-cell"><?= $child['buckets']['6-10'] > 0 ? number_format($child['buckets']['6-10'], 0, ',', '.') . ' kr.' : '-' ?></td>
                                <td class="num-cell" style="background:rgba(241, 245, 249, 0.5);"><?= $childContractor > 0 ? number_format($childContractor, 0, ',', '.') . ' kr.' : '-' ?></td>
                                <td class="num-cell">0%</td>
                                <td class="num-cell">0%</td>
                                <td class="num-cell">0%</td>
                                <td class="num-cell">0%</td>
                            </tr>
                            <?php $subIdx++; endforeach; ?>
                        <?php $gIdx++; endforeach; ?>
                <?php $bIdx++; endforeach; ?>
                <tr style="background:var(--gray-900); color:white; font-weight:700;">
                    <td>TOTAL (Project)</td>
                    <td class="num-cell"><?= number_format($totalBuckets['<1'], 0, ',', '.') ?> kr.</td>
                    <td class="num-cell"><?= number_format($totalBuckets['1-2'], 0, ',', '.') ?> kr.</td>
                    <td class="num-cell"><?= number_format($totalBuckets['3-5'], 0, ',', '.') ?> kr.</td>
                    <td class="num-cell"><?= number_format($totalBuckets['6-10'], 0, ',', '.') ?> kr.</td>
                    <td class="num-cell" style="background:var(--primary-dark);"><?= number_format($grandTotalContractor, 0, ',', '.') ?> kr.</td>
                    <td class="num-cell"><?= number_format($grandTotalContractor * ($unforeseenPct/100), 0, ',', '.') ?> kr.</td>
                    <td class="num-cell"><?= number_format($grandTotalContractor * ($designPct/100), 0, ',', '.') ?> kr.</td>
                    <td class="num-cell"><?= number_format($grandTotalContractor * ($managementPct/100), 0, ',', '.') ?> kr.</td>
                    <td class="num-cell"><?= number_format($grandTotalContractor * ($consultancyPct/100), 0, ',', '.') ?> kr.</td>
                </tr>
                <tr style="background:var(--primary-600); color:white; font-weight:800; font-size:11pt;">
                    <td colspan="5">TOTAL BUDGET (Inkl. tillæg)</td>
                    <td colspan="5" style="text-align:right; padding-right:1rem;">
                        <?php 
                        $totalWithFees = $grandTotalContractor * (1 + ($unforeseenPct + $designPct + $managementPct + $consultancyPct)/100);
                        echo number_format($totalWithFees, 0, ',', '.') . ' kr.';
                        ?>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- PAGE 2+: DETAILS -->
    <div class="page">
        <div class="header-section">
            <div class="header-title">
                <h1>Detailed Elements Analysis</h1>
                <p>Project: <?= htmlspecialchars($project['name']) ?></p>
            </div>
        </div>

        <table>
            <thead>
                <tr>
                    <th rowspan="2" style="width: 14%;">Kategori</th>
                    <th rowspan="2" style="width: 20%;">Beskrivelse</th>

                    <th rowspan="2" style="width: 16%;">Billeddokumentation</th>
                    <th rowspan="2" style="width: 16%;">Anbefaling / Bemærkninger</th>
                    <th rowspan="2" style="width: 10%;">Mængde</th>
                    <th colspan="5">Risiko</th>
                    <th colspan="4">Kategorisering</th>
                </tr>
                <tr style="font-size:7pt;">
                    <th title="Red">🔴</th>
                    <th title="Yellow">🟡</th>
                    <th title="Black">⚫️</th>
                    <th title="Green">🟢</th>
                    <th title="Blue">🔵</th>
                    <th>< 1</th>
                    <th>1-2</th>
                    <th>3-5</th>
                    <th>6-10</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($summaryData as $bSummary):
                    ?>
                    <tr style="background:var(--gray-800); color:white; font-weight:800;">
                        <td colspan="14" style="font-size:10pt; letter-spacing:0.05em;">Bygning: <?= htmlspecialchars($bSummary['name']) ?></td>
                    </tr>
                    <?php
                    $gCounter = 1;
                    foreach ($bSummary['groups'] as $group):
                        ?>
                        <tr class="group-row">
                            <td colspan="14" style="font-size:10pt; letter-spacing:0.05em;"><?= $gCounter ?>. <?= htmlspecialchars($group['name']) ?></td>
                        </tr>
                        <?php
                        $cCounter = 1;
                        foreach ($group['children'] as $child):
                            $marker = ($child['is_bcl'] == 1) ? 'BCL' : 'X';
                            $t1 = ($child['buckets']['<1'] > 0) ? $marker : '';
                            $t2 = ($child['buckets']['1-2'] > 0) ? $marker : '';
                            $t3 = ($child['buckets']['3-5'] > 0) ? $marker : '';
                            $t4 = ($child['buckets']['6-10'] > 0) ? $marker : '';
                            ?>
                            <tr>
                                <td>
                                    <strong><?= $gCounter ?>.<?= $cCounter ?> <?= htmlspecialchars($child['name']) ?></strong>
                                </td>
                                <td style="font-size:7.5pt;">
                                    <?php if (!empty($child['description'])): ?>
                                        <strong>Obs:</strong> <?= nl2br(htmlspecialchars($child['description'])) ?><br>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align:center;">
                                    <?php 
                                    $localFigIdx = 1;
                                    foreach ($child['media'] as $img): 
                                    ?>
                                        <div style="margin-bottom: 5px;">
                                            <img src="<?= get_image_url($img['file_path']) ?>?t=<?= time() ?>" class="detail-img">
                                            <div style="font-size: 6pt; color: #64748b; font-style: italic;">
                                                Fig. <?= $gCounter ?>.<?= $cCounter ?>.<?= $localFigIdx++ ?>: <?= htmlspecialchars($img['caption'] ?? $child['name']) ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </td>
                                <td style="font-size:7.5pt;"><?= nl2br(htmlspecialchars($child['recommendation'])) ?></td>
                                <td style="font-size:7.5pt;">
                                    <?php 
                                    // 1. Show detailed budget items if they exist
                                    if (!empty($child['budget_items'])) {
                                        foreach ($child['budget_items'] as $bi) {
                                            $bQty = (float)($bi['quantity'] ?? 0);
                                            if ($bQty > 0) {
                                                echo '<div>';
                                                if (!empty($bi['description'])) {
                                                    echo htmlspecialchars($bi['description']) . ' ';
                                                }
                                                echo number_format($bQty, 2, ',', '.') . ' ' . htmlspecialchars($bi['unit'] ?? 'stk');
                                                echo '</div>';
                                            }
                                        }
                                    } 
                                    // 2. Fallback to Element Quantity if no budget items (or if you want both, remove 'else')
                                    elseif ($child['quantity'] > 0) {
                                        echo number_format((float)$child['quantity'], 2, ',', '.') . ' ' . htmlspecialchars($child['unit']);
                                    }
                                    ?>
                                </td>

                                <?php 
                                $risk = $child['risk'] ?? '';
                                $r = strpos($risk, 'Rød') !== false ? '☒' : '☐';
                                $y = strpos($risk, 'Gul') !== false ? '☒' : '☐';
                                $g = strpos($risk, 'Grøn') !== false ? '☒' : '☐';
                                $blk = strpos($risk, 'Sort') !== false ? '☒' : '☐';
                                $b = strpos($risk, 'Blå') !== false ? '☒' : '☐';

                                // Format values for display (replace markers with prices)
                                $fmt = function($val) {
                                    return $val > 0 ? number_format($val, 0, ',', '.') : '';
                                };
                                $t1 = $fmt($child['buckets']['<1']);
                                $t2 = $fmt($child['buckets']['1-2']);
                                $t3 = $fmt($child['buckets']['3-5']);
                                $t4 = $fmt($child['buckets']['6-10']);
                                ?>
                                <td class="checkbox-cell" style="color:#ef4444;"><?= $r ?></td>
                                <td class="checkbox-cell" style="color:#f59e0b;"><?= $y ?></td>
                                <td class="checkbox-cell" style="color:#1e293b;"><?= $blk ?></td>
                                <td class="checkbox-cell" style="color:#10b981;"><?= $g ?></td>
                                <td class="checkbox-cell" style="color:#3b82f6;"><?= $b ?></td>

                                <td class="num-cell" style="font-size: 8pt;"><?= $t1 ?></td>
                                <td class="num-cell" style="font-size: 8pt;"><?= $t2 ?></td>
                                <td class="num-cell" style="font-size: 8pt;"><?= $t3 ?></td>
                                <td class="num-cell" style="font-size: 8pt;"><?= $t4 ?></td>
                            </tr>
                            <?php
                            $cCounter++;
                        endforeach;
                        $gCounter++;
                    endforeach;
                endforeach;
                ?>
            </tbody>
        </table>
        
        <div class="footer">
            Design System Standard Reporting &copy; <?= date('Y') ?> Bjerg Arkitekter. All rates excluding VAT.
        </div>
    </div>

</body>
</html>
