<!DOCTYPE html>
<html lang="da">
<head>
    <meta charset="UTF-8">
    <title>Budgetoversigt - <?php echo $project['name']; ?></title>
    <style>
        @page {
            size: A4 landscape;
            margin: 1.5cm;
        }
        @media print {
            .no-print { display: none; }
            * { -webkit-print-color-adjust: exact; }
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 9pt;
            line-height: 1.3;
            color: #333;
            margin: 0;
            padding: 0;
        }
        h1 { margin: 0; color: #1e40af; font-size: 16pt; }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #3b82f6;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th {
            background-color: #f1f5f9;
            text-align: left;
            padding: 8px;
            border: 1px solid #e2e8f0;
            color: #475569;
        }
        td {
            padding: 8px;
            border: 1px solid #e2e8f0;
        }
        .price { text-align: right; font-family: monospace; }
        .building-row {
            background-color: #f8fafc;
            font-weight: bold;
            color: #1e40af;
        }
        .element-name { font-weight: 600; }
        
        .footer {
            margin-top: 30px;
            text-align: right;
            font-size: 8pt;
            color: #94a3b8;
        }
        .btn-print {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #10b981;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            z-index: 1000;
        }
        .total-row {
            font-weight: bold;
            background: #eff6ff;
        }
    </style>
</head>
<body>
    <button class="btn-print no-print" onclick="window.print()">Udskriv Budget</button>

    <div class="header">
        <div>
            <h1><?php echo $report_title; ?></h1>
            <p>Projekt: <?php echo $project['name']; ?></p>
        </div>
        <div style="text-align: right;">
            Dato: <?php echo $report_date; ?>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th style="width: 25%;">Beskrivelse</th>
                <th style="width: 5%;">Mængde</th>
                <th style="width: 5%;">Enhed</th>
                <th style="width: 10%;" class="price">Enhedspris</th>
                <th style="width: 10%;" class="price">0-1 år</th>
                <th style="width: 10%;" class="price">1-2 år</th>
                <th style="width: 10%;" class="price">3-5 år</th>
                <th style="width: 10%;" class="price">5-10 år</th>
                <th style="width: 15%;" class="price">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $currentBuilding = '';
            $totals = ['t01' => 0, 't12' => 0, 't35' => 0, 't510' => 0, 'grand' => 0];
            
            foreach ($items as $item): 
                if ($currentBuilding != $item['building_name']):
                    $currentBuilding = $item['building_name'];
            ?>
                <tr class="building-row">
                    <td colspan="9">Bygning: <?php echo $currentBuilding; ?></td>
                </tr>
            <?php endif; ?>
                <tr>
                    <td>
                        <div class="element-name"><?php echo $item['element_name']; ?></div>
                        <div style="font-size: 8pt; color: #64748b;"><?php echo $item['description']; ?></div>
                    </td>
                    <td><?php echo number_format($item['quantity'], 2, ',', '.'); ?></td>
                    <td><?php echo $item['unit']; ?></td>
                    <td class="price"><?php echo number_format($item['unit_price'], 2, ',', '.'); ?></td>
                    <td class="price"><?php echo number_format($item['amount_0_1'], 2, ',', '.'); ?></td>
                    <td class="price"><?php echo number_format($item['amount_1_2'], 2, ',', '.'); ?></td>
                    <td class="price"><?php echo number_format($item['amount_3_5'], 2, ',', '.'); ?></td>
                    <td class="price"><?php echo number_format($item['amount_5_10'], 2, ',', '.'); ?></td>
                    <td class="price"><?php echo number_format($item['total_calculated'], 2, ',', '.'); ?></td>
                </tr>
            <?php 
                $totals['t01'] += $item['amount_0_1'];
                $totals['t12'] += $item['amount_1_2'];
                $totals['t35'] += $item['amount_3_5'];
                $totals['t510'] += $item['amount_5_10'];
                $totals['grand'] += $item['total_calculated'];
            endforeach; ?>
            
            <tr class="total-row">
                <td colspan="4" style="text-align: right;">TOTALER SAMLET:</td>
                <td class="price"><?php echo number_format($totals['t01'], 2, ',', '.'); ?></td>
                <td class="price"><?php echo number_format($totals['t12'], 2, ',', '.'); ?></td>
                <td class="price"><?php echo number_format($totals['t35'], 2, ',', '.'); ?></td>
                <td class="price"><?php echo number_format($totals['t510'], 2, ',', '.'); ?></td>
                <td class="price"><?php echo number_format($totals['grand'], 2, ',', '.'); ?></td>
            </tr>
        </tbody>
    </table>

    <div class="footer">
        Genereret af DueDiligence System &copy; <?php echo date('Y'); ?>
    </div>
</body>
</html>
