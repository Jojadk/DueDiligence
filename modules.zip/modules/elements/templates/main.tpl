<div class="dd-page-toolbar">
    <div class="toolbar-left">
        <!-- Project name moved to global header -->
    </div>
    <div class="toolbar-center">
        <!-- Optional: Center content like search or global navigation -->
    </div>
    <div class="toolbar-right">
        <div class="dd-dropdown">
             <button class="dd-btn dd-btn-ghost">
                <i class="fas fa-ellipsis-v icon-placeholder"></i> 
                <span class="btn-label">Handlinger</span>
                <i class="fas fa-chevron-down dd-chevron"></i>
            </button>
            <div class="dd-dropdown-menu">
                <a href="javascript:void(0)" class="dropdown-item" onclick="App.elements.openBuildingManager()"><i class="fas fa-plus"></i> Opret Bygning</a>
                <a href="javascript:void(0)" class="dropdown-item" onclick="App.elements.openVersionHistory()"><i class="fas fa-history"></i> Versioner</a>
                <div class="dropdown-divider"></div>
                <div class="dropdown-section-header">Rapportering</div>
                <a href="javascript:void(0)" class="dropdown-item" onclick="App.elements.generateReport('portrait')">
                    <svg class="dropdown-item-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg> Tilstandsrapport (A4)
                </a>
                <a href="javascript:void(0)" class="dropdown-item" onclick="App.elements.generateReport('full')">
                    <svg class="dropdown-item-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg> Full Report (Interaktiv)
                </a>
                <a href="javascript:void(0)" class="dropdown-item" onclick="App.elements.generateReport('light')">
                    <svg class="dropdown-item-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="20" x2="12" y2="10"></line><line x1="18" y1="20" x2="18" y2="4"></line><line x1="6" y1="20" x2="6" y2="16"></line></svg> Light Report (Excel)
                </a>
                <a href="javascript:void(0)" class="dropdown-item" onclick="App.elements.generateReport('summary')">
                    <i class="fas fa-file-invoice"></i> Tilstandsoversigt (A4)
                </a>
                <a href="javascript:void(0)" class="dropdown-item" onclick="App.elements.generateReport('landscape')">
                    <svg class="dropdown-item-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg> Budgetoversigt (A4)
                </a>
                <div class="dropdown-divider"></div>
                <div class="dropdown-section-header">Værktøjer</div>
                <a href="javascript:void(0)" class="dropdown-item" onclick="App.elements.openTemplateModal()"><i class="fas fa-layer-group"></i> Skabeloner</a>
                <a href="javascript:void(0)" class="dropdown-item" onclick="App.elements.deleteCurrentElement()" style="color: #dc2626;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:8px;"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                    Slet element
                </a>
                <a href="javascript:void(0)" class="dropdown-item" onclick="App.elements.openToolsMenu()"><i class="fas fa-tools"></i> Værktøjer</a>
            </div>
        </div>
    </div>
</div>

<div class="dd-layout-split">
    <!-- Sidebar: Tree Navigation -->
    <aside id="tree-sidebar" class="dd-sidebar">
        <div class="dd-sidebar-header">
         <div class="project-header-selector" onclick="App.elements.toggleProjectSelector(this)">
            <div class="selector-info">
                <span class="selector-label">Vælg Projekt</span>
                <div id="sidebar-project-name" class="selector-project">Ingen projekt valgt</div>
            </div>
            <i class="fas fa-chevron-down"></i>
         </div>
         <div class="search-wrapper">
            <i class="fas fa-search search-icon"></i>
            <input type="text" id="tree-search" class="dd-sidebar-search" placeholder="Søg..." oninput="App.elements.filterTree(this.value)">
        </div>
    </div>
        <div id="tree-container" class="dd-sidebar-content tree-container" 
             data-behavior="drag-drop" 
             data-dd-handle=".tree-content" 
             data-dd-item=".dd-tree-node"
             data-dd-callback="App.elements.handleTreeDrop">
            <!-- Tree rendered here -->
            <div class="empty-tree-state">
                <p>Ingen bygningsdele fundet</p>
            </div>
        </div>
        <div class="dd-sidebar-footer">
             <button class="dd-btn dd-btn-secondary dd-btn-block" onclick="App.elements.openNewSectionModal()">
                <i class="fas fa-plus"></i> <span class="btn-label">Nyt Afsnit</span>
            </button>
        </div>
    </aside>

    <!-- Main Content -->
    <main id="content-area" class="dd-content">
        <!-- Empty State -->
        <div id="empty-state" class="dd-empty-state">
             <div class="empty-icon"><i class="fas fa-cube"></i></div>
             <h3>Vælg en bygningsdel</h3>
             <p>Klik på en bygningsdel i venstre side for at se detaljer.</p>
        </div>

        <!-- Detail View (Initially Hidden) -->
        <div id="element-detail-view" style="display: none;">
            
            <!-- Breadcrumbs -->
            <div class="dd-breadcrumbs" id="element-breadcrumbs">
                <!-- Project > Building > Element -->
            </div>

            <!-- Header -->
            <div class="dd-element-header">
                <div class="header-main" style="display:flex; align-items:center; width:100%; gap:10px;">
                    <input type="text" id="element-name-input" class="dd-input-title" placeholder="Navn på bygningsdel..." 
                           oninput="App.elements.autoSave('name', this.value)"
                           onblur="App.elements.saveField('name', this.value)">
                    
                    <!-- Comment Trigger -->
                    <div id="admin-comment-trigger" class="admin-comment-trigger" style="display:none;" title="Se interne noter">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                        </svg>
                        <span id="admin-comment-badge" class="admin-comment-badge" style="display:none;">0</span>
                    </div>
                </div>
                <div class="header-meta">
                   <!-- Meta info moved to ribbon -->
                </div>
            </div>

            <!-- Ratings Ribbon (3 Cols) -->
            <div class="dd-ratings-ribbon">
                <div class="rating-ribbon-item">
                    <span class="rating-header-label">Risiko</span>
                    <div id="risk-multi-select-container" class="risk-multi-select" title="Risici">
                        <div class="add-risk-btn" onclick="App.elements.toggleRiskDropdown(event)">
                            <i class="fas fa-plus"></i>
                        </div>
                    </div>
                </div>
                <div class="rating-ribbon-item">
                     <span class="rating-header-label">Tilstand</span>
                     <div id="condition-multi-select-container" class="risk-multi-select" title="Tilstandsvurdering">
                         <div class="add-risk-btn add-condition-btn" onclick="App.elements.toggleConditionDropdown(event)">
                            <i class="fas fa-plus"></i>
                        </div>
                    </div>
                </div>
                <div class="rating-ribbon-item">
                     <span class="rating-header-label">Kvalitet</span>
                     <div id="quality-multi-select-container" class="risk-multi-select" title="Kvalitetsvurdering">
                         <div class="add-risk-btn add-quality-btn" onclick="App.elements.toggleQualityDropdown(event)">
                            <i class="fas fa-plus"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Content Grid 2 Col -->
            <div class="dd-grid-2col">
                <!-- Observation -->
                <div class="dd-form-section">
                    <label class="dd-label">OBSERVATION</label>
                    <textarea id="field-description" class="dd-textarea-auto" placeholder="Beskriv observationen..."
                              oninput="App.elements.autoSave('description', this.value)"
                              onblur="App.elements.saveField('description', this.value)"></textarea>
                </div>

                <!-- Recommendation -->
                <div class="dd-form-section">
                    <label class="dd-label">ANBEFALING</label>
                    <textarea id="field-recommendation" class="dd-textarea-auto" placeholder="Anbefalet handling..."
                              oninput="App.elements.autoSave('recommendation', this.value)"
                              onblur="App.elements.saveField('recommendation', this.value)"></textarea>
                </div>
            </div>

            <!-- Economy Section (Full Width, Lighter) -->
            <div class="dd-section-light">
                <div class="dd-section-header" style="align-items: center;">
                    <div style="display:flex; align-items:center; gap:15px;">
                        <h4 style="margin:0;">Økonomi & Levetid</h4>
                        <!-- Rounding Controls -->
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <select id="element-rounding-override" class="dd-select-sm" 
                                    onchange="App.elements.updateElementRounding(this.value)"
                                    style="padding: 4px 8px; border: 1px solid #ddd; border-radius: 4px; font-size: 11px;">
                                <option value="">Projekt standard</option>
                                <option value="0.00">0,00</option>
                                <option value="100.00">100</option>
                                <option value="1000.00">1.000</option>
                                <option value="10000.00">10.000</option>
                                <option value="100000.00">100.000</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="dd-switch-wrapper">
                        <label class="dd-toggle-switch">
                            <input type="checkbox" id="field-is_bcl" onchange="App.elements.saveField('is_bcl', this.checked ? 1 : 0)">
                            <span class="dd-toggle-slider"></span>
                            <span class="dd-toggle-label">BCL</span>
                        </label>
                    </div>
                </div>
                <div class="dd-economy-grid">
                    <!-- CAPEX Input -->
                    <div class="economy-item capex-box">
                        <label>CAPEX (DKK)</label>
                        <div class="input-group">
                            <input type="text" id="field-capex" class="dd-input-lg" placeholder="0,00"
                                   onblur="App.elements.saveField('capex', this.value)">
                            <button class="dd-toolbar-btn btn-budget" onclick="App.elements.openBudgetModal()">
                                <i class="fas fa-calculator"></i>
                                <span>Budget & Økonomi</span>
                            </button>
                        </div>
                    </div>
                    
                    <!-- Time Buckets (Read Only) -->
                    <div class="economy-item bucket-item">
                        <span class="bucket-label">&lt;1 år</span>
                        <strong class="bucket-value" id="sum-0-1">0,00</strong>
                    </div>
                    <div class="economy-item bucket-item">
                        <span class="bucket-label">1-2 år</span>
                        <strong class="bucket-value" id="sum-1-2">0,00</strong>
                    </div>
                    <div class="economy-item bucket-item">
                        <span class="bucket-label">3-5 år</span>
                        <strong class="bucket-value" id="sum-3-5">0,00</strong>
                    </div>
                    <div class="economy-item bucket-item">
                        <span class="bucket-label">5-10 år</span>
                        <strong class="bucket-value" id="sum-5-10">0,00</strong>
                    </div>
                </div>
            </div>

            <!-- AI Assessment Section -->
            <style>
                .dd-section-ai {
                    background: #fdf2f8;
                    border: 1px solid #fbcfe8;
                    border-radius: 12px;
                    padding: 1.5rem;
                    margin-bottom: 2rem;
                }
                .ai-toggle-header {
                    cursor: pointer;
                    user-select: none;
                }
                .ai-toggle-header:hover {
                    opacity: 0.8;
                }
                .ai-chevron {
                    transition: transform 0.3s ease;
                }
                .ai-toggle-header.collapsed .ai-chevron {
                    transform: rotate(-90deg);
                }
                /* Font fix for material icons */
                .material-icons {
                    font-family: 'Material Icons' !important;
                    font-weight: normal;
                    font-style: normal;
                    line-height: 1;
                    letter-spacing: normal;
                    text-transform: none;
                    display: inline-block;
                    white-space: nowrap;
                    word-wrap: normal;
                    direction: ltr;
                    -webkit-font-feature-settings: 'liga';
                    -webkit-font-smoothing: antialiased;
                }
                .ai-result-text {
                    font-size: 0.9rem;
                    line-height: 1.6;
                    color: #1e293b;
                    white-space: pre-wrap;
                }
                .ai-result-text h1, .ai-result-text h2, .ai-result-text h3 { color: #9d174d; margin-top: 1rem; margin-bottom: 0.5rem; }
                .ai-meta {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 1.5rem;
                    font-size: 0.75rem;
                    color: #be185d;
                    font-weight: 700;
                    text-transform: uppercase;
                    border-bottom: 2px solid #fce7f3;
                    padding-bottom: 0.75rem;
                }
                .ai-structured-results {
                    display: flex;
                    flex-direction: column;
                    gap: 1.5rem;
                }
                .ai-result-row {
                    background: white;
                    border-radius: 8px;
                    padding: 1rem;
                    border: 1px solid #f9a8d450;
                    box-shadow: 0 1px 3px rgba(0,0,0,0.02);
                }
                .ai-result-label {
                    display: flex;
                    align-items: center;
                    gap: 6px;
                    font-size: 0.7rem;
                    font-weight: 800;
                    color: #9d174d;
                    margin-bottom: 0.75rem;
                    text-transform: uppercase;
                    letter-spacing: 0.05em;
                }
                .ai-transfer-btn {
                    margin-left: auto;
                    background: #fdf2f8;
                    border: 1px solid #fbcfe8;
                    color: #be185d;
                    padding: 2px 8px;
                    border-radius: 4px;
                    font-size: 0.65rem;
                    font-weight: 700;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    gap: 4px;
                    transition: all 0.2s;
                    text-transform: none;
                }
                .ai-transfer-btn:hover {
                    background: #be185d;
                    color: white;
                    border-color: #be185d;
                }
                .ai-result-value {
                    font-size: 0.875rem;
                    color: #334155;
                    line-height: 1.6;
                }
                .ai-result-item {
                    flex: 1;
                    min-width: 150px;
                }
                .ai-badge-list {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 6px;
                }
                .ai-flag-badge {
                    background: #fef2f2;
                    color: #dc2626;
                    border: 1px solid #fee2e2;
                    padding: 2px 8px;
                    border-radius: 4px;
                    font-size: 0.75rem;
                    font-weight: 600;
                }
                .ai-condition-badge {
                    display: inline-block;
                    padding: 4px 12px;
                    border-radius: 20px;
                    font-size: 0.8rem;
                    font-weight: 700;
                    text-transform: uppercase;
                }
                .ai-condition-badge[data-condition="God"] { background: #dcfce7; color: #166534; }
                .ai-condition-badge[data-condition="Fornuftig"] { background: #dbeafe; color: #1e40af; }
                .ai-condition-badge[data-condition="Acceptabel"] { background: #fef9c3; color: #854d0e; }
                .ai-condition-badge[data-condition="Forventet"] { background: #f1f5f9; color: #475569; }
                .ai-condition-badge[data-condition="Dårlig"] { background: #fee2e2; color: #991b1b; }
            </style>
            <div id="ai-assessment-container" style="display: none;">
                <div class="dd-section-ai">
                    <div class="ai-meta ai-toggle-header" onclick="App.elements.toggleAI(this)">
                        <div style="display:flex; align-items:center; gap:8px;">
                            <span class="material-icons" style="font-size:18px;">psychology</span>
                            <span>AI Teknisk Vurdering</span>
                        </div>
                        <div style="display:flex; align-items:center; gap:10px;">
                            <div id="ai-date-label"></div>
                            <span class="material-icons ai-chevron" style="font-size:20px;">expand_more</span>
                        </div>
                    </div>
                    
                    <!-- Collapsible Content Wrapper -->
                    <div id="ai-content-wrapper" style="display:none;">
                        <div id="ai-assessment-text" class="ai-result-text"></div>
                        <div style="margin-top: 1.5rem; display: flex; gap: 1rem;">
                            <button class="dd-btn-primary dd-btn-sm" style="background: #db2777; border-color: #db2777;" onclick="App.elements.runAIAssessment()">
                                Genberegn Vurdering
                            </button>
                            <button class="dd-btn-secondary dd-btn-sm" onclick="App.elements.applyAIAssessmentToFields()">
                                Overfør til Observation/Anbefaling
                            </button>
                        </div>
                    </div>
                </div>
                <!-- Inline Script for Toggle -->
                <script>
                    if(!App) var App = {};
                    if(!App.elements) App.elements = {};
                    App.elements.toggleAI = function(header) {
                        const wrapper = document.getElementById('ai-content-wrapper');
                        const isHidden = wrapper.style.display === 'none';
                        wrapper.style.display = isHidden ? 'block' : 'none';
                        header.classList.toggle('collapsed', !isHidden);
                        
                        // Rotate chevron logic handled by class
                        const chevron = header.querySelector('.ai-chevron');
                        if(chevron) chevron.style.transform = isHidden ? 'rotate(0deg)' : 'rotate(-90deg)';
                    };
                </script>
            </div>
            
            <div id="ai-empty-container" style="margin-bottom: 2rem;">
                 <button class="dd-btn-secondary dd-btn-block" style="border-style: dashed; border-color: #fbcfe8; color: #db2777; background: #fff1f2;" onclick="App.elements.runAIAssessment()">
                    <span class="material-icons" style="margin-right: 8px;">auto_awesome</span>
                    Kør AI Teknisk Vurdering
                </button>
            </div>

            <!-- Gallery Section -->
            <div class="dd-form-section">
                <div class="section-header-row">
                    <label class="dd-label">BILLEDER</label>
                    <!-- <button class="btn-text">Administrer</button> -->
                </div>
                <div id="image-grid" class="dd-gallery-grid">
                    <!-- Add Button Card -->
                    <div class="gallery-card add-card" 
                         data-behavior="file-upload"
                         data-upload-url="api.php?module=elements&action=media_upload"
                         data-upload-multiple="true"
                         data-upload-callback="App.elements.refreshCurrentElement"
                         data-upload-data-element-id=""> <!-- ID injected by JS -->
                        <i class="fas fa-plus"></i>
                        <span>Tilføj billede</span>
                        <span class="sub-text">eller træk fil hertil</span>
                    </div>
                </div>
                <!-- Hidden Input removed (handled by behavior) -->
            </div>
            
            <div style="height: 100px;"></div> <!-- Spacer -->
        </div>
    </main>
</div>

<!-- Project Selector Modal (Hidden by default, triggered by JS) -->
<div id="project-selector-modal" class="dd-modal-overlay" style="display: none;">
    <div class="dd-modal-content">
        <!-- Content injected by JS -->
    </div>
</div>

<style>
:root {
    --sidebar-width: 300px;
    --toolbar-height: 60px;
    --bg-sidebar: #f8f9fa;
    --bg-content: #ffffff;
    --border-color: #e2e8f0;
    --text-primary: #1e293b;
    --text-secondary: #64748b;
}

/* Project Selector Dropdown */
.project-header-selector {
    position: relative;
}

.project-header-selector {
    margin-bottom: 1rem;
    cursor: pointer;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
    padding: 0.75rem 1rem;
    background: white;
    border: 1px solid var(--gray-200);
    border-radius: var(--radius-md);
    transition: all 0.2s;
    box-shadow: var(--shadow-sm);
}
.project-header-selector:hover {
    border-color: var(--primary-400);
    background: var(--blue-50);
}
.project-header-selector .selector-info {
    display: flex;
    flex-direction: column;
    overflow: hidden;
}
.project-header-selector .selector-label {
    font-size: 0.7rem;
    text-transform: uppercase;
    letter-spacing: 0.025em;
    color: var(--gray-500);
    font-weight: 600;
}
.project-header-selector .selector-project {
    font-size: 0.95rem;
    font-weight: 600;
    color: var(--gray-900);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 180px;
}
.project-header-selector i {
    font-size: 0.75rem;
    color: var(--gray-400);
}

/* Premium Tree Styling */
.dd-tree-node {
    position: relative;
    /* Cleaner spacing */
    margin: 1px 0;
}

.tree-content {
    display: flex;
    align-items: center;
    padding: 8px 12px;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.1s ease;
    border: 1px solid transparent;
}

.tree-content:hover {
    background: #f1f5f9;
}

.tree-content.active,
.dd-tree-node.active > .tree-content,
.dd-tree-node.selected > .tree-content {
    background-color: #dbeafe;
    border-left: 3px solid #3b82f6;
    color: #1e40af;
    font-weight: 600;
}

/* Fading Blue for Hierarchy */
/* Immediate Parent */
.dd-tree-node.active-parent > .tree-content {
    background-color: #eff6ff; /* Lighter blue */
    border-left: 3px solid #93c5fd;
    color: #1e3a8a;
}

/* Grandparent / Building */
.dd-tree-node.active-group > .tree-content {
    background-color: #f8fafc; /* Very light or just gray-blue tint */
    border-left: 3px solid #e2e8f0;
    color: #334155;
}

/* Ensure selected overrides others */
.tree-content.active,
.dd-tree-node.active > .tree-content {
    background-color: #dbeafe !important;
    border-left-color: #3b82f6 !important;
}

.tree-toggle {
    width: 20px;
    height: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 4px;
    border-radius: 4px;
    color: var(--gray-400);
    transition: background 0.2s;
}
.tree-toggle:hover {
    background: rgba(0,0,0,0.05);
    color: var(--gray-600);
}

.tree-number {
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.75rem;
    color: var(--gray-400);
    margin-right: 8px;
    opacity: 0.7;
}

/* Hierarchy Indentation Visuals */
.tree-children {
    padding-left: 22px; 
    border-left: 1px solid #e2e8f0;
    margin-left: 11px; /* Align with toggle center */
}

/* Drag & Drop Indicators - Clean & Sharp */
.dd-tree-node.drop-target-child > .tree-content {
    background-color: #eff6ff !important;
    box-shadow: inset 0 0 0 2px #3b82f6;
}

.dd-tree-node.drop-indicator-top::before {
    content: '';
    position: absolute;
    top: -4px;
    left: 4px;
    right: 4px;
    height: 3px;
    background: #3b82f6;
    border-radius: 2px;
    pointer-events: none;
    z-index: 10;
    box-shadow: 0 1px 2px rgba(59, 130, 246, 0.4);
}

.dd-tree-node.drop-indicator-bottom::after {
    content: '';
    position: absolute;
    bottom: -4px;
    left: 4px;
    right: 4px;
    height: 3px;
    background: #3b82f6;
    border-radius: 2px;
    pointer-events: none;
    z-index: 10;
    box-shadow: 0 1px 2px rgba(59, 130, 246, 0.4);
}

/* Risk Multi-select UI */
.risk-multi-select {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
    align-items: center;
    min-height: 38px;
    padding: 4px;
    border: 1px solid var(--gray-200);
    border-radius: var(--radius-md);
    background: white;
}
.risk-tag {
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 0.85rem;
    font-weight: 600;
    background: var(--gray-100);
    border: 1px solid var(--gray-200);
    cursor: default;
}
.risk-tag.risk-red { background: #fee2e2; color: #991b1b; border-color: #fecaca; }
.risk-tag.risk-yellow { background: #fef9c3; color: #854d0e; border-color: #fef08a; }
.risk-tag.risk-green { background: #dcfce7; color: #166534; border-color: #bbf7d0; }
.risk-tag.risk-black { background: #f1f5f9; color: #0f172a; border-color: #e2e8f0; }
.risk-tag.risk-blue { background: #dbeafe; color: #1e40af; border-color: #bfdbfe; }

.risk-tag .remove-risk {
    cursor: pointer;
    margin-left: 4px;
    opacity: 0.6;
}
.risk-tag .remove-risk:hover { opacity: 1; }

.add-risk-btn {
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    border: 1px dashed var(--gray-300);
    color: var(--gray-400);
    cursor: pointer;
    transition: all 0.2s;
}
.add-risk-btn:hover {
    background: var(--gray-50);
    color: var(--primary-500);
    border-color: var(--primary-500);
}

.risk-options-dropdown {
    position: absolute;
    background: white;
    border: 1px solid var(--gray-200);
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-lg);
    z-index: 1000;
    padding: 4px;
    min-width: 180px;
}
.risk-option {
    padding: 8px 12px;
    cursor: pointer;
    border-radius: 4px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.risk-option:hover { background: var(--gray-50); }

/* Upload Progress */
#upload-progress-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(255, 255, 255, 0.8);
    backdrop-filter: blur(4px);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    z-index: 9999;
}
.progress-container {
    width: 300px;
    height: 12px;
    background: var(--gray-200);
    border-radius: 6px;
    overflow: hidden;
    margin-bottom: 1rem;
    box-shadow: inset 0 2px 4px rgba(0,0,0,0.05);
}
.progress-bar {
    height: 100%;
    background: linear-gradient(90deg, var(--primary-500), var(--primary-600));
    width: 0%;
    transition: width 0.1s ease-out;
}
.progress-text {
    font-size: 1.25rem;
    font-weight: 700;
    color: var(--gray-900);
}
.progress-subtext {
    font-size: 0.9rem;
    color: var(--gray-500);
    margin-top: 0.5rem;
}
    position: relative;
    width: 100%;
    background: transparent;
    border-top: 1px solid var(--gray-100);
    margin-top: 0.75rem;
    max-height: 400px;
    overflow: hidden;
    display: flex;
    flex-direction: column;
}

.project-selector-dropdown .project-item {
    border-bottom: 1px solid var(--gray-100);
}

.project-selector-dropdown .project-item:last-child {
    border-bottom: none;
}

.project-selector-dropdown .project-list {
    max-height: 300px;
    overflow-y: auto;
}


.project-selector-dropdown .dd-input {
    margin: 8px;
    width: calc(100% - 16px);
}

.project-selector-dropdown .project-list {
    flex: 1;
    overflow-y: auto;
    max-height: 250px;
}
.project-selector-dropdown .project-load-more {
    padding: 8px;
    border-top: 1px solid var(--gray-100);
    background: var(--gray-50);
}
.project-selector-dropdown .dropdown-search-wrapper {
    padding: 8px;
    border-bottom: 1px solid var(--gray-100);
    background: var(--gray-50);
}

.project-selector-dropdown .project-item {
    padding: 10px 12px;
    cursor: pointer;
    border-bottom: 1px solid #f1f5f9;
    transition: background 0.1s;
}

.project-selector-dropdown .project-item:hover,
.project-selector-dropdown .project-item.highlighted {
    background: #f8fafc;
}

.project-selector-dropdown .project-item:last-child {
    border-bottom: none;
}

.project-selector-dropdown .project-name {
    display: block;
    font-weight: 500;
    color: var(--text-primary);
    margin-bottom: 2px;
}

.project-selector-dropdown .project-meta {
    display: block;
    font-size: 0.8rem;
    color: var(--text-secondary);
}

/* Base Layout - Container for the whole module */
/* We assume this is rendered inside #app */
div[data-module="elements"] {
    display: flex;
    flex-direction: column;
    height: calc(100vh - 70px); /* Adjust for global header ~60-70px */
    overflow: hidden; /* Prevent window scroll */
}

/* Page Toolbar - Flows naturally */
.dd-page-toolbar {
    height: var(--toolbar-height);
    background: white;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 1.5rem;
    flex-shrink: 0; /* Keep height fixed */
    width: 100%;
}

/* Split View Container - Fills remaining space */
.dd-layout-split {
    display: flex;
    flex: 1; /* Take remaining height */
    overflow: hidden; /* Internal scrolling */
    background: white;
    width: 100%;
    position: relative; /* Create context */
}

/* Sidebar - Full Height of Split View */
.dd-sidebar {
    width: var(--sidebar-width);
    background: var(--bg-sidebar);
    border-right: 1px solid var(--border-color);
    display: flex;
    flex-direction: column;
    height: 100%;
    flex-shrink: 0;
    transition: margin-left 0.3s ease; /* Smooth toggle if we wanted */
    z-index: 20;
}

/* Responsive adjustment for global sidebar toggle */
/* No specific media queries needed for left-pos since we follow flow */

.dd-sidebar-header {
    padding: 1rem;
    border-bottom: 1px solid var(--border-color);
    flex-shrink: 0;
}

.dd-sidebar-content {
    flex: 1;
    overflow-y: auto;
    padding: 0.5rem;
}

.dd-sidebar-footer {
    padding: 1rem;
    border-top: 1px solid var(--border-color);
    background: white;
    flex-shrink: 0;
    /* Anchors to bottom naturally due to flex-direction: column */
}

.dd-sidebar-search {
    background: white;
    border: 1px solid var(--border-color);
    color: var(--text-primary);
    box-shadow: 0 1px 2px rgba(0,0,0,0.05);
}

/* Main Content */
.dd-content {
    flex: 1;
    background: var(--bg-content);
    overflow-y: auto;
    padding: 2rem 3rem;
    position: relative;
    max-width: 1200px; /* Readable line length */
    margin: 0 auto;
    width: 100%;
}

/* Toolbar Components */
.toolbar-title {
    margin: 0;
    font-size: 1.1rem;
    font-weight: 600;
    color: var(--text-primary);
}

.toolbar-right {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

/* Dropdown Styles - Hover Triggered */
.dd-dropdown {
    position: relative;
}

.dd-dropdown-menu {
    position: absolute;
    top: 100%;
    right: 0;
    padding-top: 0.5rem; /* Use padding instead of margin to keep hover */
    background: transparent; /* Outer container transparent */
    min-width: 200px;
    z-index: 10000;
    display: none;
}

.dd-dropdown-menu::before {
    content: '';
    position: absolute;
    top: 0.5rem;
    left: 0;
    right: 0;
    bottom: 0;
    background: white;
    border: 1px solid var(--border-color);
    border-radius: 6px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    z-index: -1;
}

.dd-dropdown-menu-inner {
    padding: 0.5rem 0;
    position: relative;
}

.dd-dropdown:hover .dd-dropdown-menu,
.dd-dropdown:focus-within .dd-dropdown-menu {
    display: block;
}

.dd-chevron {
    font-size: 0.7rem;
    margin-left: 0.5rem;
    opacity: 0.4;
    transition: transform 0.2s;
}

.dd-dropdown:hover .dd-chevron {
    transform: rotate(180deg);
}

.dropdown-section-header {
    padding: 0.75rem 1rem 0.25rem 1rem;
    font-size: 0.7rem;
    font-weight: 700;
    color: var(--gray-400);
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.dropdown-item-icon, .btn-icon {
    margin-right: 0.5rem;
    color: var(--gray-500);
}

.dropdown-item:hover .dropdown-item-icon {
    color: var(--primary-500);
}


.dropdown-item {
    display: block;
    padding: 0.5rem 1rem;
    color: var(--text-primary);
    text-decoration: none;
    font-size: 0.9rem;
    transition: background 0.1s;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.dropdown-item:hover {
    background: #f1f5f9;
}

.dropdown-item i {
    width: 20px;
    text-align: center;
    color: var(--text-secondary);
}

.dropdown-divider {
    height: 1px;
    background: var(--border-color);
    margin: 0.5rem 0;
}

.dd-divider-vertical {
    width: 1px;
    height: 24px;
    background: var(--border-color);
    margin: 0 0.5rem;
}

/* Breadcrumbs */
.dd-breadcrumbs {
    font-size: 0.9rem;
    color: var(--text-secondary);
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.dd-breadcrumbs span.active {
    font-weight: 600;
    color: var(--text-primary);
}

.dd-breadcrumbs i {
    font-size: 0.7rem;
    color: #cbd5e1;
}

/* Element Header */
.dd-element-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 2rem;
    margin-bottom: 2rem;
    border-bottom: 1px solid var(--border-color);
    padding-bottom: 1.5rem;
}

.dd-input-title {
    font-size: 1.75rem;
    font-weight: 700;
    border: none;
    width: 100%;
    color: var(--text-primary);
    background: transparent;
    padding: 0;
}
.dd-input-title:focus {
    outline: none;
    background: #f8fafc;
}

/* Select Badge Styling */
.dd-select-badge {
    appearance: none;
    background-color: #f1f5f9;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    padding: 0.5rem 1rem;
    font-weight: 500;
    color: var(--text-primary);
    cursor: pointer;
}

/* Grid Layouts */
.dd-grid-2col {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 2rem;
    margin-bottom: 2.5rem;
}

.dd-label {
    display: block;
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: var(--text-secondary);
    margin-bottom: 0.5rem;
    font-weight: 600;
}

.dd-textarea-auto {
    width: 100%;
    border: 1px solid var(--border-color);
    border-radius: 6px;
    padding: 1rem;
    font-size: 1rem;
    line-height: 1.6;
    color: var(--text-primary);
    resize: vertical;
    min-height: 150px;
    background: #fff;
    transition: box-shadow 0.2s;
}
.dd-textarea-auto:focus {
    outline: none;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
    border-color: #3b82f6;
}

/* Economy Section */
.dd-section-light {
    background: #f8fafc;
    border: 1px solid var(--border-color);
    border-radius: 8px;
    padding: 1.5rem;
    margin-bottom: 2.5rem;
}

.dd-section-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 1rem;
}
.dd-section-header h4 { margin: 0; color: var(--text-primary); }

.dd-economy-grid {
    display: grid;
    grid-template-columns: 2fr repeat(4, 1fr);
    gap: 1.5rem;
    align-items: end;
}

.economy-item label {
    display: block;
    font-size: 0.8rem;
    color: var(--text-secondary);
    margin-bottom: 0.5rem;
}

.dd-input-lg {
    font-size: 1.25rem;
    padding: 0.5rem;
    width: 100%;
    border: 1px solid var(--border-color);
    border-radius: 4px;
    text-align: right;
    font-weight: 600;
}

.bucket-item {
    text-align: right;
}
.bucket-label {
    display: block;
    font-size: 0.8rem;
    color: var(--text-secondary);
    margin-bottom: 0.25rem;
}
.bucket-value {
    display: block;
    font-size: 1.1rem;
    font-weight: 600;
    color: var(--text-primary);
}

/* Gallery Grid */
.dd-gallery-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
    gap: 1rem;
}

.gallery-card {
    aspect-ratio: 4/3;
    background: #f1f5f9;
    border-radius: 8px;
    overflow: hidden;
    position: relative;
    cursor: pointer;
    border: 1px solid transparent;
    transition: all 0.2s;
}

.gallery-card img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.gallery-card.add-card {
    border: 2px dashed rgb(226, 232, 240);
    background: #f8fafc;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: var(--gray-500);
    gap: 0.25rem;
    transition: all 0.2s;
}
.gallery-card.add-card:hover {
    border-color: var(--primary-400);
    background: var(--blue-50);
    color: var(--primary-600);
}
.gallery-card.add-card i {
    font-size: 1.25rem;
    margin-bottom: 0.25rem;
}
.gallery-card.add-card span {
    font-size: 0.85rem;
    font-weight: 600;
}
.gallery-card.add-card .sub-text {
    font-size: 0.75rem;
    font-weight: 400;
    color: var(--gray-400);
}
.gallery-card.empty-slot {
    border: 2px dashed rgb(226, 232, 240) !important;
    background: transparent !important;
    cursor: default !important;
}

/* Tree View Styles */
.dd-tree-node {
    position: relative;
    cursor: pointer;
}
.tree-node-hidden {
    display: none !important;
}
/* Active/Selected Tree Node */
.dd-tree-node.active > .tree-content,
.dd-tree-node.selected > .tree-content {
    background-color: #dbeafe;
    border-left: 3px solid #3b82f6;
    color: #1e40af;
    font-weight: 600;
}

/* Drag and Drop Styles */
.dd-tree-node[draggable="true"] {
    cursor: grab;
}
.dd-tree-node[draggable="true"]:active {
    cursor: grabbing;
}
.dd-tree-node.dragging {
    opacity: 0.5;
    cursor: grabbing;
}
.dd-tree-node.drag-over > .tree-content {
    background-color: #e0f2fe;
    outline: 2px dashed #0ea5e9;
}
.dd-tree-node.drag-over-above > .tree-content {
    border-top: 3px solid #3b82f6;
}
.dd-tree-node.drag-over-below > .tree-content {
    border-bottom: 3px solid #3b82f6;
}

.tree-node:hover > .tree-content {
    background-color: #f1f5f9;
}
.tree-content {
    padding: 0.2rem 0.3rem;
    cursor: pointer;
    border-radius: 4px;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    transition: background 0.15s, border-left 0.15s;
    margin-bottom: 1px;
    border-left: 2px solid transparent;
    font-size: 0.875rem;
}
.tree-content:hover {
    background-color: #f8fafc;
}
.tree-content.active {
    background-color: #eff6ff;
    color: var(--primary-600);
    font-weight: 600;
}
.tree-number {
    font-family: 'Monaco', 'Consolas', monospace;
    font-size: 0.75rem;
    color: var(--text-secondary);
    margin-right: 0.25rem;
    min-width: 20px;
    display: inline-block;
}
.tree-name {
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
.node-icon {
    margin-right: 0.5rem;
    color: var(--gray-400);
    flex-shrink: 0;
}
.caret-icon {
    color: var(--gray-500);
    transition: transform 0.2s;
}
.dd-tree-node:not(.expanded) > .tree-content .caret-icon {
    /* transform: rotate(-90deg); */ /* We now switch icon instead of rotating for better clarity with SVG */
}
.tree-toggle {
    width: 20px;
    height: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 2px;
    color: var(--text-secondary);
    cursor: pointer;
}
.tree-toggle:hover { color: var(--text-primary); }

.tree-children {
    display: none; /* Controlled by JS toggling .expanded on parent node or children container */
}
.dd-tree-node.expanded > .tree-children {
    display: block;
}

/* Form Styles Refinement */
.dd-form-group {
    margin-bottom: 1.25rem;
}
.dd-input:focus, .dd-textarea-auto:focus {
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
    outline: none;
}
.dd-input-lg {
    font-family: inherit;
    font-variant-numeric: tabular-nums;
}

/* Budget Window Styles */
.budget-list-container { flex: 1; overflow-y: auto; padding: 15px; }
.budget-card { background: #fff; border: 1px solid #e0e0e0; border-radius: 6px; padding: 12px; margin-bottom: 12px; display: flex; gap: 12px; position: relative; transition: box-shadow 0.2s; }
.budget-card:hover { box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
.ac-dropdown { position: absolute; background: white; border: 1px solid #ccc; z-index: 1000; width: 100%; max-height: 200px; overflow-y: auto; box-shadow: 0 4px 6px rgba(0,0,0,0.1); top: 100%; left: 0; }
.ac-item { padding: 8px; cursor: pointer; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; font-size: 11px; }
.ac-item:hover, .ac-item.active { background: #f0f8ff; }
.drag-handle { cursor: grab; color: #ccc; display: flex; align-items: center; font-size: 18px; user-select: none; }
.drag-handle::after { content: '⋮⋮'; letter-spacing: -2px; }
.card-content { flex: 1; display: flex; flex-direction: column; gap: 10px; }
.row-top { display: flex; gap: 10px; }
.row-metrics { display: flex; gap: 8px; align-items: flex-end; }
.row-timeframes { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-top: 5px; padding-top: 10px; border-top: 1px dashed #eee; }
.budget-card label { font-size: 10px; color: #888; display: block; margin-bottom: 3px; }
.budget-card input, .budget-card select { width: 100%; padding: 6px; border: 1px solid #ddd; border-radius: 4px; font-size: 13px; box-sizing: border-box; }
.budget-card input:focus { border-color: #007bff; outline: none; }
.val-total { font-weight: bold; text-align: right; min-width: 80px; padding-bottom: 7px; font-size: 14px; }
.tf-box { position: relative; }
.tf-box input { padding-right: 25px; }
.magic-wand { position: absolute; right: 8px; bottom: 8px; cursor: pointer; color: #555; z-index: 10; font-size: 12px; }
.magic-wand:hover { opacity: 1; }
.bg-t1 { background: #fff0f0; border-color: #ffdada; }
.bg-t2 { background: #ffffe0; border-color: #eeeebb; }
.bg-t3 { background: #f0fff0; border-color: #ccffcc; }
.bg-t4 { background: #f0f8ff; border-color: #cce5ff; }
.btn-delete { border: none; background: none; color: #dc3545; cursor: pointer; font-size: 18px; padding: 0 5px; line-height: 1; }
.btn-add { width: 100%; padding: 10px; border: 1px dashed #bbb; background: #fff; color: #666; border-radius: 6px; cursor: pointer; font-weight: 500; margin-bottom: 20px; }
.btn-add:hover { background: #fefefe; border-color: #888; color: #333; }
.wm-footer-wrapper { background: #fff; border-top: 1px solid #ddd; flex-shrink: 0; }
.summary-bar { display: grid; grid-template-columns: repeat(4, 1fr); text-align: center; font-size: 11px; border-bottom: 1px solid #eee; }
.sum-item { padding: 8px 5px; border-right: 1px solid #f5f5f5; }
.sum-item:last-child { border-right: none; }
.sum-label { color: #888; font-size: 9px; display: block; margin-bottom: 2px; }
.sum-val { font-weight: bold; font-size: 12px; }
.wm-footer-actions { padding: 12px 15px; display: flex; justify-content: space-between; align-items: center; }
.btn-save { background: #007bff; color: white; border: none; padding: 8px 20px; border-radius: 4px; font-weight: 500; cursor: pointer; }

/* Input Validation Error States */
input.input-error,
textarea.input-error {
    border-color: #dc3545 !important;
    background: #fff5f5 !important;
}
input.input-error:focus,
textarea.input-error:focus {
    box-shadow: 0 0 0 3px rgba(220, 53, 69, 0.1) !important;
    border-color: #dc3545 !important;
}
.dd-input:invalid,
.dd-textarea-auto:invalid {
    border-color: #ffc107;
}
.btn-budget {
    background: #f0fdf4 !important;
    border: 1px solid #bbf7d0 !important;
    color: #166534 !important;
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px !important;
    font-weight: 500;
}
.btn-budget:hover {
    background: #dcfce7 !important;
    border-color: #86efac !important;
}
.btn-add {
    background: #fff;
    border: 1px dashed #ced4da;
    color: #6c757d;
    padding: 12px;
    width: 100%;
    margin-top: 10px;
    border-radius: 6px;
    cursor: pointer;
    font-weight: 500;
    transition: all 0.2s;
}
.btn-add:hover {
    background: #f8f9fa;
    border-color: #adb5bd;
    color: #495057;
}
.btn-delete {
    background: #fee2e2;
    color: #dc2626;
    border: none;
    border-radius: 4px;
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    font-size: 16px;
}
.btn-delete:hover {
    background: #fecaca;
}


/* Ratings Ribbon */
.dd-ratings-ribbon {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    gap: 20px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 20px;
}
.rating-ribbon-item {
    display: flex;
    flex-direction: column;
}
.rating-header-label {
    font-size: 11px;
    text-transform: uppercase;
    color: var(--text-secondary);
    font-weight: 700;
    margin-bottom: 8px;
    letter-spacing: 0.5px;
}
.risk-multi-select {
    display: flex;
    align-items: center;
    gap: 6px;
    flex-wrap: wrap;
    min-height: 32px;
}

</style>

<script>
(async function() {
    const initModule = async () => {
        if (window.App && window.App.elements) {
            // Ensure state is initialized from URL if present (Deep Linking Fix)
            const urlParams = new URLSearchParams(window.location.search);
            const pid = urlParams.get('project_id');
            const eid = urlParams.get('element_id');
            
            if (pid && App.elements.state) {
                App.elements.state.projectId = parseInt(pid);
                if (eid) App.elements.state.pendingElementId = eid;
            }

            await App.elements.initPage();
        } else {
            setTimeout(initModule, 100);
        }
    };
    
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initModule);
    } else {
        initModule();
    }
    // === TEMPLATE IMPORT FUNCTIONALITY ===
    App.elements.openTemplateModal = async function() {
        if (!App.elements.state || !App.elements.state.projectId) {
            App.core.toast('warning', 'Vælg venligst et projekt først.');
            return;
        }
        if (!App.elements.state.buildingId) {
             // 1. Try from current element
             if (App.elements.state.currentElement && App.elements.state.currentElement.building_id) {
                 App.elements.state.buildingId = App.elements.state.currentElement.building_id;
             } 
             // 2. Try from building-selector if it exists
             else if (document.getElementById('building-selector')?.value) {
                 App.elements.state.buildingId = document.getElementById('building-selector').value;
             }
             // 3. Try pick first building from state
             else if (App.elements.state.buildings && App.elements.state.buildings.length > 0) {
                 App.elements.state.buildingId = App.elements.state.buildings[0].id;
             }
             else {
                 App.core.toast('warning', 'Vælg venligst/opret en bygning i venstre side for at importere indhold.');
                 return;
             }
        }

        const modalBody = `
            <div class="dd-grid-2col" style="grid-template-columns: 1fr 1fr; gap: 0; border: 1px solid var(--gray-200); border-radius: var(--radius-md); height: 500px; margin-bottom: 0;">
                <!-- Left: Template List -->
                <div style="border-right: 1px solid var(--gray-200); display: flex; flex-direction: column; background: #f8fafc;">
                    <div style="padding: 10px 15px; border-bottom: 1px solid var(--gray-200); font-weight: 600; color: var(--gray-500); font-size: 0.8rem; text-transform: uppercase;">
                        Vælg Skabelon
                    </div>
                    <div id="import-template-list" style="flex: 1; overflow-y: auto;">
                        <div class="dd-loading-small" style="padding: 20px;">Henter skabeloner...</div>
                    </div>
                </div>

                <!-- Right: Node Selection -->
                <div style="display: flex; flex-direction: column; background: white;">
                    <div style="padding: 10px 15px; border-bottom: 1px solid var(--gray-200); display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-weight: 600; color: var(--gray-500); font-size: 0.8rem; text-transform: uppercase;">Vælg Indhold</span>
                        <div style="display: flex; gap: 10px; font-size: 0.75rem;">
                            <a href="#" onclick="App.elements.toggleAllTemplateNodes(true)" style="text-decoration: none;">Vælg alle</a>
                            <span style="color: var(--gray-300);">|</span>
                            <a href="#" onclick="App.elements.toggleAllTemplateNodes(false)" style="text-decoration: none; color: var(--gray-400);">Fravælg</a>
                        </div>
                    </div>
                    <div id="import-template-preview" style="flex: 1; overflow-y: auto; padding: 10px;">
                        <div style="color: var(--gray-400); text-align: center; padding-top: 40px;">
                            Vælg en skabelon til venstre for at se indhold
                        </div>
                    </div>
                </div>
            </div>
            <style>
                .tpl-item { padding: 10px 15px; cursor: pointer; border-bottom: 1px solid #f1f5f9; transition: background 0.1s; }
                .tpl-item:hover { background: #e2e8f0; }
                .tpl-item.active { background: white; border-left: 3px solid var(--primary-500); font-weight: 600; }
                .tpl-node-row { display: flex; align-items: center; padding: 4px 0; }
                .tpl-checkbox { margin-right: 8px; }
            </style>
        `;

        const buttons = [
            { label: 'Annuller', class: 'dd-btn-secondary', onclick: 'App.modal.close()' },
            { label: 'Importer Valgte', class: 'dd-btn-primary', id: 'btn-import-nodes', onclick: 'App.elements.importTemplateNodes()' }
        ];

        App.modal.show(App.utils.renderModal(modalBody, buttons), 'Importer fra Skabelon', 'large');

        // Load Templates
        try {
            const res = await App.core.ajax('api.php?module=elements&action=template_list');
            const templates = (res.data && res.data.data) ? res.data.data : (Array.isArray(res.data) ? res.data : []);
            App.elements.renderImportTemplateList(templates);
        } catch (e) {
             document.getElementById('import-template-list').innerHTML = `<div style="padding:15px; color:red;">Fejl: ${e.message}</div>`;
        }
    };

    App.elements.renderImportTemplateList = function(templates) {
        const container = document.getElementById('import-template-list');
        if (!templates || templates.length === 0) {
            container.innerHTML = '<div style="padding:15px; color:var(--gray-500);">Ingen skabeloner fundet via Template Manager.</div>';
            return;
        }

        container.innerHTML = templates.map(t => `
            <div class="tpl-item" onclick="App.elements.loadTemplatePreview(${t.id}, this)">
                <div style="font-size: 0.9rem;">${t.name}</div>
                <div style="font-size: 0.75rem; color: var(--gray-500);">${t.node_count || 0} elementer</div>
            </div>
        `).join('');
    };

    App.elements._currentImportTemplateId = null;

    App.elements.loadTemplatePreview = async function(id, el) {
        // Active state UI
        document.querySelectorAll('.tpl-item').forEach(i => i.classList.remove('active'));
        if (el) el.classList.add('active');

        App.elements._currentImportTemplateId = id;
        const container = document.getElementById('import-template-preview');
        container.innerHTML = '<div class="dd-loading-small">Henter struktur...</div>';

        try {
             const res = await App.core.ajax(`api.php?module=elements&action=template_get_config&template_id=${id}`);
             const structure = res.data.structure || [];
             
             if (structure.length === 0) {
                 container.innerHTML = '<div style="padding:15px; color:var(--gray-500);">Denne skabelon er tom.</div>';
                 return;
             }
             
             // Render Checkbox Tree
             const renderCheckNode = (node, level=0) => {
                 const hasStandards = node.observation || node.recommendation || node.risk_level || node.condition_rating || node.quality_rating;
                 return `
                    <div class="tpl-node-row" style="padding-left: ${level * 15}px;">
                        <input type="checkbox" class="tpl-checkbox node-check" value="${node.id}" checked 
                               data-id="${node.id}" 
                               data-parent-id="${node.parent_id || ''}"
                               onchange="App.elements.handleTemplateNodeSelection(this)">
                        <span style="font-size: 0.85rem; ${hasStandards ? 'font-weight: 600; color: var(--primary-700);' : ''}">
                            ${node.element_type === 'section' ? '<i class="fas fa-folder" style="color:#fbbf24; margin-right:5px;"></i>' : '<i class="fas fa-file-alt" style="color:#94a3b8; margin-right:5px;"></i>'} 
                            ${node.name}
                            ${hasStandards ? '<small style="font-weight: 400; font-size: 10px; opacity: 0.6; margin-left: 5px;">(Standardiseret)</small>' : ''}
                        </span>
                    </div>
                    ${(node.children || []).map(c => renderCheckNode(c, level + 1)).join('')}
                 `;
             };
             
             container.innerHTML = structure.map(n => renderCheckNode(n)).join('');
             
        } catch(e) {
            container.innerHTML = `<div style="padding:15px; color:red;">Fejl: ${e.message}</div>`;
        }
    };

    App.elements.handleTemplateNodeSelection = function(cb) {
        if (cb.checked) {
            const parentId = cb.getAttribute('data-parent-id');
            if (parentId) {
                const parentCb = document.querySelector(`.tpl-checkbox[data-id="${parentId}"]`);
                if (parentCb && !parentCb.checked) {
                    parentCb.checked = true;
                    App.elements.handleTemplateNodeSelection(parentCb);
                }
            }
        }
    };

    App.elements.toggleAllTemplateNodes = function(state) {
        document.querySelectorAll('.node-check').forEach(cb => cb.checked = state);
    };

    App.elements.importTemplateNodes = async function() {
        const checkboxes = document.querySelectorAll('.node-check:checked');
        if (checkboxes.length === 0) {
            App.core.toast('warning', 'Ingen elementer valgt til import.');
            return;
        }

        const ids = Array.from(checkboxes).map(cb => parseInt(cb.value));
        const btn = document.getElementById('btn-import-nodes');
        const oldText = btn ? btn.innerText : 'Importer Valgte'; // Fallback
        if(btn) {
            btn.innerText = 'Importerer...';
            btn.disabled = true;
        }

        // Ensure we have a building ID
        let buildingId = parseInt(App.elements.state.buildingId);
        if (!buildingId) {
             const selector = document.getElementById('building-selector');
             if (selector && selector.value) {
                 buildingId = parseInt(selector.value);
                 App.elements.state.buildingId = buildingId;
             } else if (App.elements.state.buildings && App.elements.state.buildings.length > 0) {
                 buildingId = App.elements.state.buildings[0].id;
                 App.elements.state.buildingId = buildingId;
             }
        }

        if (!buildingId) {
            App.core.toast('error', 'Kunne ikke identificere hvilken bygning der skal importeres til. Vælg venligst en bygning.');
            if(btn) {
                btn.innerText = oldText;
                btn.disabled = false;
            }
            return;
        }

        try {
            await App.core.ajax('api.php?module=elements&action=template_bulk_create', {
                method: 'POST',
                body: {
                    project_id: parseInt(App.elements.state.projectId),
                    building_id: buildingId,
                    elements: ids
                }
            });

            App.core.toast('success', `${ids.length} elementer importeret success.`);
            App.modal.close();
            
            // Force reload tree to show new elements
            if (App.elements.loadTree) {
                // Invalidate cache to force fetch
                if (App.elements.state && App.elements.state.treeCache) {
                    App.elements.state.treeCache = {}; 
                }
                await App.elements.loadTree();
            }
            // Reload list/view
            if (App.elements.loadList && App.elements.state.projectId) {
                App.elements.loadList(App.elements.state.projectId);
            }
        } catch (e) {
            console.error(e);
            App.core.toast('error', 'Import fejlede: ' + e.message);
            if(btn) {
                btn.innerText = oldText;
                btn.disabled = false;
            }
        }
    };



    
    // Tools Menu Modal
    App.elements.openToolsMenu = function() {
        if (!App.elements.state || !App.elements.state.currentElement) {
             App.core.toast('warning', 'Vælg venligst et element først.');
             return;
        }
        const el = App.elements.state.currentElement;
        
        const content = `
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <!-- Column 1: Standard Actions -->
                <div>
                    <h5 style="color: var(--gray-500); font-size: 0.75rem; text-transform: uppercase; margin-bottom: 10px;">Handlinger</h5>
                    
                    <button onclick="App.elements.deleteCurrentElement(); App.modal.close();" class="dd-btn-secondary" style="width: 100%; text-align: left; margin-bottom: 8px; color: #dc2626; border-color: #fee2e2; background: #fef2f2;">
                        <i class="fas fa-trash-alt" style="margin-right: 8px;"></i> Slet Element
                    </button>
                    
                    <button class="dd-btn-secondary" style="width: 100%; text-align: left; margin-bottom: 8px; opacity: 0.6; cursor: not-allowed;">
                        <i class="fas fa-copy" style="margin-right: 8px;"></i> Dupliker (Kommer snart)
                    </button>

                    <button class="dd-btn-secondary" style="width: 100%; text-align: left; margin-bottom: 8px; opacity: 0.6; cursor: not-allowed;">
                        <i class="fas fa-arrow-right" style="margin-right: 8px;"></i> Flyt (Brug Drag & Drop)
                    </button>
                </div>

                <!-- Column 2: AI & Future -->
                <div style="background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px dashed var(--gray-300);">
                    <h5 style="color: var(--primary-600); font-size: 0.75rem; text-transform: uppercase; margin-bottom: 10px;">
                        <i class="fas fa-magic" style="margin-right: 5px;"></i> AI Assistent
                    </h5>
                    
                    <div style="font-size: 0.85rem; color: var(--gray-500); margin-bottom: 10px;">
                        AI-værktøjer er under udvikling til Enterprise versionen.
                    </div>

                    <button class="dd-btn-primary" style="width: 100%; text-align: left; margin-bottom: 8px; background: linear-gradient(135deg, #6366f1, #8b5cf6); border: none; opacity: 0.8; cursor: not-allowed;">
                        <i class="fas fa-pen-fancy" style="margin-right: 8px;"></i> Forbedre beskrivelse
                    </button>
                    
                    <button class="dd-btn-primary" style="width: 100%; text-align: left; margin-bottom: 8px; background: linear-gradient(135deg, #6366f1, #8b5cf6); border: none; opacity: 0.8; cursor: not-allowed;">
                        <i class="fas fa-search-dollar" style="margin-right: 8px;"></i> Estimer Pris
                    </button>
                </div>
            </div>
        `;
        
        App.modal.show(content, `Værktøjer: ${el.name}`, 'medium');
    };

    // Fix for refreshCurrentElement context issue during upload callback
    App.elements.refreshCurrentElement = function () {
        if (App.elements.state && App.elements.state.currentElement) {
            App.elements.selectElement(App.elements.state.currentElement.id);
        }
    };

    // Delete Current Element (With Modal & SVG)
    App.elements.deleteCurrentElement = function() {
        if (!App.elements.state || !App.elements.state.currentElement || !App.elements.state.currentElement.id) {
            App.core.toast('warning', 'Vælg venligst et element først.');
            return;
        }

        const currentEl = App.elements.state.currentElement;
        const id = currentEl.id;

        const body = `
            <div style="text-align: center; padding: 20px;">
                <div style="color: #ef4444; margin-bottom: 15px;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
                </div>
                <h3 style="margin-bottom: 10px; color: var(--gray-900);">Slet Element?</h3>
                <p style="color: var(--gray-600); margin-bottom: 20px;">
                    Er du sikker på at du vil slette <strong>"${currentEl.name || 'elementet'}"</strong>?<br>
                    <span style="font-size: 0.85rem; color: #ef4444;">ADVARSEL: Dette vil også slette alle underliggende elementer og tilknyttede opgaver!</span>
                </p>
            </div>
        `;

        const buttons = [
             { label: 'Annuller', class: 'dd-btn-secondary', onclick: 'App.modal.close()' },
             { label: 'Slet Element', class: 'dd-btn-danger', onclick: `App.elements.executeDeleteElement(${id})`, icon: 'trash' }
        ];

        App.modal.show(App.utils.renderModal(body, buttons), 'Bekræft Sletning', 'small');
    };

    App.elements.executeDeleteElement = async function(id) {
        App.modal.close();
        try {
            const res = await App.core.ajax('api.php?module=elements&action=element_delete', {
                method: 'POST',
                body: {
                    id: id,
                    project_id: App.elements.state.projectId
                }
            });

            if (res.success) {
                App.core.toast('success', 'Element slettet.');
                
                // Clear selection
                App.elements.state.currentElement = null;
                const detailsContainer = document.getElementById('element-details-container');
                if(detailsContainer) detailsContainer.innerHTML = '<div style="padding:2rem; text-align:center; color:var(--gray-500);">Vælg en bygningsdel</div>';
                
                // Invalidate Tree Cache
                if (App.elements.state.treeCache) {
                    App.elements.state.treeCache = {};
                }
                
                // Refresh Tree
                if (App.elements.loadTree) {
                    await App.elements.loadTree();
                } else if (App.elements.loadList) {
                    App.elements.loadList(App.elements.state.projectId);
                }
            } else {
                App.core.toast('error', res.error || 'Kunne ikke slette element.');
            }
        } catch (e) {
            console.error(e);
            App.core.toast('error', 'Der opstod en fejl: ' + e.message);
        }
    };
    
    // Fix for duplicate tree rendering & Restore Drag-Drop
    App.elements.renderTree = function (treeData) {
        const container = document.getElementById('tree-container');
        if (!container) return;

        // Clear existing content (Fixing duplication)
        container.innerHTML = '';

        if (!treeData || treeData.length === 0) {
            container.innerHTML = `
                <div class="empty-tree-state" style="padding: 2rem; text-align: center; color: var(--gray-400);">
                    <div style="font-size: 2rem; margin-bottom: 0.5rem;"><i class="fas fa-cubes"></i></div>
                    <p>Ingen bygningsdele fundet</p>
                    <button class="dd-btn-secondary" onclick="App.elements.createRootElement()" style="margin-top:1rem; font-size:0.8rem;">Opret første element</button>
                </div>`;
            return;
        }

        // Ensure root container is draggable zone
        container.dataset.behavior = 'drag-drop';
        container.dataset.ddHandle = '.tree-content';
        container.dataset.ddItem = '.dd-tree-node';
        container.dataset.ddCallback = 'App.elements.handleTreeDrop';

        const renderNode = (node, level) => {
            const nodeEl = App.elements.createTreeNode(node, level);

            if (node.children && node.children.length > 0) {
                const childrenContainer = document.createElement('div');
                childrenContainer.className = 'tree-children';
                childrenContainer.style.display = 'block'; 

                // Nested drag-drop support (Critical for functionality)
                childrenContainer.dataset.behavior = 'drag-drop';
                childrenContainer.dataset.ddHandle = '.tree-content';
                childrenContainer.dataset.ddItem = '.dd-tree-node';
                childrenContainer.dataset.ddCallback = 'App.elements.handleTreeDrop';

                node.children.forEach(child => {
                    childrenContainer.appendChild(renderNode(child, level + 1));
                });

                nodeEl.appendChild(childrenContainer);
            }
            return nodeEl;
        };

        const fragment = document.createDocumentFragment();
        treeData.forEach(node => {
            fragment.appendChild(renderNode(node, 0));
        });
        container.appendChild(fragment);

        // Update numbering and visuals
        setTimeout(() => {
            if (typeof App.elements.updateTreeNumbering === 'function') {
                App.elements.updateTreeNumbering();
            }
        }, 0);

        // Re-bind behaviors (Drag & Drop)
        if (window.App && App.behaviors && typeof App.behaviors.init === 'function') {
            App.behaviors.init(container);
        }
    };
    
    // ========================================================================
    // BUILDING MANAGER OVERRIDES & FIXES
    // ========================================================================

    App.elements.openBuildingManager = function () {
        if (!App.elements.state.projectId) {
            App.core.toast('warning', 'Vælg et projekt først');
            return;
        }

        const buildings = App.elements.state.buildings || [];
        
        const body = `
            <div class="dd-building-manager">
                ${buildings.length === 0 ? `
                    <div class="dd-empty-state" style="padding: 3rem 1rem; text-align: center;">
                        <div class="empty-icon" style="font-size: 2rem; color: var(--gray-300); margin-bottom: 1rem;">
                            <i class="fas fa-building"></i>
                        </div>
                        <p style="color: var(--gray-500);">Ingen bygninger oprettet endnu.</p>
                    </div>
                ` : `
                    <div class="dd-list-group" id="building-sort-list">
                        ${buildings.map((b, index) => `
                            <div class="dd-list-item building-item" data-id="${b.id}" style="padding: 1rem; border-bottom: 1px solid var(--gray-200); display: flex; justify-content: space-between; align-items: center; background:white;">
                                <div style="display:flex; align-items:center;">
                                    <div class="drag-handle" style="cursor:grab; margin-right:10px; color:var(--gray-400);"><i class="fas fa-grip-vertical"></i></div>
                                    <div>
                                        <div style="font-weight: 600; color: var(--gray-900);">${b.name}</div>
                                        <div style="font-size: 0.875rem; color: var(--gray-500);">${b.description || 'Ingen beskrivelse'}</div>
                                    </div>
                                </div>
                                <div class="actions" style="display: flex; gap: 0.5rem;">
                                    <button class="dd-btn-icon" title="Rediger" onclick="App.elements.editBuilding(${b.id})">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="dd-btn-icon dd-btn-danger" title="Slet" onclick="App.elements.deleteBuilding(${b.id})">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                `}
                <div style="margin-top: 1rem; font-size: 0.75rem; color: var(--gray-500); text-align: center; text-transform: uppercase; letter-spacing: 0.025em;">
                    ${buildings.length} bygning(er) i dette projekt
                </div>
            </div>
        `;

        const buttons = [
            { label: 'Luk', class: 'dd-btn-secondary', onclick: 'App.modal.close()' },
            { label: 'Ny Bygning', class: 'dd-btn-primary', onclick: 'App.elements.createBuildingPanel()', icon: 'plus' }
        ];

        App.modal.show(App.utils.renderModal(body, buttons), 'Bygnings Styring', 'medium', 'elements-mgr');

        // Init Drag & Drop (Sortable)
        setTimeout(() => {
            const list = document.getElementById('building-sort-list');
            if (list && window.Sortable) {
                Sortable.create(list, {
                    handle: '.drag-handle',
                    animation: 150,
                    onEnd: function (evt) {
                        App.elements.saveBuildingOrder();
                    }
                });
            }
        }, 100);
    };

    App.elements.saveBuildingOrder = async function() {
         const updates = [];
         document.querySelectorAll('#building-sort-list .building-item').forEach((row, index) => {
             updates.push({
                 id: row.getAttribute('data-id'),
                 sort_order: index + 1
             });
         });

         try {
             // Use building_reorder endpoint
             await App.core.ajax('api.php?module=elements&action=building_reorder', { 
                method: 'POST',
                body: { project_id: App.elements.state.projectId, order: updates } 
             });
             
             // Refresh Data
             App.core.toast('success', 'Rækkefølge gemt');
             await App.elements.loadBuildings(); // Updates internal state
             
             // Refresh Tree
             if(App.elements.state.treeCache) App.elements.state.treeCache = {};
             if(App.elements.loadTree) await App.elements.loadTree(); 

         } catch(e) { console.error(e); }
    };

    // Override createBuilding to be the Form Panel
    App.elements.createBuildingPanel = function () { 
        const projectId = App.elements.state.projectId;
        const body = `
            <div class="dd-form-row">
                <label class="dd-label">Navn <span class="dd-required">*</span></label>
                <input type="text" id="new-building-name" class="dd-input" placeholder="F.eks. Hovedbygning" autofocus required>
            </div>
            <div class="dd-form-row">
                <label class="dd-label">Beskrivelse (Valgfri)</label>
                <textarea id="new-building-desc" class="dd-input" rows="2" placeholder="Kort beskrivelse..."></textarea>
            </div>
            <div class="dd-form-row">
                <label class="dd-label">Adresse (Valgfri)</label>
                <input type="text" id="new-building-address" class="dd-input" placeholder="Gade og nr.">
            </div>
        `;

        const buttons = [
            { label: 'Annuller', class: 'dd-btn-secondary', onclick: 'App.elements.openBuildingManager()' },
            { label: 'Opret Bygning', class: 'dd-btn-primary', onclick: `App.elements.submitCreateBuilding(${projectId})`, icon: 'save' }
        ];
        App.modal.show(App.utils.renderModal(body, buttons), 'Ny Bygning', 'medium');
    };

    // Actual API Call
    App.elements.submitCreateBuilding = async function(projectId) {
        const nameInput = document.getElementById('new-building-name');
        const descInput = document.getElementById('new-building-desc');
        const addrInput = document.getElementById('new-building-address');
        
        if (!nameInput || !nameInput.value.trim()) {
            App.core.toast('error', 'Indtast venligst et navn');
            return;
        }

        try {
            await App.core.ajax('api.php?module=elements&action=building_create', {
                method: 'POST',
                body: {
                    project_id: projectId,
                    name: nameInput.value.trim(),
                    description: descInput ? descInput.value.trim() : '',
                    address: addrInput ? addrInput.value.trim() : ''
                }
            });

            App.core.toast('success', 'Bygning oprettet');
            
            // Reloads
            await App.elements.loadBuildings();
            if(App.elements.state.treeCache) App.elements.state.treeCache = {};
            if(App.elements.loadTree) await App.elements.loadTree(); 

            App.elements.openBuildingManager(); // Back to list
        } catch (e) {
            App.core.toast('error', e.message);
        }
    };
    
    // Override Edit
    App.elements.editBuilding = function(id) {
        const b = App.elements.state.buildings.find(x => x.id == id);
        if(!b) return;
        
        const body = `
            <div class="dd-form-row">
                <label class="dd-label">Navn <span class="dd-required">*</span></label>
                <input type="text" id="edit-building-name" class="dd-input" value="${b.name}" autofocus required>
            </div>
            <div class="dd-form-row">
                <label class="dd-label">Beskrivelse</label>
                <textarea id="edit-building-desc" class="dd-input" rows="2">${b.description||''}</textarea>
            </div>
        `;
        const buttons = [
            { label: 'Annuller', class: 'dd-btn-secondary', onclick: 'App.elements.openBuildingManager()' },
            { label: 'Gem Ændringer', class: 'dd-btn-primary', onclick: `App.elements.submitUpdateBuilding(${b.id})`, icon: 'save' }
        ];
        App.modal.show(App.utils.renderModal(body, buttons), 'Rediger Bygning', 'medium');
    };

    App.elements.submitUpdateBuilding = async function(id) {
         const name = document.getElementById('edit-building-name').value;
         const desc = document.getElementById('edit-building-desc').value;
         
         try {
            await App.core.ajax('api.php?module=elements&action=building_update', {
                method: 'POST',
                body: { id: id, name: name, description: desc }
            });
            App.core.toast('success', 'Gemt');
            await App.elements.loadBuildings();
            if(App.elements.state.treeCache) App.elements.state.treeCache = {};
            if(App.elements.loadTree) await App.elements.loadTree(); 
            App.elements.openBuildingManager();
         } catch(e) { App.core.toast('error', e.message); }
    };

    // Override Delete
    App.elements.deleteBuilding = function(id) {
        // Find name
        const b = (App.elements.state.buildings || []).find(x => x.id == id);
        const name = b ? b.name : 'Denne bygning';
        
        App.elements.confirmDeleteBuilding(id, name, true);
    };
    
    // Sidebar Delete (Tree)
    App.elements.deleteBuildingSidebar = function(id) {
        // Fetch name if possible, or generic
        App.elements.confirmDeleteBuilding(id, 'Denne bygning', false);
    };

    App.elements.confirmDeleteBuilding = function(id, name, returnToManager) {
        const body = `
            <div style="text-align: center; padding: 20px;">
                <div style="color: #ef4444; margin-bottom: 15px;">
                     <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
                </div>
                <h3 style="margin-bottom: 10px; color: var(--gray-900);">Slet Bygning?</h3>
                <p style="color: var(--gray-600); margin-bottom: 20px;">
                    Er du sikker på at du vil slette <strong>"${name || 'bygningen'}"</strong>?<br>
                    <span style="font-size: 0.85rem; color: #ef4444;">ADVARSEL: Dette sletter også alle elementer i bygningen!</span>
                </p>
            </div>
        `;
        
        const buttons = [
             { label: 'Annuller', class: 'dd-btn-secondary', onclick: returnToManager ? 'App.elements.openBuildingManager()' : 'App.modal.close()' },
             { label: 'Slet Bygning', class: 'dd-btn-danger', onclick: `App.elements.executeDeleteBuilding(${id}, ${returnToManager})`, icon: 'trash' }
        ];

        App.modal.show(App.utils.renderModal(body, buttons), 'Slet Bygning', 'small');
    };

    App.elements.executeDeleteBuilding = async function(id, returnToManager) {
        App.modal.close();
        try {
             await App.core.ajax('api.php?module=elements&action=building_delete', { method: 'POST', body: { id: id } });
             App.core.toast('success', 'Bygning slettet');
             await App.elements.loadBuildings();
             if(App.elements.state.treeCache) App.elements.state.treeCache = {};
             if(App.elements.loadTree) await App.elements.loadTree(); 
             
             if (returnToManager) {
                 App.elements.openBuildingManager();
             }
        } catch(e) { App.core.toast('error', e.message); }
    };
    
    // Override createTreeNode to use Custom SVG
    App.elements.createTreeNode = function (node, level) {
        const nodeEl = document.createElement('div');
        nodeEl.className = 'dd-tree-node tree-node expanded';
        const nodeType = node.type || 'element';
        nodeEl.dataset.id = `${nodeType}-${node.id}`;
        nodeEl.dataset.rawId = node.id;
        nodeEl.dataset.level = level;
        nodeEl.dataset.type = nodeType;

        const content = document.createElement('div');
        content.className = `tree-content ${App.elements.state.currentElement && App.elements.state.currentElement.id == node.id ? 'active' : ''}`;
        content.dataset.nodeId = node.id; // For Stats

        const hasChildren = node.children && node.children.length > 0;

        // Toggle
        const toggle = document.createElement('span');
        toggle.className = 'tree-toggle';
        if (hasChildren) {
            toggle.innerHTML = App.icons.get('caretDown', { size: 12, class: 'caret-icon' });
            toggle.addEventListener('click', (e) => {
                e.stopPropagation();
                // We assume toggleTreeNode is on prototype or we bind it. 
                // Since this is override, 'this' might be wrong if called directly.
                // Safest to access App.elements.toggleTreeNode if it exists or replicate logic.
                // app.combined.js used `this.toggleTreeNode`. Here `App.elements` might not be `this`.
                if (App.elements.toggleTreeNode) {
                     App.elements.toggleTreeNode(e, toggle);
                } else {
                     // Simple fallback
                     nodeEl.classList.toggle('expanded');
                     toggle.classList.toggle('collapsed');
                }
            });
        }
        content.appendChild(toggle);

        // Number
        const number = document.createElement('span');
        number.className = 'tree-number';
        content.appendChild(number);

        // Icon
        const icon = document.createElement('span');
        icon.className = 'node-icon';
        if (node.type === 'building') {
            icon.innerHTML = App.icons.get('building', { size: 14 });

            // Add Delete Button to Building (Custom SVG)
            const deleteBtn = document.createElement('span');
            deleteBtn.className = 'tree-delete-btn';
            deleteBtn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>`;
            deleteBtn.title = 'Slet Bygning';
            deleteBtn.style.marginLeft = 'auto';
            deleteBtn.style.padding = '2px 4px';
            deleteBtn.style.opacity = '0';
            deleteBtn.style.cursor = 'pointer';
            deleteBtn.style.transition = 'opacity 0.2s';
            deleteBtn.style.color = '#ef4444'; // Red color

            content.addEventListener('mouseenter', () => deleteBtn.style.opacity = '1');
            content.addEventListener('mouseleave', () => deleteBtn.style.opacity = '0');

            deleteBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                App.elements.deleteBuildingSidebar(node.id);
            });
            content.appendChild(deleteBtn);
        } else {
            icon.innerHTML = App.icons.get('layers', { size: 14 });
        }
        content.appendChild(icon);

        // Name
        const name = document.createElement('span');
        name.className = 'tree-name';
        name.textContent = node.name;
        content.appendChild(name);
        
        // Risk indicators (restored logic simplified)
        if (node.type !== 'building' && node.risk_level) {
             const risks = node.risk_level.split(',').map(r => r.trim());
             const activeRisks = risks.filter(r => ['Rød', 'Gul', 'Grøn'].includes(r));
             if (activeRisks.length > 0) {
                 const riskWrapper = document.createElement('span');
                 riskWrapper.style.marginLeft = 'auto';
                 riskWrapper.style.display = 'flex';
                 riskWrapper.style.gap = '2px';
                 activeRisks.forEach(r => {
                     const dot = document.createElement('span');
                     dot.style.width = '8px'; dot.style.height='8px'; dot.style.borderRadius='50%';
                     if(r==='Rød') dot.style.background = '#ef4444';
                     if(r==='Gul') dot.style.background = '#f59e0b';
                     if(r==='Grøn') dot.style.background = '#10b981';
                     riskWrapper.appendChild(dot);
                 });
                 content.appendChild(riskWrapper);
             }
        }

        nodeEl.appendChild(content);
        return nodeEl;
    };
    

    
    // === AI LOADING & RESULT OVERRIDES ===
    App.elements._aiLoadingInterval = null;
    
    App.elements.startAILoadingAnimation = function(baseText) {
        this.stopAILoadingAnimation();
        const el = document.getElementById('ai-process-status-text');
        if (!el) return;
        
        let dots = 0;
        el.innerText = baseText;
        
        this._aiLoadingInterval = setInterval(() => {
            dots = (dots + 1) % 4;
            el.innerText = baseText + '.'.repeat(dots);
        }, 500);
    };
    
    App.elements.stopAILoadingAnimation = function() {
        if (this._aiLoadingInterval) {
            clearInterval(this._aiLoadingInterval);
            this._aiLoadingInterval = null;
        }
    };

    // Override updateAIFlow to support animation
    const _originalUpdateAIFlow = App.elements.updateAIFlow;
    App.elements.updateAIFlow = function(state, timerVal = null) {
        // Still call original to handle dots and lines
        if (typeof _originalUpdateAIFlow === 'function') {
            _originalUpdateAIFlow.apply(this, arguments);
        }
        
        if (state === 'sent') {
            this.startAILoadingAnimation('AI behandler data');
        } else if (state === 'done') {
            this.stopAILoadingAnimation();
            const el = document.getElementById('ai-process-status-text');
            if (el) el.innerText = 'Færdig! Indlæser resultat...';
        }
    };

    // Override runAIAssessment to include result view and animated start
    App.elements.runAIAssessment = async function () {
        const element = this.state.currentElement;
        if (!element) return;

        try {
            const res = await App.core.ajax('api.php?module=ai&action=list_agents');
            const agents = res.data || [];
            const media = element.media || [];

            if (agents.length === 0) {
                App.core.toast('warning', 'Ingen AI agenter konfigureret. Opret en under System.');
                return;
            }

            const body = `
                <div id="ai-modal-selector-view">
                    <div class="dd-form-row">
                        <label class="dd-label" style="display:flex; align-items:center; gap:8px;">
                            <span class="material-icons" style="font-size:20px; color:var(--primary-600);">psychology</span>
                            Vælg AI Agent
                        </label>
                        <select id="ai-agent-selector" class="dd-input" onchange="App.elements.updateAIPromptPlaceholder(this.value, ${JSON.stringify(agents).replace(/"/g, '&quot;')})">
                            ${agents.map(a => `<option value="${a.id}">${a.name}</option>`).join('')}
                        </select>
                    </div>

                    <div class="dd-form-row" style="margin-top:1.5rem;">
                        <details style="background:var(--gray-50); border-radius:8px; border:1px solid var(--gray-200);">
                            <summary style="padding:10px; cursor:pointer; font-weight:500; font-size:0.875rem; color:var(--gray-700); display:flex; align-items:center; gap:8px;">
                                <span class="material-icons" style="font-size:18px;">settings_suggest</span>
                                Tilpas AI Instrukser / Prompt (Valgfrit)
                            </summary>
                            <div style="padding:10px; border-top:1px solid var(--gray-200);">
                                <textarea id="ai-custom-prompt" class="dd-input" style="min-height:150px; font-size:0.85rem;" placeholder="Indtast specifikke instrukser til denne kørsel...">${agents[0].system_prompt || ''}</textarea>
                            </div>
                        </details>
                    </div>

                    <div class="dd-form-row" style="margin-top:2rem;">
                        <label class="dd-label" style="display:flex; align-items:center; gap:8px;">
                            <span class="material-icons" style="font-size:20px; color:var(--primary-600);">photo_library</span>
                            Vælg billeder til analyse (Valgfrit)
                        </label>
                        <div id="ai-photo-selector" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 15px; margin-top:10px;">
                            ${media.length === 0 ? '<p style="grid-column:1/-1; color:var(--gray-400); font-size:0.875rem;">Ingen billeder fundet på dette element.</p>' :
                    media.map(m => `
                                <label class="ai-photo-item" style="position:relative; cursor:pointer;">
                                    <input type="checkbox" name="ai_media" value="${m.id}" style="position:absolute; top:8px; right:8px; z-index:10; width:18px; height:18px;" checked>
                                    <img src="${window.UPLOAD_URL}${m.file_path}" style="width:100%; aspect-ratio:1; object-fit:cover; border-radius:8px; border:3px solid transparent; transition:all 0.2s; box-shadow:var(--shadow-sm);">
                                </label>
                              `).join('')
                }
                        </div>
                    </div>

                    <p style="font-size: 0.8125rem; color: var(--gray-500); margin-top:2rem; border-top:1px solid var(--gray-100); padding-top:1rem; font-style:italic;">
                        AI'en kender automatisk til placering, observationer, anbefalinger og system-tags.
                    </p>
                </div>

                <div id="ai-modal-process-view" style="display:none; padding: 2rem 1rem; text-align: center;">
                    <div class="ai-flow-visualization" style="display: flex; align-items: center; justify-content: center; gap: 0; margin-bottom: 2rem;">
                        <div class="flow-step" id="flow-step-sent" style="display: flex; flex-direction: column; align-items: center; width: 80px;">
                            <div class="flow-dot" style="width: 24px; height: 24px; border-radius: 50%; background: var(--gray-200); display: flex; align-items: center; justify-content: center; color: white; transition: all 0.3s;">
                                <span class="material-icons" style="font-size: 16px;">upload</span>
                            </div>
                            <span style="font-size: 0.75rem; margin-top: 8px; color: var(--gray-500); font-weight: 600;">SENDT</span>
                        </div>
                        <div class="flow-line" id="flow-line-1" style="height: 3px; background: var(--gray-200); flex: 1; max-width: 100px; margin-top: -24px; transition: all 0.3s;"></div>
                        <div class="flow-step" id="flow-step-thinking" style="display: flex; flex-direction: column; align-items: center; width: 80px;">
                            <div class="flow-dot" style="width: 24px; height: 24px; border-radius: 50%; background: var(--gray-200); display: flex; align-items: center; justify-content: center; color: white; transition: all 0.3s;">
                                <span class="material-icons" style="font-size: 16px;">schedule</span>
                            </div>
                            <span id="ai-timer-label" style="font-size: 0.75rem; margin-top: 8px; color: var(--gray-500); font-weight: 600;">0 SEK</span>
                        </div>
                        <div class="flow-line" id="flow-line-2" style="height: 3px; background: var(--gray-200); flex: 1; max-width: 100px; margin-top: -24px; transition: all 0.3s;"></div>
                        <div class="flow-step" id="flow-step-received" style="display: flex; flex-direction: column; align-items: center; width: 80px;">
                            <div class="flow-dot" style="width: 24px; height: 24px; border-radius: 50%; background: var(--gray-200); display: flex; align-items: center; justify-content: center; color: white; transition: all 0.3s;">
                                <span class="material-icons" style="font-size: 16px;">check</span>
                            </div>
                            <span style="font-size: 0.75rem; margin-top: 8px; color: var(--gray-500); font-weight: 600;">MODTAGET</span>
                        </div>
                    </div>
                    <div id="ai-process-status-text" style="font-size: 1rem; color: var(--gray-700); font-weight: 500;">AI forbereder anmodning...</div>
                </div>

                <div id="ai-modal-result-view" style="display:none; padding:10px;">
                    <div class="dd-form-row">
                        <label class="dd-label">Observationer (Rediger bar)</label>
                        <textarea id="ai-modal-obs-edit" class="dd-input" style="min-height:200px; font-size:0.9rem; line-height:1.5;"></textarea>
                    </div>
                    <div class="dd-form-row" style="margin-top:1.5rem;">
                        <label class="dd-label">Anbefalinger (Rediger bar)</label>
                        <textarea id="ai-modal-rec-edit" class="dd-input" style="min-height:150px; font-size:0.9rem; line-height:1.5;"></textarea>
                    </div>
                    <div id="ai-modal-result-metadata" style="margin-top:1rem; font-size:0.8rem; color:var(--gray-400); display:flex; justify-content:space-between;">
                        <span id="ai-result-agent-name"></span>
                        <span id="ai-result-time"></span>
                    </div>
                </div>
            `;

            const buttons = [
                { label: 'Annuller', class: 'dd-btn-secondary', onclick: 'App.modal.close()' },
                { label: 'Start AI Vurdering', class: 'dd-btn-primary', id: 'btn-submit-ai', onclick: 'App.elements.submitAIAssessment()', style: 'background:#db2777; border-color:#db2777;' }
            ];

            App.modal.show(App.utils.renderModal(body, buttons), 'AI Teknisk Vurdering', 'medium');

        } catch (e) {
            console.error(e);
            App.core.toast('error', 'Kunne ikke initialisere AI modul');
        }
    };

    // Override submitAIAssessment to handle the result editing view
    App.elements.submitAIAssessment = async function () {
        const agentId = document.getElementById('ai-agent-selector').value;
        const customPrompt = document.getElementById('ai-custom-prompt').value;
        const element = this.state.currentElement;
        if (!element || !agentId) return;

        const mediaCheckboxes = document.querySelectorAll('input[name="ai_media"]:checked');
        const mediaIds = Array.from(mediaCheckboxes).map(cb => cb.value);

        const selectorView = document.getElementById('ai-modal-selector-view');
        const processView = document.getElementById('ai-modal-process-view');
        const submitBtn = document.getElementById('btn-submit-ai');

        if (selectorView) selectorView.style.display = 'none';
        if (processView) processView.style.display = 'block';
        if (submitBtn) submitBtn.style.display = 'none';

        // Start animation
        this.startAILoadingAnimation('AI forbereder anmodning');

        let seconds = 0;
        const timer = setInterval(() => {
            seconds++;
            this.updateAIFlow('thinking', seconds); // Original updateAIFlow will still update dots/lines
        }, 1000);

        try {
            this.updateAIFlow('sent', 0); // This will restart animation with "AI behandler data"

            const res = await App.core.ajax('api.php?module=ai&action=run_assessment', {
                method: 'POST',
                body: {
                    agent_id: agentId,
                    element_id: element.id,
                    media_ids: mediaIds,
                    custom_prompt: customPrompt,
                    language: 'Dansk'
                }
            });

            clearInterval(timer);
            this.stopAILoadingAnimation();

            if (res.success || (res.data && res.data.success)) {
                this.updateAIFlow('done', seconds);
                const data = res.data || res;
                const assessment = data.assessment;

                setTimeout(() => {
                    // Transition to Result View
                    if (processView) processView.style.display = 'none';
                    const resultView = document.getElementById('ai-modal-result-view');
                    if (resultView) resultView.style.display = 'block';

                    // Populate fields
                    if (assessment) {
                        document.getElementById('ai-modal-obs-edit').value = assessment.observation || '';
                        document.getElementById('ai-modal-rec-edit').value = assessment.recommendation || '';
                    }
                    document.getElementById('ai-result-agent-name').innerText = 'Agent: ' + (data.agent_name || 'AI');
                    document.getElementById('ai-result-time').innerText = 'Tid: ' + seconds + 's';

                    // Change footer buttons
                    const footer = document.querySelector('.dd-modal-footer');
                    if (footer) {
                        footer.innerHTML = `
                            <button class="dd-btn dd-btn-secondary" onclick="App.modal.close()">Annuller</button>
                            <button class="dd-btn dd-btn-primary" style="background:#db2777; border-color:#db2777;" onclick="App.elements.applyAIResultFromModal()">Anvend på Element</button>
                        `;
                    }
                    
                    // Store the result temporarily on the element object for the apply function
                    element._pendingAIAssessment = assessment;
                }, 800);
            }
        } catch (e) {
            clearInterval(timer);
            this.stopAILoadingAnimation();
            App.core.toast('error', 'AI vurdering fejlede: ' + e.message);
            if (selectorView) selectorView.style.display = 'block';
            if (processView) processView.style.display = 'none';
            if (submitBtn) submitBtn.style.display = 'inline-block';
        }
    };

    /**
     * Apply the edited AI result from the modal to the element fields and save
     */
    App.elements.applyAIResultFromModal = async function() {
        const element = this.state.currentElement;
        if (!element) return;

        const obsText = document.getElementById('ai-modal-obs-edit').value;
        const recText = document.getElementById('ai-modal-rec-edit').value;

        // Apply to local state
        if (element._pendingAIAssessment) {
             element.ai_assessment = element._pendingAIAssessment;
             element.ai_assessment.observation = obsText;
             element.ai_assessment.recommendation = recText;
             element.ai_assessment_date = new Date().toLocaleString('da-DK');
             delete element._pendingAIAssessment;
        }

        // Apply to UI fields
        const descEl = document.getElementById('field-description');
        const recEl = document.getElementById('field-recommendation');
        if (descEl) descEl.value = obsText;
        if (recEl) recEl.value = recText;

        // Save to DB
        try {
            App.core.toast('info', 'Gemmer data...');
            await this.saveField('description', obsText);
            await this.saveField('recommendation', recText);
            
            // Re-render the AI section in the main view
            this.renderAIAssessment(element, false);
            
            App.modal.close();
            App.core.toast('success', 'AI vurdering anvendt og gemt.');
        } catch (e) {
            App.core.toast('error', 'Fejl ved gem: ' + e.message);
        }
    };

})();
</script>

<!-- Admin Comments Sidebar -->
<div id="admin-comments-sidebar" class="admin-sidebar">
    <div class="sidebar-header">
        <h3>Interne Noter</h3>
        <button onclick="App.elements.toggleCommentsSidebar()" class="close-btn">&times;</button>
    </div>
    
    <!-- Add Comment Section -->
    <div class="sidebar-add-comment">
        <textarea id="admin-comment-input" placeholder="Skriv en intern note..."></textarea>
        <button onclick="App.elements.addComment()" class="dd-btn dd-btn-primary dd-btn-block">Tilføj Note</button>
    </div>

    <div class="sidebar-content" id="admin-comments-list">
        <!-- Injected via JS -->
    </div>
</div>

<style>
/* Admin Sidebar Styles */
.admin-sidebar {
    position: fixed;
    top: 0;
    right: -400px; /* Hidden by default */
    width: 400px;
    height: 100vh;
    background: white;
    box-shadow: -4px 0 15px rgba(0,0,0,0.1);
    z-index: 10000;
    transition: right 0.3s ease;
    display: flex;
    flex-direction: column;
    border-left: 1px solid var(--border-color);
}
.admin-sidebar.open {
    right: 0;
}
.admin-sidebar .sidebar-header {
    padding: 1.5rem;
    border-bottom: 1px solid var(--border-color);
}
.admin-sidebar .sidebar-header h3 {
    margin: 0;
    font-size: 1.1rem;
    color: var(--text-primary);
    font-weight: 600;
}
.admin-sidebar .close-btn {
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: var(--text-secondary);
    padding: 0;
    line-height: 1;
}

/* Add Comment Section */
.sidebar-add-comment {
    padding: 1.5rem;
    background: #fff;
    border-bottom: 1px solid var(--border-color);
}
.sidebar-add-comment textarea {
    width: 100%;
    border: 1px solid var(--border-color);
    border-radius: 6px;
    padding: 0.75rem;
    font-size: 0.95rem;
    min-height: 80px;
    resize: vertical;
    margin-bottom: 0.75rem;
    font-family: inherit;
}
.sidebar-add-comment textarea:focus {
    outline: none;
    border-color: var(--primary-500);
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

.admin-sidebar .sidebar-content {
    flex: 1;
    overflow-y: auto;
    padding: 1.5rem;
    background: #f8fafc; /* Slight contrast for list */
}
.admin-comment-item {
    background: white;
    border: 1px solid var(--border-color);
    border-radius: 8px;
    padding: 1rem;
    margin-bottom: 1rem;
    box-shadow: 0 1px 2px rgba(0,0,0,0.03);
}
.admin-comment-meta {
    display: flex;
    justify-content: space-between;
    margin-bottom: 0.5rem;
    font-size: 0.75rem;
    color: var(--text-secondary);
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.025em;
}
.admin-comment-item.resolved {
    opacity: 0.6;
    background: #f0fdf4; /* Light green tint */
    border-left: 3px solid #22c55e;
}
.admin-comment-item.resolved .admin-comment-text {
    text-decoration: line-through;
    color: var(--text-secondary);
}
.admin-comment-text {
    white-space: pre-wrap;
    color: var(--text-primary);
    font-size: 0.95rem;
    line-height: 1.5;
}
.admin-comment-trigger {
    cursor: pointer;
    position: relative;
    color: var(--text-secondary);
    transition: all 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    border-radius: 6px;
}
.admin-comment-trigger:hover {
    background: #f1f5f9;
    color: var(--text-primary);
}
.admin-comment-badge {
    position: absolute;
    top: -5px;
    right: -5px;
    background: #ef4444;
    color: white;
    font-size: 0.7rem;
    font-weight: bold;
    min-width: 16px;
    height: 16px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px solid white;
}
</style>
