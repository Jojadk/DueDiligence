<!DOCTYPE html>
<html lang="da">
<head>
    <meta charset="UTF-8">
    <title><?php echo $report_title; ?> - <?php echo $project['name']; ?></title>
    <style>
        @page {
            size: A4 portrait;
            margin: 1.5cm;
        }
        @media print {
            .no-print { display: none; }
            * { -webkit-print-color-adjust: exact; }
        }
        body {
            font-family: 'Inter', 'Segoe UI', system-ui, sans-serif;
            font-size: 9pt;
            line-height: 1.4;
            color: #1e293b;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 100%;
        }
        header {
            border-bottom: 2px solid #3b82f6;
            margin-bottom: 20px;
            padding-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
        }
        h1 { margin: 0; color: #1e40af; font-size: 18pt; font-weight: 800; }
        .meta { text-align: right; color: #64748b; font-size: 8pt; text-transform: uppercase; letter-spacing: 0.05em; }
        
        .project-info {
            background: #f8fafc;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 30px;
            border: 1px solid #e2e8f0;
        }
        .project-info table { width: 100%; border: none; }
        .project-info td { padding: 4px 0; border: none; }
        .label { font-weight: bold; color: #64748b; width: 120px; }

        .building-header {
            background: #1e40af;
            color: white;
            padding: 10px 15px;
            border-radius: 4px;
            margin-top: 40px;
            margin-bottom: 20px;
            page-break-before: always;
        }
        .building-header:first-of-type {
            page-break-before: avoid;
            margin-top: 0;
        }
        .building-header h2 { margin: 0; font-size: 16pt; }

        .section-header {
            background: #f1f5f9;
            padding: 8px 12px;
            border-radius: 4px;
            margin-top: 25px;
            margin-bottom: 15px;
            page-break-after: avoid;
        }
        h3 { color: #1e40af; margin: 0; font-size: 13pt; }

        table.elements-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
            page-break-inside: auto;
        }
        table.elements-table tr {
            page-break-inside: avoid;
            page-break-after: auto;
        }
        table.elements-table th {
            background-color: #f8fafc;
            text-align: left;
            padding: 10px;
            border: 1px solid #e2e8f0;
            font-weight: 700;
            color: #475569;
            text-transform: uppercase;
            font-size: 7.5pt;
        }
        table.elements-table td {
            padding: 10px;
            border: 1px solid #e2e8f0;
            vertical-align: top;
        }
        
        .risk-container {
            display: flex;
            flex-wrap: wrap;
            gap: 4px;
        }
        .risk-tag {
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 8pt;
            font-weight: 800;
            display: inline-block;
            white-space: nowrap;
        }
        .risk-Rød { background: #fee2e2; color: #991b1b; }
        .risk-Gul { background: #fef9c3; color: #854d0e; }
        .risk-Grøn { background: #dcfce7; color: #166534; }
        .risk-Sort { background: #1e293b; color: #f8fafc; }
        .risk-Blå { background: #dbeafe; color: #1e40af; }

        /* Condition / Quality Colors */
        .risk-God { background: #dcfce7; color: #166534; }
        .risk-Fornuftig { background: #dbeafe; color: #1e40af; }
        .risk-Acceptabel { background: #fef9c3; color: #854d0e; }
        .risk-Forventet { background: #f1f5f9; color: #475569; }
        .risk-Dårlig { background: #fee2e2; color: #991b1b; }
        
        .rating-group { margin-bottom: 6px; }
        .rating-label { font-size: 7pt; color: #64748b; font-weight: 600; text-transform: uppercase; display: block; margin-bottom: 2px; }
        
        .price { text-align: right; font-family: 'JetBrains Mono', monospace; font-weight: 600; }
        
        .figure-box {
            text-align: center;
            margin-bottom: 10px;
        }
        .report-img {
            max-width: 100%;
            max-height: 140px;
            border-radius: 4px;
            object-fit: cover;
            border: 1px solid #e2e8f0;
        }
        .figure-caption {
            font-size: 7pt;
            color: #64748b;
            margin-top: 4px;
            font-style: italic;
        }
        
        .footer {
            margin-top: 50px;
            text-align: center;
            font-size: 8pt;
            color: #94a3b8;
        }
        .btn-print {
            position: fixed; top: 20px; right: 20px;
            background: #3b82f6; color: white; border: none;
            padding: 10px 20px; border-radius: 6px; cursor: pointer;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); z-index: 1000;
        }
        
        .content-label {
            font-weight: 700;
            color: #64748b;
            font-size: 7.5pt;
            text-transform: uppercase;
            margin-bottom: 4px;
            display: block;
        }
        .observation-text {
            color: #1e293b;
            margin-bottom: 10px;
        }
        .recommendation-text {
            color: #1e40af;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <button class="btn-print no-print" onclick="window.print()">Udskriv Rapport</button>

    <div class="container">
        <header>
            <div>
                <h1><?php echo $report_title; ?></h1>
                <p><?php echo $project['name']; ?></p>
            </div>
            <div class="meta">
                Dato: <?php echo $report_date; ?><br>
                Projektnr: <?php echo $project['id']; ?>
            </div>
        </header>

        <div class="project-info">
            <table>
                <tr>
                    <td class="label">Projekt:</td>
                    <td><?php echo $project['name']; ?></td>
                    <td class="label">Adresse:</td>
                    <td><?php echo $project['address'] ?? '-'; ?></td>
                </tr>
                <tr>
                    <td class="label">Kunde:</td>
                    <td><?php echo $project['customer_name'] ?? '-'; ?></td>
                    <td class="label">Status:</td>
                    <td><?php echo strtoupper($project['status'] ?? 'OPEN'); ?></td>
                </tr>
            </table>
        </div>

        <?php foreach ($buildings as $building): ?>
            <div class="building-header">
                <h2>Bygning: <?php echo htmlspecialchars($building['name']); ?></h2>
            </div>

            <?php 
            $gIdx = 1;

            foreach ($building['tree'] as $group): 
            ?>
                <div class="section-header">
                    <h3><?php echo $gIdx; ?>. <?php echo htmlspecialchars($group['name']); ?></h3>
                </div>
                    
                <table class="elements-table">
                    <thead>
                        <tr>
                            <th style="width: 22%;">Bygningsdel</th>
                            <th style="width: 20%;">Billededokumentation</th>
                            <th style="width: 15%;">Vurderinger</th>
                            <th style="width: 28%;">Observation & Anbefaling</th>
                            <th style="width: 15%;" class="price">Budget (DKK)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($group['children'])): ?>
                        <tr>
                            <td colspan="5" style="text-align: center; color: #94a3b8; font-style: italic;">Ingen under-elementer i denne kategori</td>
                        </tr>
                        <?php else: ?>
                            <?php 
                            $cIdx = 1;
                            foreach ($group['children'] as $el): 
                            ?>
                            <tr>
                                <td>
                                    <strong><?php echo $gIdx; ?>.<?php echo $cIdx; ?> <?php echo htmlspecialchars($el['name']); ?></strong>
                                    <?php 
                                    $qty = (float)($el['quantity'] ?? 0);
                                    if ($qty > 0): 
                                    ?>
                                        <?php echo number_format($qty, 2, ',', '.'); ?> <?php echo htmlspecialchars($el['unit'] ?? 'stk'); ?>
                                    <?php endif; ?>
                                    <br>
                                    
                                    <?php if (!empty($el['location'])): ?>
                                        <small style="color: #64748b;"><?php echo htmlspecialchars($el['location']); ?></small><br>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align: center;">
                                    <?php if (!empty($el['media'])): ?>
                                        <?php 
                                        $fIdx = 1;
                                        foreach ($el['media'] as $media): 
                                        ?>
                                            <div class="figure-box">
                                                <img src="<?php echo get_image_url($media['file_path']); ?>?t=<?php echo time(); ?>" class="report-img">
                                                <div class="figure-caption">Fig. <?php echo $gIdx; ?>.<?php echo $cIdx; ?>.<?php echo $fIdx++; ?>: <?php echo htmlspecialchars($media['caption'] ?? $el['name']); ?></div>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <div style="width: 100%; height: 60px; background: #f8fafc; border-radius: 4px; display: flex; align-items: center; justify-content: center; color: #cbd5e1; font-size: 8pt; border: 1px dashed #cbd5e1;">Ingen fotos</div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($el['risk_level'])): ?>
                                    <div class="rating-group">
                                        <span class="rating-label">Risiko</span>
                                        <div class="risk-container">
                                        <?php 
                                            $tags = preg_split('/[,\s]+/', $el['risk_level'], -1, PREG_SPLIT_NO_EMPTY);
                                            foreach ($tags as $tag):
                                                $tag = trim($tag);
                                                if(empty($tag) || $tag==='Ikke relevant') continue;
                                        ?>
                                            <span class="risk-tag risk-<?php echo htmlspecialchars($tag); ?>">
                                                <?php echo htmlspecialchars($tag); ?>
                                            </span>
                                        <?php endforeach; ?>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php 
                                    // Helper for checkboxes
                                    $renderCheckboxGroup = function($label, $valueString) {
                                        // Standard options from user request
                                        // Map Acceptabel -> Rimelig for display
                                        $options = ['God', 'Fornuftig', 'Rimelig', 'Dårlig'];
                                        
                                        // Parse values
                                        $selected = [];
                                        $parts = preg_split('/[,\s]+/', $valueString, -1, PREG_SPLIT_NO_EMPTY);
                                        foreach($parts as $p) {
                                            $p = trim($p);
                                            if ($p === 'Acceptabel') $p = 'Rimelig'; 
                                            $selected[] = $p;
                                        }

                                        echo '<div class="rating-group">';
                                        echo '<span class="rating-label">' . htmlspecialchars($label) . '</span>';
                                        echo '<div style="font-size: 8pt; line-height: 1.3;">';
                                        foreach ($options as $opt) {
                                            $isChecked = in_array($opt, $selected);
                                            // Using HTML entities for checkbox look
                                            $icon = $isChecked ? '&#9745;' : '&#9744;'; // ☑ vs ☐
                                            $style = $isChecked ? 'font-weight:bold; color:#000;' : 'color:#94a3b8;';
                                            echo '<span style="display:inline-block; margin-right:6px; ' . $style . '">' . $opt . $icon . '</span> '; // Label then box? Image shows "God[x]" (Label then box)
                                            // Actually image shows "God[x], Fornuftig[], ..."
                                        }
                                        echo '</div>';
                                        echo '</div>';
                                    };
                                    ?>

                                    <?php if (!empty($el['condition_rating'])): ?>
                                        <?php $renderCheckboxGroup('Tilstand', $el['condition_rating']); ?>
                                    <?php endif; ?>

                                    <?php if (!empty($el['quality_rating'])): ?>
                                        <?php $renderCheckboxGroup('Kvalitet', $el['quality_rating']); ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($el['description'])): ?>
                                        <span class="content-label">Observation</span>
                                        <div class="observation-text"><?php echo nl2br(htmlspecialchars($el['description'])); ?></div>
                                    <?php endif; ?>

                                    <?php if (!empty($el['recommendation'])): ?>
                                        <span class="content-label">Anbefaling</span>
                                        <div class="recommendation-text"><?php echo nl2br(htmlspecialchars($el['recommendation'])); ?></div>
                                    <?php endif; ?>
                                    
                                    <?php if (empty($el['description']) && empty($el['recommendation'])): ?>
                                        <span style="color: #cbd5e1; font-style: italic;">Ingen noter angivet</span>
                                    <?php endif; ?>
                                </td>
                                <td class="price">
                                    <?php if ($el['total_budget'] > 0): ?>
                                        <?php echo number_format($el['total_budget'], 0, ',', '.'); ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php 
                            $cIdx++;
                            endforeach; 
                            ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            <?php 
            $gIdx++;
            endforeach; 
            ?>
        <?php endforeach; ?>

        <div class="footer">
            Denne rapport er genereret af DueDiligence System &copy; <?php echo date('Y'); ?>
        </div>
    </div>
</body>
</html>
