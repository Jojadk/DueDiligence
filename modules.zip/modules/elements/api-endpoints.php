<?php
// modules/elements/api-endpoints.php
require_once __DIR__ . '/../../core/templates.php';

/**
 * Building Elements API Endpoints
 *
 * Comprehensive API for managing building elements with:
 * - Standard CRUD operations
 * - Budget management
 * - Media handling
 * - Version control
 * - Building management
 * - Collaborative editing (locks)
 * - Tree structure management
 */

function handle_api($action, $db)
{
    // Permission Checks
    switch ($action) {
        case 'get_comments':
        case 'add_comment':
        case 'edit_comment':
        case 'toggle_comment_resolved':
            require_permission('allow_view_all');
            break;

        case 'create':
        case 'store':
        case 'update':
        case 'delete':
        case 'update_field':
        case 'reorder':
        case 'move_node':
        case 'budget_save':
        case 'update_project_rounding':
        case 'update_element_rounding':
        case 'media_upload':
        case 'media_delete':
        case 'media_reorder':
        case 'media_update_caption':
        case 'media_save_annotations':
        case 'version_save':
        case 'version_restore':
        case 'building_create':
        case 'building_update':
        case 'building_delete':
        case 'reorder_buildings':
        case 'template_bulk_create':
            require_permission('allow_manage_projects'); // elements/buildings are managed via project permissions
            break;

        case 'element_delete': // Alias for delete
            require_permission('allow_manage_projects');
            return delete_element($db);

        case 'template_create':
        case 'template_update':
        case 'template_delete':
        case 'template_node_create':
        case 'template_node_update':
        case 'template_node_delete':
        case 'template_node_move':
            require_permission('allow_manage_configuration');
            break;
    }

    switch ($action) {
        // === ELEMENT CRUD ===
        case 'list':
        case 'list_standard':
            return list_elements_standard($db);

        case 'get':
        case 'get_detail':
            return get_element_detail($db);

        case 'get_building_summary':
            return get_building_summary($db);
        case 'get_stats':
            return get_element_stats($db);

        case 'create':
        case 'store':
            return create_element($db);

        case 'update':
            return update_element($db);

        case 'delete':
            return delete_element($db);

        case 'update_field':
            return update_element_field($db);

        case 'reorder':
            return reorder_elements($db);

        case 'template_list':
            return list_element_templates($db);

        // === COMMENTS ===
        case 'add_comment':
            return add_element_comment($db);
        case 'edit_comment':
            return edit_element_comment($db);
        case 'get_comments':
            return get_element_comments($db);
        case 'toggle_comment_resolved':
            return toggle_comment_resolved($db);

        case 'template_get_config':
            return template_get_config($db);

        case 'template_bulk_create':
            return template_bulk_create($db);

        case 'template_create':
            return template_create($db);
        case 'template_update':
            return template_update($db);
        case 'template_delete':
            return template_delete($db);
        case 'template_node_create':
            return template_node_create($db);
        case 'template_node_update':
            return template_node_update($db);
        case 'template_node_delete':
            return template_node_delete($db);
        case 'template_node_move':
            return template_node_move($db);

        case 'get_group_summary':
            return get_group_summary($db);

        // === REPORTING ===
        case 'get_html_report':
            return get_html_report($db);
        case 'get_budget_report':
            return get_budget_report($db);
        case 'get_summary_report':
            return get_summary_report($db);
        case 'get_light_report':
            return get_light_report($db);
        case 'get_interactive_report':
            return get_interactive_report($db);

        // === TREE STRUCTURE ===
        case 'get_tree':
            return get_element_tree($db);

        case 'move_node':
            return move_node($db);

        // === BUDGET ===
        case 'budget_get':
            return budget_get($db);

        case 'budget_save':
            return budget_save($db);

        case 'budget_search_catalog':
            return budget_search_catalog($db);

        case 'get_project_rounding':
            return get_project_rounding($db);

        case 'update_project_rounding':
            return update_project_rounding($db);

        case 'get_element_rounding':
            return get_element_rounding($db);

        case 'update_element_rounding':
            return update_element_rounding($db);

        // === MEDIA ===
        case 'media_list':
            return media_list($db);

        case 'media_upload':
            return media_upload($db);

        case 'media_delete':
            return media_delete($db);

        case 'media_reorder':
            return media_reorder($db);

        case 'media_update_caption':
            return media_update_caption($db);
        case 'media_get_detail':
            return media_get_detail($db);
        case 'media_save_annotations':
            return media_save_annotations($db);

        // === VERSION CONTROL ===
        case 'version_save':
            return version_save($db);

        case 'version_list':
            return version_list($db);

        case 'version_restore':
            return version_restore($db);

        case 'building_list':
            return building_list($db);

        case 'building_create':
            return building_create($db);

        case 'building_update':
            return building_update($db);

        case 'building_delete':
            return building_delete($db);
        case 'debug_data':
            return debug_data($db);

        case 'reorder_buildings':
            return reorder_buildings($db);


        // === LOCKING (Collaborative Editing) ===
        case 'lock_acquire':
            return lock_acquire($db);

        case 'lock_release':
            return lock_release($db);

        case 'lock_check':
            return lock_check($db);

        case 'lock_heartbeat':
            return lock_heartbeat($db);

        case 'sync_element':
            return sync_element($db);

        case 'export_excel':
        case 'export_pdf':
            return ['status' => 'success', 'message' => 'Export feature coming soon'];

        default:
            throw new Exception("Unknown elements action: " . $action);
    }
}

// ============================================================================
// ELEMENT CRUD OPERATIONS
// ============================================================================

function list_elements_standard($db)
{
    $projectId = isset($_GET['project_id']) ? (int) $_GET['project_id'] : 0;
    $buildingId = isset($_GET['building_id']) ? (int) $_GET['building_id'] : 0;

    if (!$projectId) {
        return ['data' => [], 'pagination' => []];
    }

    $where = ["e.project_id = ?"];
    $params = [$projectId];

    if ($buildingId) {
        $where[] = "e.building_id = ?";
        $params[] = $buildingId;
    }

    $whereSql = implode(' AND ', $where);

    // Optimized: Use subqueries for counts/sums to avoid joining large tables multiple times
    $stmt = $db->prepare(
        "SELECT e.*,
b.name AS building_name,
(SELECT COUNT(*) FROM element_media em WHERE em.element_id = e.id) as media_count,
(SELECT COUNT(*) FROM dd_system_Comments c WHERE c.bind_type = 'element' AND c.bind_id = e.id) as comment_count,
(SELECT COALESCE(SUM(bi.total_calculated), 0) FROM dd_budget_items bi WHERE bi.element_id = e.id) as total_budget
FROM v_dd_building_elements e
LEFT JOIN v_dd_buildings b ON e.building_id = b.id
WHERE $whereSql
ORDER BY e.sort_order ASC, e.created_at DESC"
    );
    $stmt->execute($params);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return ['data' => $data];
}

function get_element_detail($db)
{
    $idParam = $_GET['element_id'] ?? $_GET['id'] ?? '';
    $elementId = (int) str_replace('element-', '', $idParam);

    if (!$elementId) {
        throw new Exception("Element ID required");
    }

    $stmt = $db->prepare(
        "SELECT e.*,
                e.building_id,
                e.project_id,
                b.name AS building_name,
                p.name AS project_name,
                parent.name AS parent_name,
                COUNT(em.id) as media_count
        FROM v_dd_building_elements e
        LEFT JOIN v_dd_buildings b ON e.building_id = b.id
        LEFT JOIN v_dd_projects p ON e.project_id = p.id
        LEFT JOIN v_dd_building_elements parent ON e.parent_id = parent.id
        LEFT JOIN element_media em ON e.id = em.element_id
        WHERE e.id = ?
        GROUP BY e.id, b.name, p.name, parent.name"
    );
    $stmt->execute([$elementId]);
    $element = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$element) {
        throw new Exception("Element not found");
    }

    $requestProjectId = (int) ($_GET['project_id'] ?? 0);
    if ($requestProjectId > 0 && $element['project_id'] != $requestProjectId) {
        $msg = "Element $elementId belongs to project " . $element['project_id'] . ", requested project $requestProjectId";
        error_log("MISMATCH: $msg");
        throw new Exception($msg);
    }

    // Get budget summary
    $stmt = $db->prepare(
        "SELECT
COALESCE(SUM(amount_0_1), 0) as sum_0_1,
COALESCE(SUM(amount_1_2), 0) as sum_1_2,
COALESCE(SUM(amount_3_5), 0) as sum_3_5,
COALESCE(SUM(amount_5_10), 0) as sum_5_10
FROM v_dd_budget_items
WHERE element_id = ?"
    );
    $stmt->execute([$elementId]);
    $budget = $stmt->fetch(PDO::FETCH_ASSOC);

    $element['budget_summary'] = $budget;

    // Get media
    $stmt = $db->prepare(
        "SELECT * FROM element_media
WHERE element_id = ?
ORDER BY sort_order ASC, id ASC"
    );
    $stmt->execute([$elementId]);
    $element['media'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Ensure is_resolved column exists (self-healing migration)
    try {
        $db->query("SELECT is_resolved FROM dd_system_Comments LIMIT 1");
    } catch (Exception $e) {
        $db->exec("ALTER TABLE dd_system_Comments ADD COLUMN is_resolved TINYINT(1) DEFAULT 0 AFTER content");
    }

    // Get comments (internal notes)
    $stmt = $db->prepare("
        SELECT c.id, c.bind_type, c.bind_id, c.user_id, c.content as comment, c.is_resolved, c.created_at, u.name as user_name
        FROM dd_system_Comments c
        LEFT JOIN dd_users u ON c.user_id = u.id
        WHERE c.bind_type = 'element' AND c.bind_id = ?
        ORDER BY c.created_at DESC
    ");
    $stmt->execute([$elementId]);
    $element['comments'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $element;
}



function create_element($db)
{
    $data = json_decode(file_get_contents('php://input'), true);

    if (empty($data['project_id']) || empty($data['name'])) {
        throw new Exception("Project ID and Name are required");
    }

    // Get next sort_order
    $stmt = $db->prepare(
        "SELECT COALESCE(MAX(sort_order), 0) + 1 as next_order
FROM dd_building_Elements
WHERE project_id = ?"
    );
    $stmt->execute([$data['project_id']]);
    $nextOrder = $stmt->fetch(PDO::FETCH_ASSOC)['next_order'];

    $stmt = $db->prepare("
INSERT INTO dd_building_Elements (
project_id, building_id, parent_id, name, location,
element_type, description, recommendation,
condition_rating, risk_level,
estimated_cost, is_bcl, sort_order
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");

    $stmt->execute([
        $data['project_id'],
        $data['building_id'] ?? null,
        $data['parent_id'] ?? null,
        $data['name'],
        $data['location'] ?? '',
        $data['element_type'] ?? 'element',
        $data['description'] ?? '',
        $data['recommendation'] ?? '',
        $data['condition_rating'] ?? null,
        $data['risk_level'] ?? null,
        $data['estimated_cost'] ?? 0,
        $data['is_bcl'] ?? 0,
        $nextOrder
    ]);

    $elementId = $db->lastInsertId();

    // Handle custom fields if present
    if (!empty($data['custom_fields']) && is_array($data['custom_fields'])) {
        $stmt = $db->prepare(
            "INSERT INTO dd_custom_field_values (definition_id, bind_id, value)
VALUES (?, ?, ?)"
        );
        foreach ($data['custom_fields'] as $fieldId => $value) {
            $stmt->execute([$fieldId, $elementId, $value]);
        }
    }

    return [
        'id' => $elementId,
        'message' => 'Element created successfully'
    ];
}

function update_element($db)
{
    $data = json_decode(file_get_contents('php://input'), true);

    $elementId = $data['id'] ?? null;
    if (!$elementId) {
        throw new Exception("Element ID required");
    }

    // Build dynamic UPDATE query
    $fields = [];
    $values = [];

    $allowedFields = [
        'name',
        'location',
        'description',
        'recommendation',
        'condition_rating',
        'quality_rating',
        'risk_level',
        'quantity',
        'estimated_cost',
        'capex',
        'is_bcl',
        'building_id',
        'parent_id'
    ];

    foreach ($allowedFields as $field) {
        if (array_key_exists($field, $data)) {
            $fields[] = "$field = ?";
            $values[] = $data[$field];
        }
    }

    if (empty($fields)) {
        throw new Exception("No fields to update");
    }

    $values[] = $elementId;

    $stmt = $db->prepare(
        "UPDATE dd_building_Elements
SET " . implode(', ', $fields) . ", updated_at = CURRENT_TIMESTAMP
WHERE id = ?"
    );
    $stmt->execute($values);

    // Handle custom fields
    if (!empty($data['custom_fields']) && is_array($data['custom_fields'])) {
        $stmt = $db->prepare(
            "INSERT INTO dd_custom_field_values (definition_id, bind_id, value)
VALUES (?, ?, ?)
ON DUPLICATE KEY UPDATE value = VALUES(value)"
        );
        foreach ($data['custom_fields'] as $fieldId => $value) {
            $stmt->execute([$fieldId, $elementId, $value]);
        }
    }

    return ['message' => 'Element updated successfully'];
}

function update_element_field($db)
{
    $data = json_decode(file_get_contents('php://input'), true);

    $elementId = $data['element_id'] ?? $data['id'] ?? null;
    $field = $data['field'] ?? null;
    $value = $data['value'] ?? null;

    if (!$elementId || !$field) {
        throw new Exception("Element ID and field name required");
    }

    // Whitelist allowed fields for security
    $allowedFields = [
        'description',
        'recommendation',
        'notes',
        'risk_level',
        'condition_rating',
        'quality_rating',
        'capex',
        'is_bcl',
        'name',
        'location',
        'building_id',
        'parent_id'
    ];

    if (!in_array($field, $allowedFields)) {
        throw new Exception("Field not allowed for update");
    }

    // Data type normalization
    if ($field === 'capex' || $field === 'estimated_cost') {
        $value = (isset($value) && $value !== '') ? (float) $value : 0;
    } elseif ($field === 'building_id' || $field === 'parent_id') {
        $value = (isset($value) && $value !== '') ? (int) $value : null;
    } elseif ($field === 'is_bcl') {
        $value = $value ? 1 : 0;
    }

    $stmt = $db->prepare(
        "UPDATE dd_building_Elements
SET $field = ?, updated_at = CURRENT_TIMESTAMP
WHERE id = ?"
    );
    $stmt->execute([$value, $elementId]);

    return ['message' => 'Field updated successfully'];
}

function delete_element($db)
{
    $elementId = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
    if (!$elementId) {
        throw new Exception("ID required");
    }

    $stmt = $db->prepare("CALL sp_SoftDelete('element', ?)");
    $stmt->execute([$elementId]);

    return ['message' => 'Element and children soft-deleted successfully'];
}

/**
 * Move a single node (drag-and-drop operation)
 * Updates parent_id and sort_order, manages siblings
 */
function move_node($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $elementId = $data['element_id'] ?? null;
    $targetId = $data['target_id'] ?? null;
    $positionHint = $data['position'] ?? 0; // -1: before, -2: after, >=0: inside at index
    $newParentId = $data['new_parent_id'] ?? null;
    $targetType = $data['target_type'] ?? 'element';

    if (!$elementId) {
        throw new Exception('Element ID required');
    }

    $db->beginTransaction();
    try {
        // 1. Get current element data
        $stmt = $db->prepare("SELECT * FROM dd_building_Elements WHERE id = ?");
        $stmt->execute([$elementId]);
        $element = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$element)
            throw new Exception('Element not found');

        $oldParentId = $element['parent_id'];
        $oldPosition = $element['sort_order'];
        $oldBuildingId = $element['building_id'];

        // 2. Identify New Location Details
        $newBuildingId = $oldBuildingId;
        $newPosition = 0;

        if ($targetType === 'building') {
            // Target is a building -> move to root of this building
            $newBuildingId = $targetId;
            $newParentId = null;
            if ($positionHint < 0) {
                // Should not happen with current UI, but for safety:
// Elements shouldn't be "before" buildings. Treat as inside.
                $positionHint = 0;
            }

            if ($positionHint >= 0) {
                // Appending to the end of building's root
                $stmt = $db->prepare("SELECT COALESCE(MAX(sort_order), -1) + 1 as next_order FROM dd_building_Elements WHERE building_id
= ? AND parent_id IS NULL");
                $stmt->execute([$newBuildingId]);
                $newPosition = $stmt->fetch(PDO::FETCH_ASSOC)['next_order'];
            }
        } else {
            // Target is an element
            $stmt = $db->prepare("SELECT parent_id, sort_order, building_id FROM dd_building_Elements WHERE id = ?");
            $stmt->execute([$targetId]);
            $target = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$target)
                throw new Exception('Target element not found');

            $newBuildingId = $target['building_id'];

            if ($positionHint === -1) { // BEFORE
                $newParentId = $target['parent_id'];
                $newPosition = $target['sort_order'];
            } else if ($positionHint === -2) { // AFTER
                $newParentId = $target['parent_id'];
                $newPosition = $target['sort_order'] + 1;
            } else { // INSIDE (as child)
                $newParentId = $targetId;
                $stmt = $db->prepare("SELECT COALESCE(MAX(sort_order), -1) + 1 as next_order FROM dd_building_Elements WHERE parent_id =
?");
                $stmt->execute([$newParentId]);
                $newPosition = $stmt->fetch(PDO::FETCH_ASSOC)['next_order'];
            }
        }

        // 3. Remove from Old Position
        if ($oldParentId !== null) {
            $stmt = $db->prepare("UPDATE dd_building_Elements SET sort_order = sort_order - 1 WHERE parent_id = ? AND sort_order >
?");
            $stmt->execute([$oldParentId, $oldPosition]);
        } else {
            $stmt = $db->prepare("UPDATE dd_building_Elements SET sort_order = sort_order - 1 WHERE parent_id IS NULL AND
building_id = ? AND sort_order > ?");
            $stmt->execute([$oldBuildingId, $oldPosition]);
        }

        // 4. Open Gap at New Position
        if ($newParentId !== null) {
            $stmt = $db->prepare("UPDATE dd_building_Elements SET sort_order = sort_order + 1 WHERE parent_id = ? AND sort_order >=
?");
            $stmt->execute([$newParentId, $newPosition]);
        } else {
            $stmt = $db->prepare("UPDATE dd_building_Elements SET sort_order = sort_order + 1 WHERE parent_id IS NULL AND
building_id = ? AND sort_order >= ?");
            $stmt->execute([$newBuildingId, $newPosition]);
        }

        // 5. Final Move
        $stmt = $db->prepare("UPDATE dd_building_Elements SET parent_id = ?, sort_order = ?, building_id = ? WHERE id = ?");
        $stmt->execute([$newParentId, $newPosition, $newBuildingId, $elementId]);

        $db->commit();
        return ['success' => true, 'message' => 'Element moved successfully'];
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

function reorder_elements($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $items = $data['items'] ?? [];

    if (empty($items)) {
        throw new Exception("No items to reorder");
    }

    $db->beginTransaction();
    try {
        foreach ($items as $item) {
            $stmt = $db->prepare(
                "UPDATE dd_building_Elements
SET sort_order = ?, parent_id = ?
WHERE id = ?"
            );
            $stmt->execute([
                $item['order'],
                $item['parent_id'] ?? null,
                $item['id']
            ]);
        }
        $db->commit();
        return ['message' => 'Elements reordered successfully'];
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

// ============================================================================
// LEGACY SUPPORT
// ============================================================================

function get_elements_report($db)
{
    $projectId = (int) ($_GET['project_id'] ?? 0);
    if (!$projectId) {
        throw new Exception("Project ID required");
    }

    $stmt = $db->prepare(
        "SELECT e.*, b.name AS building_name
FROM dd_building_Elements e
LEFT JOIN dd_buildings b ON e.building_id = b.id
WHERE e.project_id = ?
ORDER BY e.sort_order ASC, e.created_at DESC"
    );
    $stmt->execute([$projectId]);
    $elements = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calculate summary
    $capex = 0;
    $redflags = 0;
    foreach ($elements as $el) {
        $capex += (float) ($el['capex'] ?? 0);
        if (in_array($el['risk_level'] ?? '', ['Rød', 'Sort'])) {
            $redflags++;
        }
    }

    return [
        'summary' => [
            'capex' => $capex,
            'redflags' => $redflags,
            'total_elements' => count($elements)
        ],
        'data' => $elements
    ];
}

// ============================================================================
// BATCH DATA FETCHING (OPTIMIZATION FOR N+1)
// ============================================================================



function get_html_report($db)
{
    $projectId = (int) ($_GET['project_id'] ?? 0);
    if (!$projectId) {
        throw new Exception("Project ID required");
    }

    // Fetch Project
    $stmt = $db->prepare("SELECT * FROM dd_projects WHERE id = ?");
    $stmt->execute([$projectId]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$project) {
        throw new Exception("Project not found");
    }

    // Optimized Data Fetching (Batch)
    $buildings = get_project_data_batch($db, $projectId);

    $data = [
        'project' => $project,
        'buildings' => $buildings,
        'report_title' => 'Tilstandsrapport',
        'report_date' => date('d.m.Y')
    ];

    $html = render_template(__DIR__ . '/templates/report_a4.tpl', $data);

    header('Content-Type: text/html; charset=utf-8');
    echo $html;
    exit;
}

function get_budget_report($db)
{
    $projectId = (int) ($_GET['project_id'] ?? 0);
    if (!$projectId) {
        throw new Exception("Project ID required");
    }

    // Fetch Project
    $stmt = $db->prepare("SELECT * FROM dd_projects WHERE id = ?");
    $stmt->execute([$projectId]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);

    // Optimized Data Fetching (Batch)
    $buildings = get_project_data_batch($db, $projectId);

    // Flatten buildings/elements into items for the landscape budget report
    $items = [];
    foreach ($buildings as $b) {
        $buildingName = $b['name'];

        $flatten = function ($elements) use (&$flatten, &$items, $buildingName) {
            foreach ($elements as $el) {
                foreach ($el['budget_items'] as $bi) {
                    $item = $bi;
                    $item['building_name'] = $buildingName;
                    $item['element_name'] = $el['name'];
                    $item['rounding_override'] = $el['rounding_override'];
                    $items[] = $item;
                }
                if (!empty($el['children'])) {
                    $flatten($el['children']);
                }
            }
        };

        if (!empty($b['tree'])) {
            $flatten($b['tree']);
        }
    }

    $data = [
        'project' => $project,
        'items' => $items,
        'report_title' => 'Budgetoversigt',
        'report_date' => date('d.m.Y')
    ];

    $html = render_template(__DIR__ . '/templates/report_budget_landscape.tpl', $data);

    header('Content-Type: text/html; charset=utf-8');
    echo $html;
    exit;
}

function get_summary_report($db)
{
    $projectId = (int) ($_GET['project_id'] ?? 0);
    if (!$projectId) {
        throw new Exception("Project ID required");
    }

    // 1. Fetch Project
    $stmt = $db->prepare("
SELECT p.*, c.name as customer_name, c.address as customer_address
FROM dd_projects p
LEFT JOIN dd_customers c ON p.customer_id = c.id
WHERE p.id = ?
");
    $stmt->execute([$projectId]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$project) {
        throw new Exception("Project not found");
    }

    // Optimized Data Fetching (Batch)
    $buildings = get_project_data_batch($db, $projectId);

    // Fetch Metadata
    $meta = get_project_meta($db, $projectId);
    $reportConfig = $meta['report_config'] ?? [];
    $constants = $meta['constants'] ?? [];

    $data = [
        'project' => $project,
        'buildings' => $buildings,
        'report_config' => $reportConfig,
        'constants' => $constants,
        'report_title' => 'Sammenfatning',
        'report_date' => date('d.m.Y')
    ];

    $html = render_template(__DIR__ . '/templates/report_summary_landscape.tpl', $data);
    header('Content-Type: text/html; charset=utf-8');
    echo $html;
    exit;
}


// ============================================================================
// TREE STRUCTURE
// ============================================================================

function get_element_tree($db)
{
    $projectId = (int) ($_GET['project_id'] ?? 0);
    $buildingId = isset($_GET['building_id']) ? (int) $_GET['building_id'] : null;

    if (!$projectId) {
        throw new Exception("Project ID required");
    }

    // 1. Fetch Buildings
    $buildingWhere = "project_id = ?";
    $buildingParams = [$projectId];
    if ($buildingId) {
        $buildingWhere .= " AND id = ?";
        $buildingParams[] = $buildingId;
    }

    $stmt = $db->prepare("SELECT id, name FROM dd_buildings WHERE $buildingWhere ORDER BY name ASC");
    $stmt->execute($buildingParams);
    $buildings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 2. Fetch Elements
    $elementWhere = "e.project_id = ?";
    $elementParams = [$projectId];
    if ($buildingId) {
        $elementWhere .= " AND e.building_id = ?";
        $elementParams[] = $buildingId;
    }

    $stmt = $db->prepare(
        "SELECT e.id, e.parent_id, e.name, e.location, e.sort_order, e.risk_level, e.building_id, e.project_id, 'element' as type,
        (SELECT COUNT(*) FROM dd_system_Comments c WHERE c.bind_type = 'element' AND c.bind_id = e.id) as comment_count
FROM dd_building_Elements e
WHERE $elementWhere
ORDER BY e.sort_order ASC, e.id ASC"
    );
    $stmt->execute($elementParams);
    $rawElements = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Explicitly filter for project safety
    $elements = [];
    foreach ($rawElements as $el) {
        if ($el['project_id'] == $projectId) {
            $elements[] = $el;
        } else {
            // Log this strictly - we need to know if this happens
            $msg = "DATA INTEGRITY ERROR: Element " . $el['id'] . " linked to Project " . $el['project_id'] . " returned for Project $projectId";
            // Check for Logger class availability or use error_log
            error_log($msg);
        }
    }

    // Build internal element tree
    $byId = [];
    foreach ($elements as $el) {
        $el['children'] = [];
        $byId[$el['id']] = $el;
    }

    $elementTree = [];
    foreach ($byId as $id => &$node) {
        if ($node['parent_id'] && isset($byId[$node['parent_id']])) {
            $byId[$node['parent_id']]['children'][] = &$node;
        } else {
            $elementTree[] = &$node;
        }
    }
    unset($node); // Fix: Prevent reference bug during subsequent loops

    // 3. Map elements to buildings (Optimized: O(N) instead of O(N*M))
    $nodesByBuilding = [];
    foreach ($elementTree as $node) {
        $nodesByBuilding[$node['building_id']][] = $node;
    }

    $tree = [];
    foreach ($buildings as $b) {
        $b['type'] = 'building';
        $b['children'] = $nodesByBuilding[$b['id']] ?? [];
        $tree[] = $b;
    }

    return ['tree' => $tree];
}

// Redundant move_tree_node removed - using enterprise version below

// ============================================================================
// BUDGET OPERATIONS
// ============================================================================

function budget_get($db)
{
    $elementId = $_GET['element_id'] ?? $_GET['id'] ?? null;
    if (!$elementId) {
        throw new Exception('Element ID required');
    }

    $stmt = $db->prepare(
        'SELECT bi.*, pc.description as catalog_name, pc.unit as catalog_unit
FROM dd_budget_items bi
LEFT JOIN price_catalogs pc ON bi.price_catalog_id = pc.id
WHERE bi.element_id = ?
ORDER BY bi.sort_order ASC, bi.id ASC'
    );
    $stmt->execute([$elementId]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calculate totals
    $totals = [
        'amount_0_1' => 0,
        'amount_1_2' => 0,
        'amount_3_5' => 0,
        'amount_5_10' => 0,
        'total' => 0
    ];

    foreach ($items as $item) {
        $totals['amount_0_1'] += $item['amount_0_1'] ?? 0;
        $totals['amount_1_2'] += $item['amount_1_2'] ?? 0;
        $totals['amount_3_5'] += $item['amount_3_5'] ?? 0;
        $totals['amount_5_10'] += $item['amount_5_10'] ?? 0;
        $totals['total'] += $item['total_calculated'] ?? 0;
    }

    return [
        'items' => $items,
        'totals' => $totals
    ];
}

function budget_save($db)
{
    $data = json_decode(file_get_contents('php://input'), true);

    $elementId = $data['element_id'] ?? $data['id'] ?? null;
    $items = $data['items'] ?? [];

    if (!$elementId) {
        throw new Exception('Element ID required');
    }

    $db->beginTransaction();
    try {
        // Delete existing items
        $stmt = $db->prepare('DELETE FROM dd_budget_items WHERE element_id = ?');
        $stmt->execute([$elementId]);

        $grandTotal = 0;

        // Insert new items
        $stmtInsert = $db->prepare(
            'INSERT INTO dd_budget_items
(element_id, description, quantity, unit, unit_price,
amount_0_1, amount_1_2, amount_3_5, amount_5_10,
total_calculated, price_catalog_id, sort_order)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );

        foreach ($items as $index => $item) {
            $unitPrice = floatval($item['unit_price'] ?? 0);
            $quantity = floatval($item['quantity'] ?? 0);
            $total = $unitPrice * $quantity;
            $grandTotal += $total;

            $stmtInsert->execute([
                $elementId,
                $item['description'] ?? '',
                $quantity,
                $item['unit'] ?? 'stk',
                $unitPrice,
                floatval($item['amount_0_1'] ?? 0),
                floatval($item['amount_1_2'] ?? 0),
                floatval($item['amount_3_5'] ?? 0),
                floatval($item['amount_5_10'] ?? 0),
                $total,
                $item['price_catalog_id'] ?? null,
                $index // sort_order
            ]);
        }

        // Update element CAPEX
        $stmt = $db->prepare("UPDATE dd_building_Elements SET capex = ? WHERE id = ?");
        $stmt->execute([$grandTotal, $elementId]);

        $db->commit();
        return [
            'total' => $grandTotal,
            'message' => 'Budget saved successfully'
        ];

    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

function budget_search_catalog($db)
{
    $query = $_GET['search'] ?? $_GET['q'] ?? '';
    $page = max(1, intval($_GET['page'] ?? 1));
    $perPage = 20;
    $offset = ($page - 1) * $perPage;

    if (strlen($query) < 2) {
        return ['data' => []];
    }

    $searchTerm = '%' . $query . '%';

    // Combine Price Catalogs and Bundles
    // Note: We select specific columns to ensure schema compatibility between unions
    $sql = "
        (SELECT 
            id, 
            item_code, 
            description as name, 
            unit, 
            unit_price, 
            'item' as type
         FROM price_catalogs
         WHERE description LIKE ? OR item_code LIKE ?)
        UNION ALL
        (SELECT 
            id, 
            NULL as item_code, 
            name, 
            unit, 
            total_price as unit_price, 
            'bundle' as type
         FROM dd_price_catalog_bundles
         WHERE name LIKE ? OR description LIKE ? OR tags LIKE ?)
        ORDER BY name
        LIMIT $perPage OFFSET $offset
    ";

    $stmt = $db->prepare($sql);
    // Bind parameters: 2 for first query, 3 for second query
    $stmt->execute([
        $searchTerm,
        $searchTerm,             // Items
        $searchTerm,
        $searchTerm,
        $searchTerm // Bundles
    ]);

    return ['data' => $stmt->fetchAll(PDO::FETCH_ASSOC)];
}

/**
 * Get Project Rounding Level
 */
function get_project_rounding($db)
{
    $projectId = $_GET['project_id'] ?? null;
    if (!$projectId) {
        throw new Exception('Project ID required');
    }

    $stmt = $db->prepare('SELECT rounding_level FROM dd_projects WHERE id = ?');
    $stmt->execute([$projectId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    return [
        'rounding_level' => $result['rounding_level'] ?? 0.00
    ];
}

/**
 * Update Project Rounding Level
 */
function update_project_rounding($db)
{
    $projectId = $_POST['project_id'] ?? null;
    $roundingLevel = $_POST['rounding_level'] ?? 0.00;

    if (!$projectId) {
        throw new Exception('Project ID required');
    }

    $stmt = $db->prepare('UPDATE dd_projects SET rounding_level = ? WHERE id = ?');
    $stmt->execute([$roundingLevel, $projectId]);

    return ['success' => true, 'rounding_level' => $roundingLevel];
}

/**
 * Get Element Rounding Override
 */
function get_element_rounding($db)
{
    $elementId = $_GET['element_id'] ?? null;
    if (!$elementId) {
        throw new Exception('Element ID required');
    }

    $stmt = $db->prepare('SELECT rounding_override FROM dd_building_Elements WHERE id = ?');
    $stmt->execute([$elementId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    return [
        'rounding_override' => $result['rounding_override']
    ];
}

/**
 * Update Element Rounding Override
 */
function update_element_rounding($db)
{
    // Try to get data from JSON body first (since frontend sends JSON)
    $input = json_decode(file_get_contents('php://input'), true);
    if (json_last_error() === JSON_ERROR_NONE && !empty($input)) {
        $elementId = $input['element_id'] ?? null;
        $roundingOverride = $input['rounding_override'] ?? null;
    } else {
        // Fallback to standard POST
        $elementId = $_POST['element_id'] ?? null;
        $roundingOverride = $_POST['rounding_override'] ?? null;
    }

    if (!$elementId) {
        throw new Exception('Element ID required');
    }

    // NULL means use project default
    $value = (isset($roundingOverride) && $roundingOverride !== '') ? (float) $roundingOverride : null;
    $stmt = $db->prepare('UPDATE dd_building_Elements SET rounding_override = ? WHERE id = ?');
    $stmt->execute([$value, $elementId]);

    return ['success' => true, 'rounding_override' => $roundingOverride];
}

// ============================================================================
// MEDIA OPERATIONS
// ============================================================================

function media_list($db)
{
    $elementId = $_GET['element_id'] ?? $_GET['id'] ?? null;
    if (!$elementId) {
        throw new Exception('Element ID required');
    }

    $stmt = $db->prepare(
        'SELECT * FROM element_media
WHERE element_id = ?
ORDER BY sort_order ASC, id ASC'
    );
    $stmt->execute([$elementId]);

    return ['data' => $stmt->fetchAll(PDO::FETCH_ASSOC)];
}

function media_upload($db)
{
    $elementId = $_POST['element_id'] ?? $_POST['id'] ?? null;
    $projectId = $_POST['project_id'] ?? null;

    if (!$elementId) {
        throw new Exception('Element ID required');
    }

    // Change key to match frontend 'images[]'
    if (empty($_FILES['images'])) {
        throw new Exception('No files uploaded');
    }

    $uploadedFiles = [];
    $files = $_FILES['images'];

    // Normalize file array
    $fileCount = is_array($files['name']) ? count($files['name']) : 1;

    // Use centralized Upload Path
    $baseDir = UPLOAD_PATH;

    // Project specific folder
    $subDir = $projectId ? 'project_' . (int) $projectId . '/' : '';
    $uploadDir = $baseDir . $subDir;

    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    for ($i = 0; $i < $fileCount; $i++) {
        $name = is_array($files['name']) ? $files['name'][$i] : $files['name'];
        $tmpName = is_array($files['tmp_name']) ? $files['tmp_name'][$i] : $files['tmp_name'];
        $type = is_array($files['type']) ? $files['type'][$i] : $files['type'];

        // Validate file type
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (!in_array($type, $allowedTypes)) {
            continue;
        }

        $ext = pathinfo($name, PATHINFO_EXTENSION);
        $uniqueId = uniqid();
        $originalName = 'original_' . $uniqueId . '.' . $ext;
        $webpName = 'img_' . $uniqueId . '.webp';

        // Paths for DB and filesystem
        $originalDbPath = $subDir . $originalName;
        $originalDest = $uploadDir . $originalName;
        $webpDbPath = $subDir . $webpName;
        $webpDest = $uploadDir . $webpName;

        // 1. Save Original raw file
        if (!move_uploaded_file($tmpName, $originalDest)) {
            continue;
        }

        // 2. Process Image for WebP (using the saved original as source)
        $image = null;
        switch (strtolower($type)) {
            case 'image/jpeg':
            case 'image/jpg':
                $image = @imagecreatefromjpeg($originalDest);
                break;
            case 'image/png':
                $image = @imagecreatefrompng($originalDest);
                break;
            case 'image/webp':
                $image = @imagecreatefromwebp($originalDest);
                break;
            case 'image/gif':
                $image = @imagecreatefromgif($originalDest);
                break;
        }

        $success = false;
        if ($image) {
            // Fix orientation if JPEG
            if (function_exists('exif_read_data') && ($type === 'image/jpeg' || $type === 'image/jpg')) {
                $exif = @exif_read_data($originalDest);
                if ($exif && !empty($exif['Orientation'])) {
                    switch ($exif['Orientation']) {
                        case 3:
                            $image = imagerotate($image, 180, 0);
                            break;
                        case 6:
                            $image = imagerotate($image, -90, 0);
                            break;
                        case 8:
                            $image = imagerotate($image, 90, 0);
                            break;
                    }
                }
            }

            // Save as WebP with centralized quality
            if (imagewebp($image, $webpDest, IMAGE_QUALITY)) {
                imagedestroy($image);
                $success = true;
            } else {
                imagedestroy($image);
                $success = copy($originalDest, $webpDest);
            }
        } else {
            $success = copy($originalDest, $webpDest);
        }

        if ($success) {
            // Get next sort order
            $stmt = $db->prepare(
                'SELECT COALESCE(MAX(sort_order), 0) + 1 as next_order
FROM element_media
WHERE element_id = ?'
            );
            $stmt->execute([$elementId]);
            $order = $stmt->fetch(PDO::FETCH_ASSOC)['next_order'];

            $stmt = $db->prepare(
                'INSERT INTO element_media (element_id, file_path, original_path, media_type, sort_order)
VALUES (?, ?, ?, ?, ?)'
            );
            $stmt->execute([$elementId, $webpDbPath, $originalDbPath, 'image', $order]);

            $uploadedFiles[] = [
                'id' => $db->lastInsertId(),
                'file_path' => $webpDbPath,
                'original_path' => $originalDbPath,
                'url' => get_image_url($webpDbPath)
            ];
        }
    }

    return [
        'uploaded' => count($uploadedFiles),
        'files' => $uploadedFiles
    ];
}

function media_delete($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $mediaId = $data['media_id'] ?? $_POST['media_id'] ?? $_GET['media_id'] ?? null;
    if (!$mediaId) {
        throw new Exception('Media ID required');
    }

    // Get media info
    $stmt = $db->prepare('SELECT * FROM element_media WHERE id = ?');
    $stmt->execute([$mediaId]);
    $media = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$media) {
        throw new Exception('Media not found');
    }

    // Delete web-friendly file
    $filePath = __DIR__ . '/../../assets/uploads/' . $media['file_path'];
    if (file_exists($filePath)) {
        @unlink($filePath);
    }

    // Delete original file
    if (!empty($media['original_path'])) {
        $originalPath = __DIR__ . '/../../assets/uploads/' . $media['original_path'];
        if (file_exists($originalPath)) {
            @unlink($originalPath);
        }
    }

    // Delete from database
    $stmt = $db->prepare('DELETE FROM element_media WHERE id = ?');
    $stmt->execute([$mediaId]);

    return ['message' => 'Media deleted successfully'];
}

function media_reorder($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $items = $data['items'] ?? [];

    if (empty($items)) {
        throw new Exception('No items to reorder');
    }

    $db->beginTransaction();
    try {
        foreach ($items as $item) {
            $stmt = $db->prepare('UPDATE element_media SET sort_order = ? WHERE id = ?');
            $stmt->execute([$item['order'], $item['id']]);
        }
        $db->commit();
        return ['message' => 'Media reordered successfully'];
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

function media_update_caption($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $mediaId = $data['media_id'] ?? null;
    $caption = $data['caption'] ?? '';

    if (!$mediaId) {
        throw new Exception('Media ID required');
    }

    $stmt = $db->prepare('UPDATE element_media SET caption = ? WHERE id = ?');
    $stmt->execute([$caption, $mediaId]);

    return ['message' => 'Caption updated successfully'];
}

function media_get_detail($db)
{
    $mediaId = $_GET['media_id'] ?? null;
    if (!$mediaId) {
        throw new Exception('Media ID required');
    }

    $stmt = $db->prepare('SELECT * FROM element_media WHERE id = ?');
    $stmt->execute([$mediaId]);
    $media = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$media) {
        throw new Exception('Media not found');
    }

    return $media;
}

function media_save_annotations($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $mediaId = $data['media_id'] ?? null;
    $annotations = $data['annotations'] ?? null;
    $imageData = $data['image_data'] ?? null;
    $isSnapshot = $data['is_snapshot'] ?? false;

    if (!$mediaId) {
        throw new Exception('Media ID required');
    }

    // Surgical column addition (without IF NOT EXISTS if not supported)
    try {
        $stmt = $db->query("SHOW COLUMNS FROM element_media LIKE 'updated_at'");
        if (!$stmt->fetch()) {
            $db->exec("ALTER TABLE element_media ADD updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
        }
    } catch (Exception $e) {
        // Fallback for different dialects
        try {
            $db->exec("ALTER TABLE element_media ADD COLUMN updated_at TIMESTAMP");
        } catch (Exception $ee) {
        }
    }

    // Get media info and project name for naming
    $stmt = $db->prepare('
SELECT m.element_id, m.file_path, m.original_path, p.name as project_name, p.id as project_id
FROM element_media m
JOIN dd_building_Elements e ON m.element_id = e.id
JOIN dd_buildings b ON e.building_id = b.id
JOIN dd_projects p ON b.project_id = p.id
WHERE m.id = ?
');
    $stmt->execute([$mediaId]);
    $media = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$media) {
        // Fallback if joined tables fail (shouldn't happen with valid media)
        $stmt = $db->prepare('SELECT element_id, file_path, original_path FROM element_media WHERE id = ?');
        $stmt->execute([$mediaId]);
        $media = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    if (!$media) {
        throw new Exception('Media not found');
    }

    $targetPath = $media['file_path'];
    $newMediaId = $mediaId;

    if ($isSnapshot) {
        // Create snapshots directory
        $snapshotDir = __DIR__ . '/../../assets/uploads/snapshots';
        if (!file_exists($snapshotDir)) {
            @mkdir($snapshotDir, 0777, true);
        }

        // Clean project name for filename
        $projName = preg_replace('/[^a-zA-Z0-9_\-]/', '', $media['project_name'] ?? 'Project' . ($media['project_id'] ?? ''));
        $timestamp = date('dmy_His');
        $ext = pathinfo($media['file_path'], PATHINFO_EXTENSION) ?: 'webp';

        // Final snapshot path relative to assets/uploads
        $newPath = 'snapshots/' . $projName . '_snapshot_' . $timestamp . '.' . $ext;
        $targetPath = $newPath;

        $stmt = $db->prepare(
            'INSERT INTO element_media (element_id, file_path, original_path, media_type, caption, sort_order)
SELECT element_id, ?, original_path, "snapshot", "Snapshot", (SELECT COALESCE(MAX(sort_order),0)+1 FROM element_media
WHERE element_id = ?)
FROM element_media WHERE id = ?'
        );
        $stmt->execute([$newPath, $media['element_id'], $mediaId]);
        $newMediaId = $db->lastInsertId();
    }

    if ($imageData) {
        $pattern = '/^data:image\/(webp|jpeg|png);base64,/i';
        if (preg_match($pattern, $imageData)) {
            $encodedData = preg_replace($pattern, '', $imageData);
            $decodedData = base64_decode($encodedData);

            $fullPath = __DIR__ . '/../../assets/uploads/' . $targetPath;
            // Ensure directory exists for snapshots if they use a subfolder (usually they don't here)
            file_put_contents($fullPath, $decodedData);
        }
    }

    // Update with extra safety for column existence
    try {
        $stmt = $db->prepare('UPDATE element_media SET annotations = ?, updated_at = NOW() WHERE id = ?');
        $stmt->execute([is_string($annotations) ? $annotations : json_encode($annotations), $newMediaId]);
    } catch (Exception $e) {
        // If updated_at still fails, try without it
        $stmt = $db->prepare('UPDATE element_media SET annotations = ? WHERE id = ?');
        $stmt->execute([is_string($annotations) ? $annotations : json_encode($annotations), $newMediaId]);
    }

    return [
        'message' => $isSnapshot ? 'Snapshot gemt' : 'Markeringer gemt',
        'media_id' => $newMediaId
    ];
}

// ============================================================================
// VERSION CONTROL
// ============================================================================

function version_save($db)
{
    $data = json_decode(file_get_contents('php://input'), true);

    $projectId = $data['project_id'] ?? null;
    $versionNumber = $data['version_number'] ?? '1.0';
    $versionNote = $data['version_note'] ?? '';
    $internalRemark = $data['internal_remark'] ?? '';

    if (!$projectId) {
        throw new Exception('Project ID required');
    }

    // Capture snapshot of all elements
    $stmt = $db->prepare(
        'SELECT * FROM dd_building_Elements WHERE project_id = ? ORDER BY sort_order ASC'
    );
    $stmt->execute([$projectId]);
    $elements = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $versionData = [
        'elements' => $elements,
        'timestamp' => date('Y-m-d H:i:s'),
        'version_number' => $versionNumber
    ];

    $stmt = $db->prepare(
        'INSERT INTO project_versions
(project_id, version_number, version_note, internal_remark, version_data, created_by)
VALUES (?, ?, ?, ?, ?, ?)'
    );

    $userId = $_SESSION['user_id'] ?? 1;

    $stmt->execute([
        $projectId,
        $versionNumber,
        $versionNote,
        $internalRemark,
        json_encode($versionData),
        $userId
    ]);

    return [
        'version_id' => $db->lastInsertId(),
        'message' => 'Version saved successfully'
    ];
}

function version_list($db)
{
    $projectId = $_GET['project_id'] ?? null;
    if (!$projectId) {
        throw new Exception('Project ID required');
    }

    $stmt = $db->prepare(
        'SELECT pv.*, u.name as created_by_name
FROM project_versions pv
LEFT JOIN dd_users u ON pv.created_by = u.id
WHERE pv.project_id = ?
ORDER BY pv.created_at DESC'
    );
    $stmt->execute([$projectId]);

    return ['data' => $stmt->fetchAll(PDO::FETCH_ASSOC)];
}

function version_restore($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $versionId = $data['version_id'] ?? null;

    if (!$versionId) {
        throw new Exception('Version ID required');
    }

    $stmt = $db->prepare('SELECT * FROM project_versions WHERE id = ?');
    $stmt->execute([$versionId]);
    $version = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$version) {
        throw new Exception('Version not found');
    }

    $versionData = json_decode($version['version_data'], true);
    $elements = $versionData['elements'] ?? [];

    if (empty($elements)) {
        throw new Exception('No elements found in this version');
    }

    $projectId = $version['project_id'];

    $db->beginTransaction();
    try {
        // 1. Delete existing elements for this project
// Note: dependent data (budget, media) will be orphaned or cascaded depending on DB schema.
// If we restore specific IDs, they might reconnect.
        $stmt = $db->prepare("DELETE FROM dd_building_Elements WHERE project_id = ?");
        $stmt->execute([$projectId]);

        // 2. Restore elements
        $sql = "INSERT INTO dd_building_Elements (
id, project_id, building_id, parent_id, element_code,
name, location, element_type, description, recommendation,
notes, condition_rating, risk_level, quantity, unit,
unit_price, estimated_cost, capex, installation_year,
expected_lifetime, is_bcl, sort_order, created_at, updated_at
) VALUES (
?, ?, ?, ?, ?,
?, ?, ?, ?, ?,
?, ?, ?, ?, ?,
?, ?, ?, ?,
?, ?, ?, ?, ?
)";

        $stmtInsert = $db->prepare($sql);

        foreach ($elements as $el) {
            $stmtInsert->execute([
                $el['id'],
                $el['project_id'],
                $el['building_id'],
                $el['parent_id'],
                $el['element_code'],
                $el['name'],
                $el['location'],
                $el['element_type'],
                $el['description'],
                $el['recommendation'],
                $el['notes'],
                $el['condition_rating'],
                $el['risk_level'],
                $el['quantity'],
                $el['unit'],
                $el['unit_price'],
                $el['estimated_cost'],
                $el['capex'],
                $el['installation_year'],
                $el['expected_lifetime'],
                $el['is_bcl'],
                $el['sort_order'],
                $el['created_at'],
                $el['updated_at']
            ]);
        }

        $db->commit();

        return [
            'success' => true,
            'message' => 'Project structure restored successfully (' . count($elements) . ' elements)',
            'restored_count' => count($elements)
        ];

    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

// ============================================================================
// BUILDING MANAGEMENT
// ============================================================================

function building_list($db)
{
    $projectId = $_GET['project_id'] ?? null;
    if (!$projectId) {
        throw new Exception('Project ID required');
    }

    $stmt = $db->prepare('SELECT * FROM v_dd_buildings WHERE project_id = ? ORDER BY sort_order ASC, id ASC');
    $stmt->execute([$projectId]);

    return ['data' => $stmt->fetchAll(PDO::FETCH_ASSOC)];
}

function building_reorder($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $order = $data['order'] ?? [];
    $projectId = $data['project_id'] ?? 0;

    if (empty($order)) {
        return ['success' => true]; // No updates needed
    }

    $db->beginTransaction();
    try {
        $stmt = $db->prepare("UPDATE dd_buildings SET sort_order = ? WHERE id = ? AND project_id = ?");
        foreach ($order as $item) {
            $stmt->execute([(int) $item['sort_order'], (int) $item['id'], (int) $projectId]);
        }
        $db->commit();
        return ['success' => true];
    } catch (Exception $e) {
        $db->rollBack();
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

function building_create($db)
{
    $data = json_decode(file_get_contents('php://input'), true);

    $projectId = $data['project_id'] ?? null;
    $name = $data['name'] ?? null;

    if (!$projectId || !$name) {
        throw new Exception('Project ID and name required');
    }

    // Get next sort order
    $stmt = $db->prepare("SELECT COALESCE(MAX(sort_order), -1) + 1 FROM dd_buildings WHERE project_id = ?");
    $stmt->execute([$projectId]);
    $nextOrder = $stmt->fetchColumn();

    $stmt = $db->prepare('INSERT INTO dd_buildings (project_id, name, sort_order) VALUES (?, ?, ?)');
    $stmt->execute([$projectId, $name, $nextOrder]);

    return [
        'id' => $db->lastInsertId(),
        'message' => 'Building created successfully'
    ];
}

function building_update($db)
{
    $data = json_decode(file_get_contents('php://input'), true);

    $buildingId = $data['id'] ?? null;
    $name = $data['name'] ?? null;

    if (!$buildingId || !$name) {
        throw new Exception('Building ID and name required');
    }

    $stmt = $db->prepare('UPDATE dd_buildings SET name = ? WHERE id = ?');
    $stmt->execute([$name, $buildingId]);

    return ['message' => 'Building updated successfully'];
}

function building_delete($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $buildingId = $data['id'] ?? $_GET['id'] ?? $_POST['id'] ?? null;

    if (!$buildingId) {
        throw new Exception('Building ID required');
    }

    $stmt = $db->prepare("CALL sp_SoftDelete('building', ?)");
    $stmt->execute([$buildingId]);

    return ['message' => 'Building and associated elements soft-deleted successfully'];
}

function reorder_buildings($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $items = $data['items'] ?? [];

    if (empty($items)) {
        throw new Exception("No items to reorder");
    }

    $db->beginTransaction();
    try {
        foreach ($items as $item) {
            $stmt = $db->prepare("UPDATE dd_buildings SET sort_order = ? WHERE id = ?");
            $stmt->execute([(int) $item['order'], (int) $item['id']]);
        }
        $db->commit();
        return ['message' => 'Buildings reordered'];
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}




// ============================================================================
// COLLABORATIVE EDITING (LOCKS)
// ============================================================================

function lock_acquire($db)
{
    $data = json_decode(file_get_contents('php://input'), true);

    $elementId = $data['element_id'] ?? $data['id'] ?? null;
    $field = $data['field'] ?? null;
    $clientId = $data['client_id'] ?? null;

    if (!$elementId || !$clientId) {
        throw new Exception('Element ID and Client ID required');
    }

    // Check if lock exists and is still valid (within 60 seconds)
    $stmt = $db->prepare(
        "SELECT * FROM input_locks
WHERE table_name = 'building_elements'
AND row_id = ?
AND field_name = ?
AND locked_at > DATE_SUB(NOW(), INTERVAL 60 SECOND)"
    );
    $stmt->execute([$elementId, $field ?? '']);
    $existingLock = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existingLock && $existingLock['client_id'] !== $clientId) {
        throw new Exception('Field is locked by another user');
    }

    // Acquire or refresh lock
    $userId = $_SESSION['user_id'] ?? 1;

    $stmt = $db->prepare(
        "INSERT INTO input_locks (table_name, row_id, field_name, client_id, user_id, locked_at)
VALUES ('building_elements', ?, ?, ?, ?, NOW())
ON DUPLICATE KEY UPDATE locked_at = NOW()"
    );
    $stmt->execute([$elementId, $field ?? '', $clientId, $userId]);

    return ['locked' => true];
}

function lock_release($db)
{
    $data = json_decode(file_get_contents('php://input'), true);

    $elementId = $data['element_id'] ?? $data['id'] ?? null;
    $field = $data['field'] ?? null;

    if (!$elementId) {
        throw new Exception('Element ID required');
    }

    $stmt = $db->prepare(
        "DELETE FROM input_locks
WHERE table_name = 'building_elements'
AND row_id = ?
AND field_name = ?"
    );
    $stmt->execute([$elementId, $field ?? '']);

    return ['message' => 'Lock released'];
}

function lock_check($db)
{
    $elementId = $_GET['element_id'] ?? $_GET['id'] ?? null;
    $clientId = $_GET['client_id'] ?? null;

    if (!$elementId) {
        throw new Exception('Element ID required');
    }

    $stmt = $db->prepare(
        "SELECT * FROM input_locks
WHERE table_name = 'building_elements'
AND row_id = ?
AND locked_at > DATE_SUB(NOW(), INTERVAL 60 SECOND)"
    );
    $stmt->execute([$elementId]);
    $locks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $isLocked = false;
    $lockedBy = null;
    $lockedFields = [];

    foreach ($locks as $lock) {
        if ($lock['client_id'] !== $clientId) {
            $isLocked = true;
            $lockedBy = $lock['user_id'];
            $lockedFields[] = $lock['field_name'];
        }
    }

    return [
        'locked' => $isLocked,
        'locked_by' => $lockedBy,
        'locked_fields' => $lockedFields
    ];
}

function lock_heartbeat($db)
{
    $data = json_decode(file_get_contents('php://input'), true);

    $elementId = $data['element_id'] ?? $data['id'] ?? null;
    $clientId = $data['client_id'] ?? null;

    if (!$elementId || !$clientId) {
        throw new Exception('Element ID and Client ID required');
    }

    $stmt = $db->prepare(
        "UPDATE input_locks
SET locked_at = NOW()
WHERE table_name = 'building_elements'
AND row_id = ?
AND client_id = ?"
    );
    $stmt->execute([$elementId, $clientId]);

    return ['refreshed' => true];
}

function sync_element($db)
{
    $elementId = $_GET['element_id'] ?? $_GET['id'] ?? null;
    $clientId = $_GET['client_id'] ?? null;
    $currentVersion = $_GET['data_version'] ?? null;

    if (!$elementId) {
        throw new Exception('Element ID required');
    }

    // 0. Auto-Heartbeat: Refresh locks for this client if exists
    if ($clientId) {
        $stmt = $db->prepare("UPDATE input_locks SET locked_at = NOW() WHERE client_id = ? AND row_id = ?");
        $stmt->execute([$clientId, $elementId]);
    }

    // 1. Prune old locks
    $db->query("DELETE FROM input_locks WHERE locked_at < DATE_SUB(NOW(), INTERVAL 60 SECOND)");

    // 2. Get current locks
    $stmt = $db->prepare(
        "SELECT * FROM input_locks
        WHERE table_name = 'building_elements'
        AND row_id = ?"
    );
    $stmt->execute([$elementId]);
    $locks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $formattedLocks = [];

    foreach ($locks as $lock) {
        // Get user name for better UI
        $userStmt = $db->prepare("SELECT name FROM dd_users WHERE id = ?");
        $userStmt->execute([$lock['user_id']]);
        $userName = $userStmt->fetchColumn() ?: 'Unknown';

        $formattedLocks[$lock['field_name']] = [
            'user_id' => $lock['user_id'],
            'user_name' => $userName,
            'client_id' => $lock['client_id'],
            'is_me' => ($lock['client_id'] === $clientId)
        ];
    }

    // 3. Check for data updates
    $stmt = $db->prepare("SELECT updated_at FROM dd_building_Elements WHERE id = ?");
    $stmt->execute([$elementId]);
    $lastUpdate = $stmt->fetchColumn();

    $newData = null;
    if ($currentVersion && $lastUpdate && strtotime($lastUpdate) > strtotime($currentVersion)) {
        // Data has changed, fetch fresh data
        // For efficiency, we reuse get_element_details logic or just fetch what's needed
        // Here we'll just fetch the main fields to keep it light
        $stmt = $db->prepare("SELECT * FROM dd_building_Elements WHERE id = ?");
        $stmt->execute([$elementId]);
        $newData = $stmt->fetch(PDO::FETCH_ASSOC);

        // Add budget summary recalculation if needed, but for now just raw data
    }

    // 4. Get Favorites for autocomplete (Items and Bundles)
    $favorites = get_catalog_favorites($db);

    return [
        'locks' => $formattedLocks,
        'data_version' => $lastUpdate,
        'new_data' => $newData,
        'favorites' => $favorites
    ];
}

function get_catalog_favorites($db)
{
    // Fetch favorite items
    $stmt = $db->query("
        SELECT id, description as name, 'item' as type, unit, unit_price as price, is_favorite 
        FROM price_catalogs 
        WHERE is_favorite = 1 
        ORDER BY name ASC
    ");
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch favorite bundles
    $stmt = $db->query("
        SELECT id, name, 'bundle' as type, unit, total_price as price, is_favorite
        FROM dd_price_catalog_bundles
        WHERE is_favorite = 1
        ORDER BY name ASC
    ");
    $bundles = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Merge and simple sort (bundles first? User said favorites prioritized, but all these are favorites. Maybe Bundles first?)
    // User: "hvor favorit skal prioriteres øverst" -> All these are favorites.
    // Let's just merge.
    $all = array_merge($bundles, $items);

    // Enrich with icons
    foreach ($all as &$row) {
        if ($row['type'] === 'bundle') {
            $row['icon'] = '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>';
        } else {
            $row['icon'] = '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>'; // Generic item icon
        }

        // Add star marking to name if requested
        // User: "gerne med en stjernemarkering"
        $row['name_display'] = '★ ' . $row['name'];
    }

    return $all;
}

// // File: modules/elements/api-endpoints.php

/**
 * Building Elements API - Enterprise Edition
 * Håndterer hierarki i dd_building_Elements
 */

// Tree API handlers moved to main handle_api

/**
 * Sletter et element og dets underliggende børn
 */
function element_delete($db)
{
    $id = (int) ($_POST['id'] ?? 0);
    $projectId = (int) ($_POST['project_id'] ?? 0);

    if (!$id || !$projectId) {
        throw new Exception("Element ID and Project ID required.");
    }

    $db->beginTransaction();
    try {
        // Rekursiv sletning
        delete_element_recursive($db, $id);

        regenerate_element_codes($db, $projectId);

        $db->commit();
        return ['success' => true];
    } catch (Exception $e) {
        $db->rollBack();
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

function delete_element_recursive($db, $parentId)
{
    // 1. Find børn
    $stmt = $db->prepare("SELECT id FROM dd_building_Elements WHERE parent_id = ?");
    $stmt->execute([$parentId]);
    $children = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // 2. Slet børn rekursivt
    foreach ($children as $childId) {
        delete_element_recursive($db, $childId);
    }

    // 3. Slet tilknyttede opgaver
    $stmtTasks = $db->prepare("DELETE FROM dd_tasks WHERE element_id = ?");
    $stmtTasks->execute([$parentId]);

    // 4. Slet selve elementet
    $stmtDel = $db->prepare("DELETE FROM dd_building_Elements WHERE id = ?");
    $stmtDel->execute([$parentId]);
}

/**
 * Flytter elementer (understøtter multi-select) og regenererer koder
 */
function move_tree_node($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $ids = (array) ($data['ids'] ?? []);
    $newParentId = (int) ($data['new_parent_id'] ?? 0);
    $projectId = (int) ($data['project_id'] ?? 0);

    if (empty($ids)) {
        throw new Exception("No elements selected for move.");
    }
    if ($projectId <= 0) {
        throw new Exception("Project ID required.");
    }

    $db->beginTransaction();
    try {
        foreach ($ids as $id) {
            // Valider dybde (Constraint: 5 niveauer)
            if ($newParentId != 0) {
                $depth = 1;
                $curr = $newParentId;
                while ($curr != 0) {
                    $stmt = $db->prepare("SELECT parent_id FROM dd_building_Elements WHERE id = ?");
                    $stmt->execute([$curr]);
                    $curr = $stmt->fetchColumn();
                    $depth++;
                }
                if ($depth > 5)
                    throw new Exception("Maksimal dybde på 5 niveauer overskredet.");
            }

            $stmt = $db->prepare("UPDATE dd_building_Elements SET parent_id = ? WHERE id = ?");
            $stmt->execute([$newParentId, $id]);
        }

        regenerate_element_codes($db, $projectId);
        $db->commit();
        return ['success' => true];
    } catch (Exception $e) {
        $db->rollBack();
        return ['success' => false, 'message' => $e->getMessage()];
    }
}



/**
 * Regenererer koder rekursivt: 1 -> 1.1 -> 1.1.1
 */
function regenerate_element_codes($db, $projectId, $parentId = 0, $prefix = "", $stmtSelect = null, $stmtUpdate = null)
{
    if ($stmtSelect === null) {
        $stmtSelect = $db->prepare("SELECT id FROM dd_building_Elements WHERE project_id = ? AND parent_id = ? ORDER BY
sort_order ASC, id ASC");
    }
    if ($stmtUpdate === null) {
        $stmtUpdate = $db->prepare("UPDATE dd_building_Elements SET element_code = ? WHERE id = ?");
    }

    $stmtSelect->execute([$projectId, $parentId]);
    $nodes = $stmtSelect->fetchAll(PDO::FETCH_ASSOC);

    foreach ($nodes as $index => $node) {
        $newCode = ($prefix === "") ? ($index + 1) : $prefix . "." . ($index + 1);
        $stmtUpdate->execute([$newCode, $node['id']]);

        // Rekursivt kald til børn
        regenerate_element_codes($db, $projectId, $node['id'], $newCode, $stmtSelect, $stmtUpdate);
    }
    return true;
}

/**
 * Henter statistikker til Hover-infoboks
 */
function get_element_stats($db)
{
    $idParam = $_GET['element_id'] ?? $_GET['id'] ?? '';
    $id = (int) str_replace(['element-', 'building-'], '', $idParam);

    // SQL til at summere data for det enkelte element og tælle flag
    $stmt = $db->prepare("
SELECT
name, element_code, estimated_cost, installation_year, condition_rating,
(SELECT COUNT(*) FROM dd_tasks WHERE element_id = e.id AND status != 'closed') as task_count
FROM dd_building_Elements e
WHERE id = ?
");
    $stmt->execute([$id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);

    // Beregn advarsel baseret på alder (f.eks. > 30 år)
    $age = date('Y') - ($data['installation_year'] ?: date('Y'));
    $warning = ($age > 30) ? "Komponent er $age år gammel. Overskrider normal levetid." : null;

    return [
        'success' => true,
        'stats' => [
            'name' => $data['name'],
            'code' => $data['element_code'],
            'capex' => $data['estimated_cost'],
            'tasks' => $data['task_count'],
            'rating' => $data['condition_rating'],
            'warning' => $warning,
            'flags' => [
                'condition' => $data['condition_rating'] > 3,
                'age' => $age > 25,
                'budget' => $data['estimated_cost'] > 50000,
                'tasks' => $data['task_count'] > 0,
                'critical' => ($data['condition_rating'] == 5)
            ]
        ]
    ];
}

// ============================================================================
// TEMPLATE OPERATIONS
// ============================================================================

/**
 * Lists all available element templates
 */
function list_element_templates($db)
{
    $stmt = $db->query("
        SELECT t.*, 
        (SELECT COUNT(*) FROM dd_element_template_nodes WHERE template_id = t.id) as node_count 
        FROM dd_element_templates t 
        ORDER BY t.name ASC
    ");
    return ['data' => $stmt->fetchAll(PDO::FETCH_ASSOC)];
}

/**
 * Gets the configuration for a template, including duplicate check for a specific building
 */
function template_get_config($db)
{
    $templateId = (int) ($_GET['template_id'] ?? 0);
    $templateName = $_GET['template_name'] ?? null;
    $buildingId = (int) ($_GET['building_id'] ?? 0);

    // Get Template Header
    if ($templateId > 0) {
        $stmt = $db->prepare("SELECT * FROM dd_element_templates WHERE id = ?");
        $stmt->execute([$templateId]);
    } else if ($templateName) {
        $stmt = $db->prepare("SELECT * FROM dd_element_templates WHERE name = ?");
        $stmt->execute([$templateName]);
    } else {
        throw new Exception("Template ID or Name required");
    }

    $template = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$template) {
        throw new Exception("Template not found" . ($templateId ? " (ID: $templateId)" : " (Name: $templateName)"));
    }

    $templateId = $template['id']; // Ensure we have the ID for nodes query

    // Get All Nodes
    $stmt = $db->prepare("SELECT * FROM dd_element_template_nodes WHERE template_id = ? ORDER BY sort_order ASC, id ASC");
    $stmt->execute([$templateId]);
    $nodes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Check for existing elements in this building to highlight duplicates
    $existingNames = [];
    if ($buildingId > 0) {
        $stmt = $db->prepare("SELECT name FROM dd_building_Elements WHERE building_id = ?");
        $stmt->execute([$buildingId]);
        $existingNames = $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    // Build hierarchy safely (cycle detection)
    $structure = [];
    $nodeMap = [];

    foreach ($nodes as $node) {
        $node['exists'] = in_array($node['name'], $existingNames);
        $node['children'] = [];
        $nodeMap[$node['id']] = $node;
    }

    foreach ($nodeMap as $id => &$node) {
        $parentId = $node['parent_id'];

        // Cycle check: Walk up the chain from parent
        $isCycle = false;
        $curr = $parentId;
        $visited = [$id => true]; // We start at ourselves

        while ($curr && isset($nodeMap[$curr])) {
            if (isset($visited[$curr])) {
                $isCycle = true;
                break;
            }
            $visited[$curr] = true;
            $curr = $nodeMap[$curr]['parent_id'];
        }

        if ($parentId && isset($nodeMap[$parentId]) && !$isCycle) {
            $nodeMap[$parentId]['children'][] = &$node;
        } else {
            // Root or cycle detected (or orphaned)
            $structure[] = &$node;
        }
    }

    return [
        'name' => $template['name'],
        'description' => $template['description'],
        'structure' => $structure
    ];
}

/**
 * Bulk creates elements from selected template items
 */
function template_bulk_create($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $projectId = (int) ($data['project_id'] ?? 0);
    $buildingId = (int) ($data['building_id'] ?? 0);
    $nodeIds = $data['elements'] ?? []; // These are now likely numeric IDs from frontend

    if (!$projectId)
        throw new Exception("Project ID is required");
    if (!$buildingId)
        throw new Exception("Building ID is required");
    if (empty($nodeIds))
        throw new Exception("No template elements selected");

    $db->beginTransaction();
    try {
        $createdCount = 0;
        $nodeIdToElementIdMap = [];

        // 1. Fetch details for all requested nodes
        $placeholders = implode(',', array_fill(0, count($nodeIds), '?'));
        $stmtNodes = $db->prepare("SELECT * FROM dd_element_template_nodes WHERE id IN ($placeholders) ORDER BY sort_order ASC, id ASC");
        $stmtNodes->execute($nodeIds);
        $nodes = $stmtNodes->fetchAll(PDO::FETCH_ASSOC);

        // Map nodes by their template ID for easy lookup
        $nodesMap = [];
        foreach ($nodes as $node) {
            $nodesMap[$node['id']] = $node;
        }

        // 2. Fetch existing elements to prevent duplicates
        $stmtCheck = $db->prepare("SELECT name, id FROM dd_building_Elements WHERE building_id = ?");
        $stmtCheck->execute([$buildingId]);
        $existing = $stmtCheck->fetchAll(PDO::FETCH_KEY_PAIR);

        // 3. Create elements in order (preserving hierarchy)
        // 3. Create elements in order (preserving hierarchy via multi-pass)
        $nodesToProcess = $nodes;
        $maxLoops = 100;

        while (!empty($nodesToProcess) && $maxLoops-- > 0) {
            $progress = false;

            foreach ($nodesToProcess as $key => $node) {
                $templateParentId = $node['parent_id'];
                $parentId = null;
                $isReady = false;

                // Check dependencies
                // 1. Is root in template? -> Ready
                if (!$templateParentId) {
                    $isReady = true;
                }
                // 2. Parent NOT in selection? -> Ready (becomes root)
                else if (!in_array($templateParentId, $nodeIds)) {
                    $isReady = true;
                    // $parentId remains null
                }
                // 3. Parent mapping exists from previous pass? -> Ready
                else if (isset($nodeIdToElementIdMap[$templateParentId])) {
                    $isReady = true;
                    $parentId = $nodeIdToElementIdMap[$templateParentId];
                }

                if ($isReady) {
                    $name = $node['name'];

                    // Check if already exists in this building (skips creation)
                    if ($name && isset($existing[$name])) {
                        $nodeIdToElementIdMap[$node['id']] = $existing[$name];
                    } else if ($name) {
                        // Create New
                        // Calculate next sort_order
                        $stmtOrder = $db->prepare("SELECT COALESCE(MAX(sort_order), 0) + 1 FROM dd_building_Elements WHERE project_id = ? AND (parent_id = ? OR (parent_id IS NULL AND ? IS NULL))");
                        $stmtOrder->execute([$projectId, $parentId, $parentId]);
                        $nextOrder = $stmtOrder->fetchColumn();

                        $stmtInsert = $db->prepare("
                            INSERT INTO dd_building_Elements (
                                project_id, building_id, parent_id, name, element_type, sort_order,
                                observation, recommendation, risk_level, condition_rating, quality_rating
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ");
                        $stmtInsert->execute([
                            $projectId,
                            $buildingId,
                            $parentId,
                            $name,
                            $parentId ? 'element' : 'section',
                            $nextOrder,
                            $node['observation'] ?? null,
                            $node['recommendation'] ?? null,
                            $node['risk_level'] ?? null,
                            $node['condition_rating'] ?? null,
                            $node['quality_rating'] ?? null
                        ]);

                        $newId = $db->lastInsertId();
                        $nodeIdToElementIdMap[$node['id']] = $newId;
                        $createdCount++;
                    }

                    // Mark done
                    unset($nodesToProcess[$key]);
                    $progress = true;
                }
            }

            // If no progress but nodes remain, there's a cycle or data issue.
            // Force process remaining as roots to avoid infinite loop.
            if (!$progress && !empty($nodesToProcess)) {
                foreach ($nodesToProcess as $key => $node) {
                    // Create as root (fallback)
                    $name = $node['name'];
                    if ($name && isset($existing[$name])) {
                        $nodeIdToElementIdMap[$node['id']] = $existing[$name];
                    } else if ($name) {
                        $stmtOrder = $db->prepare("SELECT COALESCE(MAX(sort_order), 0) + 1 FROM dd_building_Elements WHERE project_id = ? AND parent_id IS NULL");
                        $stmtOrder->execute([$projectId]);
                        $nextOrder = $stmtOrder->fetchColumn();

                        $stmtInsert = $db->prepare("
                            INSERT INTO dd_building_Elements (
                                project_id, building_id, parent_id, name, element_type, sort_order
                            ) VALUES (?, ?, NULL, ?, ?, ?)
                        ");
                        $stmtInsert->execute([
                            $projectId,
                            $buildingId,
                            $name,
                            'section', // Root fallback
                            $nextOrder
                        ]);
                        $nodeIdToElementIdMap[$node['id']] = $db->lastInsertId();
                        $createdCount++;
                    }
                    unset($nodesToProcess[$key]);
                }
            }
        }

        regenerate_element_codes($db, $projectId);
        $db->commit();

        return ['success' => true, 'created_count' => $createdCount];
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

// === TEMPLATE ADMIN FUNCTIONS ===

function template_create($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $stmt = $db->prepare("INSERT INTO dd_element_templates (name, description) VALUES (?, ?)");
    $stmt->execute([$data['name'] ?? 'Ny Skabelon', $data['description'] ?? '']);
    return ['id' => $db->lastInsertId(), 'message' => 'Template created successfully'];
}

function template_update($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $stmt = $db->prepare("UPDATE dd_element_templates SET name = ?, description = ? WHERE id = ?");
    $stmt->execute([$data['name'], $data['description'], (int) $data['id']]);
    return ['success' => true];
}

function template_delete($db)
{
    $id = (int) ($_GET['id'] ?? 0);

    $db->beginTransaction();
    try {
        // Delete all nodes first
        $stmt = $db->prepare("DELETE FROM dd_element_template_nodes WHERE template_id = ?");
        $stmt->execute([$id]);

        // Delete template
        $stmt = $db->prepare("DELETE FROM dd_element_templates WHERE id = ?");
        $stmt->execute([$id]);

        $db->commit();
        return ['success' => true];
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

function template_node_create($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $stmt = $db->prepare("INSERT INTO dd_element_template_nodes (template_id, parent_id, name, element_type, sort_order, observation, recommendation, risk_level, condition_rating, quality_rating) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        (int) $data['template_id'],
        (!empty($data['parent_id']) ? (int) $data['parent_id'] : null),
        $data['name'],
        $data['element_type'] ?? 'element',
        (int) ($data['sort_order'] ?? 0),
        $data['observation'] ?? null,
        $data['recommendation'] ?? null,
        $data['risk_level'] ?? null,
        $data['condition_rating'] ?? null,
        $data['quality_rating'] ?? null
    ]);
    return ['id' => $db->lastInsertId()];
}

function template_node_update($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $stmt = $db->prepare("UPDATE dd_element_template_nodes SET name = ?, element_type = ?, sort_order = ?, observation = ?, recommendation = ?, risk_level = ?, condition_rating = ?, quality_rating = ? WHERE id = ?");
    $stmt->execute([
        $data['name'],
        $data['element_type'],
        (int) $data['sort_order'],
        $data['observation'] ?? null,
        $data['recommendation'] ?? null,
        $data['risk_level'] ?? null,
        $data['condition_rating'] ?? null,
        $data['quality_rating'] ?? null,
        (int) $data['id']
    ]);
    return ['success' => true];
}

function template_node_delete($db)
{
    $id = (int) ($_GET['id'] ?? 0);

    // Recursive delete of children to prevent orphans
    $deletedIds = [];
    $idsToDelete = [$id];

    while (!empty($idsToDelete)) {
        $currentId = array_shift($idsToDelete);
        if (in_array($currentId, $deletedIds))
            continue;

        $deletedIds[] = $currentId;

        // Find children
        $stmt = $db->prepare("SELECT id FROM dd_element_template_nodes WHERE parent_id = ?");
        $stmt->execute([$currentId]);
        $children = $stmt->fetchAll(PDO::FETCH_COLUMN);

        foreach ($children as $childId) {
            $idsToDelete[] = $childId;
        }
    }

    if (!empty($deletedIds)) {
        $placeholders = implode(',', array_fill(0, count($deletedIds), '?'));
        $stmt = $db->prepare("DELETE FROM dd_element_template_nodes WHERE id IN ($placeholders)");
        $stmt->execute($deletedIds);
    }

    return ['success' => true];
}

function template_node_move($db)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $id = (int) $data['id'];
    $targetId = (int) $data['target_id'];
    $position = (int) ($data['position'] ?? 0); // 0: inside/append, -1: before, -2: after
    $templateId = (int) $data['template_id'];

    if (!$id || !$targetId) {
        throw new Exception("Source and Target ID required");
    }

    if ($id === $targetId)
        return ['success' => true];

    $db->beginTransaction();
    try {
        // Get target info
        $stmt = $db->prepare("SELECT parent_id, sort_order FROM dd_element_template_nodes WHERE id = ?");
        $stmt->execute([$targetId]);
        $target = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$target) {
            throw new Exception("Target node not found");
        }

        $newParentId = null;
        $newOrder = 0;

        if ($position === 0) {
            // Inside (append as child)
            $newParentId = $targetId;
            $stmt = $db->prepare("SELECT COALESCE(MAX(sort_order), 0) + 1 FROM dd_element_template_nodes WHERE parent_id = ?");
            $stmt->execute([$newParentId]);
            $newOrder = $stmt->fetchColumn();
        } elseif ($position === -1) {
            // Before target
            $newParentId = $target['parent_id'];
            $newOrder = $target['sort_order'];
            // Shift siblings down
            $stmt = $db->prepare("UPDATE dd_element_template_nodes SET sort_order = sort_order + 1 WHERE parent_id <=> ? AND sort_order >= ? AND template_id = ?");
            $stmt->execute([$newParentId, $newOrder, $templateId]);
        } elseif ($position === -2) {
            // After target
            $newParentId = $target['parent_id'];
            $newOrder = $target['sort_order'] + 1;
            // Shift siblings down
            $stmt = $db->prepare("UPDATE dd_element_template_nodes SET sort_order = sort_order + 1 WHERE parent_id <=> ? AND sort_order >= ? AND template_id = ?");
            $stmt->execute([$newParentId, $newOrder, $templateId]);
        }

        // Cycle Detection: Check if newParentId is a child of $id
        if ($newParentId) {
            // Build simple parent map to traverse
            $stmt = $db->prepare("SELECT id, parent_id FROM dd_element_template_nodes WHERE template_id = ?");
            $stmt->execute([$templateId]);
            $allNodes = $stmt->fetchAll(PDO::FETCH_KEY_PAIR); // id => parent_id

            $curr = $newParentId;
            while ($curr) {
                if ($curr == $id) {
                    throw new Exception("Move would create a cycle (cannot move parent inside child)");
                }
                $curr = $allNodes[$curr] ?? null;
            }
        }

        // Move the node
        $stmt = $db->prepare("UPDATE dd_element_template_nodes SET parent_id = ?, sort_order = ? WHERE id = ?");
        $stmt->execute([$newParentId, $newOrder, $id]);

        $db->commit();
        return ['success' => true];
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

function get_light_report($db)
{
    $projectId = (int) ($_GET['project_id'] ?? 0);
    if (!$projectId)
        throw new Exception("Project ID required");

    // Optimized Project Fetch
    $stmt = $db->prepare("SELECT p.*, c.name as customer_name, c.address as customer_address FROM dd_projects p LEFT JOIN
dd_customers c ON p.customer_id = c.id WHERE p.id = ?");
    $stmt->execute([$projectId]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$project)
        throw new Exception("Project not found");

    // Optimized Data Fetching (Batch)
    $buildings = get_project_data_batch($db, $projectId);

    $data = [
        'project' => $project,
        'buildings' => $buildings,
        'report_title' => 'Light Report',
        'report_date' => date('d.m.Y')
    ];
    $html = render_template(__DIR__ . '/templates/report_light.tpl', $data);
    header('Content-Type: text/html; charset=utf-8');
    echo $html;
    exit;
}

function get_interactive_report($db)
{
    $projectId = (int) ($_GET['project_id'] ?? 0);
    if (!$projectId)
        throw new Exception("Project ID required");

    // Optimized Project Fetch
    $stmt = $db->prepare("SELECT p.*, c.name as customer_name, c.address as customer_address FROM dd_projects p LEFT JOIN
dd_customers c ON p.customer_id = c.id WHERE p.id = ?");
    $stmt->execute([$projectId]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$project)
        throw new Exception("Project not found");

    // Optimized Data Fetching (Batch)
    $buildings = get_project_data_batch($db, $projectId);

    $data = [
        'project' => $project,
        'client' => ['name' => $project['customer_name'] ?? ''],
        'buildings' => $buildings,
        'report_title' => 'Tilstandsrapport (Interaktiv)',
        'report_date' => date('d.m.Y')
    ];
    $html = render_template(__DIR__ . '/templates/report_interactive.tpl', $data);
    header('Content-Type: text/html; charset=utf-8');
    echo $html;
    exit;
}

function debug_data($db)
{
    $projectId = (int) ($_GET['project_id'] ?? 0);
    $stmt = $db->prepare("SELECT id, parent_id, name, building_id FROM dd_building_Elements WHERE project_id = ? ORDER BY id ASC");
    $stmt->execute([$projectId]);
    $elements = $stmt->fetchAll();

    $counts = array_count_values(array_column($elements, 'id'));
    $duplicates = array_filter($counts, function ($c) {
        return $c > 1;
    });

    return [
        'project_id' => $projectId,
        'total' => count($elements),
        'duplicates' => $duplicates,
        'elements' => $elements
    ];
}
function get_building_summary($db)
{
    $buildingId = (int) ($_GET['building_id'] ?? 0);
    $projectId = (int) ($_GET['project_id'] ?? 0);

    if (!$buildingId) {
        throw new Exception("Building ID required");
    }

    // Get building info
    $stmt = $db->prepare("SELECT b.*, p.name as project_name FROM dd_buildings b LEFT JOIN dd_projects p ON b.project_id = p.id WHERE b.id = ?");
    $stmt->execute([$buildingId]);
    $building = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$building) {
        throw new Exception("Building not found");
    }

    // Aggregate budget from all elements in this building
    $stmt = $db->prepare("
        SELECT 
            COALESCE(SUM(amount_0_1), 0) as sum_0_1,
            COALESCE(SUM(amount_1_2), 0) as sum_1_2,
            COALESCE(SUM(amount_3_5), 0) as sum_3_5,
            COALESCE(SUM(amount_5_10), 0) as sum_5_10
        FROM dd_budget_items bi
        JOIN dd_building_Elements e ON bi.element_id = e.id
        WHERE e.building_id = ?
    ");
    $stmt->execute([$buildingId]);
    $budget = $stmt->fetch(PDO::FETCH_ASSOC);

    // Total CAPEX
    $stmt = $db->prepare("SELECT SUM(capex) as total_capex FROM dd_building_Elements WHERE building_id = ?");
    $stmt->execute([$buildingId]);
    $capexField = $stmt->fetch(PDO::FETCH_ASSOC);

    // Risk Counts
    $stmt = $db->prepare("
        SELECT risk_level, COUNT(*) as count 
        FROM dd_building_Elements 
        WHERE building_id = ? AND risk_level IN ('Rød', 'Gul', 'Grøn')
        GROUP BY risk_level
    ");
    $stmt->execute([$buildingId]);
    $riskCounts = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    // Condition Counts
    $stmt = $db->prepare("
        SELECT condition_rating, COUNT(*) as count 
        FROM dd_building_Elements 
        WHERE building_id = ? AND condition_rating IS NOT NULL
        GROUP BY condition_rating
    ");
    $stmt->execute([$buildingId]);
    $conditionCounts = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return [
        'type' => 'building',
        'id' => $buildingId,
        'name' => $building['name'],
        'project_id' => $building['project_id'],
        'project_name' => $building['project_name'],
        'building_id' => $buildingId,
        'building_name' => $building['name'],
        'description' => 'Herunder findes en opsummering af økonomien for samtlige bygningsdele i ' . $building['name'] . '.',
        'recommendation' => 'Vælg en specifik bygningsdel i menuen til venstre for at se eller redigere detaljer.',
        // Extended Building Info
        'address' => $building['address'] ?? '',
        'postal_code' => $building['postal_code'] ?? '',
        'city' => $building['city'] ?? '',
        'construction_year' => $building['construction_year'] ?? '',
        'sqm' => $building['sqm'] ?? '',
        'matrikel' => $building['matrikel'] ?? '',
        'floors' => $building['floors'] ?? '',
        // Stats
        'budget_summary' => $budget,
        'capex' => (float) ($capexField['total_capex'] ?? 0),
        'risk_counts' => $riskCounts,
        'condition_counts' => $conditionCounts,
        'risk_level' => '',
        'media' => [],
        'is_bcl' => 0,
        'rounding_override' => null
    ];
}

function get_group_summary($db)
{
    $elementId = $_GET['element_id'] ?? null;
    // Sanitize if "element-X" format
    if ($elementId && strpos($elementId, 'element-') === 0) {
        $elementId = str_replace('element-', '', $elementId);
    }
    $elementId = (int) $elementId;

    $projectId = (int) ($_GET['project_id'] ?? 0);

    if (!$elementId) {
        throw new Exception("Element ID required");
    }

    // Get Group Info
    $stmt = $db->prepare("SELECT e.*, b.name AS building_name FROM dd_building_Elements e LEFT JOIN dd_buildings b ON e.building_id = b.id WHERE e.id = ?");
    $stmt->execute([$elementId]);
    $element = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$element) {
        throw new Exception("Element not found");
    }

    // Identify all descendants (Recursive)
    $allIds = [$elementId]; // Include self if it has own budget? Usually groups are containers, but safer to include.
    // Actually, user wants "alle childes under".

    // Recursive collection of IDs
    $queue = [$elementId];
    $descendantIds = [];
    $limit = 5000;
    while (!empty($queue) && $limit-- > 0) {
        $currentId = array_shift($queue);
        $stmt = $db->prepare("SELECT id FROM dd_building_Elements WHERE parent_id = ?");
        $stmt->execute([$currentId]);
        $children = $stmt->fetchAll(PDO::FETCH_COLUMN);
        foreach ($children as $childId) {
            $descendantIds[] = $childId;
            $queue[] = $childId;
        }
    }

    if (empty($descendantIds)) {
        // No children, return basic stats (likely zero)
        return [
            'type' => 'group',
            'id' => $elementId,
            'name' => $element['name'],
            'description' => $element['description'],
            'recommendation' => 'Denne gruppe har ingen underliggende elementer.',
            'budget_summary' => [],
            'capex' => 0,
            'risk_counts' => [],
            'condition_counts' => [],
            'risk_level' => $element['risk_level'],
            'media' => [], // Could potentially aggregate media too, but likely not needed for summary view
            'is_bcl' => $element['is_bcl'],
            'rounding_override' => $element['rounding_override']
        ];
    }

    $placeholders = implode(',', array_fill(0, count($descendantIds), '?'));

    // Aggregate Budget
    $stmt = $db->prepare("
        SELECT 
            COALESCE(SUM(amount_0_1), 0) as sum_0_1,
            COALESCE(SUM(amount_1_2), 0) as sum_1_2,
            COALESCE(SUM(amount_3_5), 0) as sum_3_5,
            COALESCE(SUM(amount_5_10), 0) as sum_5_10
        FROM dd_budget_items
        WHERE element_id IN ($placeholders)
    ");
    $stmt->execute($descendantIds);
    $budget = $stmt->fetch(PDO::FETCH_ASSOC);

    // Total CAPEX
    $stmt = $db->prepare("SELECT SUM(capex) as total_capex FROM dd_building_Elements WHERE id IN ($placeholders)");
    $stmt->execute($descendantIds);
    $capexField = $stmt->fetch(PDO::FETCH_ASSOC);

    // Risk Counts
    $stmt = $db->prepare("
        SELECT risk_level, COUNT(*) as count 
        FROM dd_building_Elements 
        WHERE id IN ($placeholders) AND risk_level IN ('Rød', 'Gul', 'Grøn')
        GROUP BY risk_level
    ");
    $stmt->execute($descendantIds);
    $riskCounts = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    // Condition Counts
    $stmt = $db->prepare("
        SELECT condition_rating, COUNT(*) as count 
        FROM dd_building_Elements 
        WHERE id IN ($placeholders) AND condition_rating IS NOT NULL
        GROUP BY condition_rating
    ");
    $stmt->execute($descendantIds);
    $conditionCounts = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return [
        'type' => 'group',
        'id' => $elementId,
        'name' => $element['name'],
        'description' => $element['description'] ?: 'Opsummering for ' . $element['name'],
        'recommendation' => $element['recommendation'] ?: 'Vælg et underliggende element for at se detaljer.',
        'budget_summary' => $budget,
        'capex' => (float) ($capexField['total_capex'] ?? 0),
        'risk_counts' => $riskCounts,
        'condition_counts' => $conditionCounts,
        'risk_level' => $element['risk_level'], // Parent's own risk
        'media' => [],
        'is_bcl' => $element['is_bcl'],
        'rounding_override' => $element['rounding_override'],
        // Pass project/building context
        'project_id' => $element['project_id'],
        'building_id' => $element['building_id'],
    ];
}

function add_element_comment($db)
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid method');
    }

    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    if (!$data) {
        $data = $_POST;
    }

    $elementId = $data['element_id'] ?? null;
    // Sanitize if "element-X" format
    if ($elementId && strpos($elementId, 'element-') === 0) {
        $elementId = str_replace('element-', '', $elementId);
    }
    $elementId = (int) $elementId;

    $comment = trim($data['comment'] ?? '');

    if (!$elementId) {
        throw new Exception('Element ID missing');
    }
    if ($comment === '') {
        throw new Exception('Comment cannot be empty');
    }

    // Get current user (simple session based for now, assume logged in)
    $userId = $_SESSION['user_id'] ?? 1; // Fallback to 1 if no session (dev)

    // Lookup user name for immediate return
    $stmt = $db->prepare("SELECT name FROM dd_users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    $userName = $user['name'] ?? 'System';

    $stmt = $db->prepare("
        INSERT INTO dd_system_Comments (bind_type, bind_id, user_id, content, created_at)
        VALUES ('element', ?, ?, ?, NOW())
    ");
    $stmt->execute([$elementId, $userId, $comment]);

    $newCommentId = $db->lastInsertId();

    // Return the new list or just the new comment? 
    // Let's return the full list to stay consistent with re-rendering
    $stmt = $db->prepare("
        SELECT c.id, c.bind_type, c.bind_id, c.user_id, c.content as comment, c.is_resolved, c.created_at, u.name as user_name 
        FROM dd_system_Comments c
        LEFT JOIN dd_users u ON c.user_id = u.id
        WHERE c.bind_type = 'element' AND c.bind_id = ?
        ORDER BY c.created_at DESC
    ");
    $stmt->execute([$elementId]);
    $comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return ['success' => true, 'comments' => $comments];
}

function edit_element_comment($db)
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid method');
    }

    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    if (!$data) {
        $data = $_POST;
    }

    $commentId = $data['comment_id'] ?? null;
    $comment = trim($data['comment'] ?? '');

    if (!$commentId) {
        throw new Exception('Comment ID missing');
    }
    if ($comment === '') {
        throw new Exception('Comment cannot be empty');
    }

    $userId = $_SESSION['user_id'] ?? 1;

    // Verify ownership and time limit (5 minutes)
    $stmt = $db->prepare("SELECT user_id, bind_id, created_at FROM dd_system_Comments WHERE id = ?");
    $stmt->execute([$commentId]);
    $existing = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$existing) {
        throw new Exception('Comment not found');
    }

    // Check ownership
    // if ($existing['user_id'] != $userId) {
    //    throw new Exception('Unauthorized');
    // } 
    // Allowing admin override for now implicitly, but strict check is better:
    if ($existing['user_id'] != $userId && $userId != 1) { // Allow ID 1 as super admin
        throw new Exception('Unauthorized');
    }

    // Check time limit
    $created = strtotime($existing['created_at']);
    $now = time();
    if (($now - $created) > (5 * 60)) { // 5 minutes
        throw new Exception('Time limit for editing has expired');
    }

    // Update
    $stmt = $db->prepare("UPDATE dd_system_Comments SET content = ? WHERE id = ?");
    $stmt->execute([$comment, $commentId]);

    // Return updated list
    $elementId = $existing['bind_id'];
    $stmt = $db->prepare("
        SELECT c.id, c.bind_type, c.bind_id, c.user_id, c.content as comment, c.is_resolved, c.created_at, u.name as user_name 
        FROM dd_system_Comments c
        LEFT JOIN dd_users u ON c.user_id = u.id
        WHERE c.bind_type = 'element' AND c.bind_id = ?
        ORDER BY c.created_at DESC
    ");
    $stmt->execute([$elementId]);
    $comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return ['success' => true, 'comments' => $comments];
}

function get_element_comments($db)
{
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        throw new Exception('Invalid method');
    }

    $elementId = $_GET['element_id'] ?? null;
    // Sanitize if "element-X" format
    if ($elementId && strpos($elementId, 'element-') === 0) {
        $elementId = str_replace('element-', '', $elementId);
    }
    $elementId = (int) $elementId;

    if (!$elementId) {
        throw new Exception('Element ID missing');
    }

    $stmt = $db->prepare("
        SELECT c.id, c.bind_type, c.bind_id, c.user_id, c.content as comment, c.is_resolved, c.created_at, u.name as user_name 
        FROM dd_system_Comments c
        LEFT JOIN dd_users u ON c.user_id = u.id
        WHERE c.bind_type = 'element' AND c.bind_id = ?
        ORDER BY c.created_at DESC
    ");
    $stmt->execute([$elementId]);
    $comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return ['success' => true, 'comments' => $comments];
}

function toggle_comment_resolved($db)
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid method');
    }

    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    if (!$data)
        $data = $_POST;

    $commentId = $data['comment_id'] ?? null;
    $isResolved = isset($data['is_resolved']) ? (int) $data['is_resolved'] : 0;

    if (!$commentId)
        throw new Exception('Comment ID missing');

    $stmt = $db->prepare("UPDATE dd_system_Comments SET is_resolved = ? WHERE id = ?");
    $stmt->execute([$isResolved, $commentId]);

    // Return updated list for the element
    $stmt = $db->prepare("SELECT bind_id FROM dd_system_Comments WHERE id = ?");
    $stmt->execute([$commentId]);
    $bind = $stmt->fetch();
    $elementId = $bind['bind_id'];

    $stmt = $db->prepare("
        SELECT c.id, c.bind_type, c.bind_id, c.user_id, c.content as comment, c.is_resolved, c.created_at, u.name as user_name 
        FROM dd_system_Comments c
        LEFT JOIN dd_users u ON c.user_id = u.id
        WHERE c.bind_type = 'element' AND c.bind_id = ?
        ORDER BY c.created_at DESC
    ");
    $stmt->execute([$elementId]);
    $comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return ['success' => true, 'comments' => $comments];
}
