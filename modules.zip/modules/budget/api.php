<?php
// modules/budget/api.php

function handle_api($action, $db)
{
    switch ($action) {
        case 'budget_get':
            return get_budget($db);
        case 'budget_save':
            return save_budget($db);
        case 'budget_catalog_search':
            return search_catalog($db);
        default:
            throw new Exception("Unknown budget action: " . $action);
    }
}

function get_budget($db)
{
    $elementId = (int) ($_GET['element_id'] ?? 0);
    if (!$elementId) {
        throw new Exception("Element ID required");
    }

    // Get budget items
    $stmt = $db->prepare(
        "SELECT bi.*, pc.item_code as catalog_code " .
        "FROM dd_budget_items bi " .
        "LEFT JOIN dd_price_catalogs pc ON bi.price_catalog_id = pc.id " .
        "WHERE bi.element_id = ? " .
        "ORDER BY bi.id ASC"
    );
    $stmt->execute([$elementId]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calculate totals
    $totals = [
        'amount_0_1' => 0,
        'amount_1_2' => 0,
        'amount_3_5' => 0,
        'amount_5_10' => 0,
        'total' => 0
    ];

    foreach ($items as $item) {
        $totals['amount_0_1'] += (float) $item['amount_0_1'];
        $totals['amount_1_2'] += (float) $item['amount_1_2'];
        $totals['amount_3_5'] += (float) $item['amount_3_5'];
        $totals['amount_5_10'] += (float) $item['amount_5_10'];
        $totals['total'] += (float) $item['total_calculated'];
    }

    return [
        'items' => $items,
        'totals' => $totals
    ];
}

function save_budget($db)
{
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        throw new Exception("Invalid JSON input");
    }

    $elementId = (int) ($input['element_id'] ?? 0);
    $items = $input['items'] ?? [];

    if (!$elementId) {
        throw new Exception("Element ID required");
    }

    try {
        $db->beginTransaction();

        // 1. Delete existing
        $stmt = $db->prepare("DELETE FROM dd_budget_items WHERE element_id = ?");
        $stmt->execute([$elementId]);

        // 2. Insert new
        $insert = $db->prepare(
            "INSERT INTO dd_budget_items " .
            "(element_id, description, quantity, unit, unit_price, amount_0_1, amount_1_2, amount_3_5, amount_5_10, total_calculated, price_catalog_id) " .
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );

        $totalCapex = 0;

        foreach ($items as $item) {
            $qty = (float) ($item['quantity'] ?? 0);
            $price = (float) ($item['unit_price'] ?? 0);
            $total = $qty * $price;

            $a01 = (float) ($item['amount_0_1'] ?? 0);
            $a12 = (float) ($item['amount_1_2'] ?? 0);
            $a35 = (float) ($item['amount_3_5'] ?? 0);
            $a510 = (float) ($item['amount_5_10'] ?? 0);

            // Re-calculate total from distribution if provided, otherwise price*qty
            // To match sys_tdd: total_calculated is stored

            $catId = !empty($item['price_catalog_id']) ? $item['price_catalog_id'] : null;

            $insert->execute([
                $elementId,
                $item['description'] ?? '',
                $qty,
                $item['unit'] ?? 'stk',
                $price,
                $a01,
                $a12,
                $a35,
                $a510,
                $total,
                $catId
            ]);

            $totalCapex += $total;
        }

        // 3. Update Element CAPEX
        // Since we are in a transaction, we can update the element directly here as well to be sure
        $update = $db->prepare("UPDATE dd_building_Elements SET capex = ?, estimated_cost = ? WHERE id = ?");
        $update->execute([$totalCapex, $totalCapex, $elementId]);

        $db->commit();
        return ['success' => true, 'total_capex' => $totalCapex];

    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

function search_catalog($db)
{
    $q = $_GET['q'] ?? '';
    if (strlen($q) < 2)
        return [];

    $stmt = $db->prepare(
        "SELECT * FROM dd_price_catalogs " .
        "WHERE description LIKE ? OR item_code LIKE ? " .
        "LIMIT 20"
    );
    $term = "%{$q}%";
    $stmt->execute([$term, $term]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>